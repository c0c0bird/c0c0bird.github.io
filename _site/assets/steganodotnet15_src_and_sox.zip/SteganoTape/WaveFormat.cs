using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;

namespace SteganoTape {
	[StructLayout(LayoutKind.Sequential)]
	public class WaveFormat {
        private short wFormatTag;
        private short nChannels;
        private int nSamplesPerSec;
        private int nAvgBytesPerSec;
        private short nBlockAlign;
        private short wBitsPerSample;
        private short cbSize;

        public short FormatTag
        {
            get { return wFormatTag; }
            set { wFormatTag = value; }
        }

        public short Channels
        {
            get { return nChannels; }
            set { nChannels = value; }
        }

        public int SamplesPerSec
        {
            get { return nSamplesPerSec; }
            set { nSamplesPerSec = value; }
        }

        public int AvgBytesPerSec
        {
            //get{ return nSamplesPerSec * nBlockAlign; }
            get { return nAvgBytesPerSec; }
            set { nAvgBytesPerSec = value; }
        }

        public short BlockAlign
        {
            //get { return (short)(nChannels * (wBitsPerSample / 8)); }
            get{ return nBlockAlign; }
            set { nBlockAlign = value; }
        }

        public short BitsPerSample
        {
            get { return wBitsPerSample; }
            set { wBitsPerSample = value; }
        }

		public short Size
		{
			get { return cbSize; }
			set { cbSize = value; }
		}
    }
}
