using System;
using System.IO;
using System.Collections.Generic;
using System.Text;

namespace SteganoTape {
	public class WaveSound {

		private WaveFormat format;
		private short[] samples;

		public WaveFormat Format
		{
			get { return format; }
		}

		public int Count
		{
			get { return samples.Length; }
		}

		public short[] Samples
		{
			get { return samples; }
		}

		public short this[int indexer]{
			get { return samples[indexer]; }
			set { samples[indexer] = value; }
		}

		public WaveSound(WaveFormat format, short[] samples)
		{
			this.format = format;
			this.samples = samples;
		}

		public Stream CreateStream()
		{
			MemoryStream stream = new MemoryStream();
			BinaryWriter writer = new BinaryWriter(stream);

			writer.Write(System.Text.Encoding.ASCII.GetBytes("RIFF".ToCharArray()));

			writer.Write((Int32)(samples.Length + 36)); //File length minus first 8 bytes of RIFF description

			writer.Write(System.Text.Encoding.ASCII.GetBytes("WAVEfmt ".ToCharArray()));

			writer.Write((Int32)16); //length of following chunk: 16

			writer.Write(format.FormatTag);
			writer.Write(format.Channels);
			writer.Write(format.SamplesPerSec);
			writer.Write(format.AvgBytesPerSec);
			writer.Write(format.BlockAlign);
			writer.Write(format.BitsPerSample);

			writer.Write(System.Text.Encoding.ASCII.GetBytes("data".ToCharArray()));

			writer.Write(samples.Length);

			//byte[] b = new byte[samples.Length];
			//waveData.Read(b, 0, samples.Length);
			//writer.Write(b);
			for (int n = 0; n < samples.Length; n++) {
				if (format.BitsPerSample == 8) {
					writer.Write((byte)samples[n]);
				} else {
					writer.Write(samples[n]);
				}
			}

			writer.Seek(0, SeekOrigin.Begin);
			return stream;
		}

		public int SaveToFile(String fileName)
		{
			Stream stream = CreateStream();
			FileStream file = new FileStream(fileName, FileMode.Create);

			int fileLength = (int)stream.Length;

			byte[] buffer = new byte[fileLength];
			stream.Read(buffer, 0, fileLength);
			file.Write(buffer, 0, fileLength);

			file.Close();
			stream.Close();
			return fileLength;
		}

	}
}
