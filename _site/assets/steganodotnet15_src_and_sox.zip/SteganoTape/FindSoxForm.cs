using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SteganoTape {
	public partial class FindSoxForm : Form {

		public String SoxPath
		{
			get
			{
				return txtPath.Text;
			}
		}

		public FindSoxForm()
		{
			InitializeComponent();
		}

		private void btnBrowse_Click(object sender, EventArgs e)
		{
			OpenFileDialog dlg = new OpenFileDialog();
			dlg.FileName = "sox.exe";
			dlg.Filter = "sox.exe|sox.exe";
			if (dlg.ShowDialog() == DialogResult.OK) {
				txtPath.Text = dlg.FileName;
			}
		}

		private void FindSoXForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			if (this.DialogResult == DialogResult.Cancel) {
				txtPath.Text = String.Empty;
			}
		}
	}
}