namespace SteganoTape {
    partial class MainForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.components = new System.ComponentModel.Container();
			this.btnFind = new System.Windows.Forms.Button();
			this.btnExtract = new System.Windows.Forms.Button();
			this.txtHideMessage = new System.Windows.Forms.TextBox();
			this.btnHideCheckLength = new System.Windows.Forms.Button();
			this.lblRequiredSeconds = new System.Windows.Forms.Label();
			this.btnHide = new System.Windows.Forms.Button();
			this.numExtractFrequency = new System.Windows.Forms.NumericUpDown();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.numExtractVolume = new System.Windows.Forms.NumericUpDown();
			this.btnExtractFilterVolume = new System.Windows.Forms.Button();
			this.btnExtractBandPass = new System.Windows.Forms.Button();
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabHide = new System.Windows.Forms.TabPage();
			this.panelStep3 = new System.Windows.Forms.Panel();
			this.label12 = new System.Windows.Forms.Label();
			this.numHideVolume = new System.Windows.Forms.NumericUpDown();
			this.numHideFrequency = new System.Windows.Forms.NumericUpDown();
			this.label13 = new System.Windows.Forms.Label();
			this.btnHideCheckSettings = new System.Windows.Forms.Button();
			this.panelStep2 = new System.Windows.Forms.Panel();
			this.label8 = new System.Windows.Forms.Label();
			this.label16 = new System.Windows.Forms.Label();
			this.label15 = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.tabFind = new System.Windows.Forms.TabPage();
			this.panelFind = new System.Windows.Forms.Panel();
			this.label3 = new System.Windows.Forms.Label();
			this.txtExtractMessage = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.images = new System.Windows.Forms.ImageList(this.components);
			this.errorProvider = new System.Windows.Forms.ErrorProvider(this.components);
			this.waveControl = new SteganoTape.WaveDisplayControl();
			((System.ComponentModel.ISupportInitialize)(this.numExtractFrequency)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numExtractVolume)).BeginInit();
			this.tabControl1.SuspendLayout();
			this.tabHide.SuspendLayout();
			this.panelStep3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.numHideVolume)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numHideFrequency)).BeginInit();
			this.panelStep2.SuspendLayout();
			this.tabFind.SuspendLayout();
			this.panelFind.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
			this.SuspendLayout();
			// 
			// btnFind
			// 
			this.btnFind.Location = new System.Drawing.Point(427, 17);
			this.btnFind.Name = "btnFind";
			this.btnFind.Size = new System.Drawing.Size(155, 23);
			this.btnFind.TabIndex = 3;
			this.btnFind.Text = "Find noises";
			this.btnFind.Click += new System.EventHandler(this.btnFind_Click);
			// 
			// btnExtract
			// 
			this.btnExtract.Location = new System.Drawing.Point(427, 67);
			this.btnExtract.Name = "btnExtract";
			this.btnExtract.Size = new System.Drawing.Size(155, 23);
			this.btnExtract.TabIndex = 6;
			this.btnExtract.Text = "Read message";
			this.btnExtract.Click += new System.EventHandler(this.btnExtract_Click);
			// 
			// txtHideMessage
			// 
			this.txtHideMessage.Location = new System.Drawing.Point(53, 48);
			this.txtHideMessage.Multiline = true;
			this.txtHideMessage.Name = "txtHideMessage";
			this.txtHideMessage.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.txtHideMessage.Size = new System.Drawing.Size(226, 68);
			this.txtHideMessage.TabIndex = 7;
			this.txtHideMessage.TextChanged += new System.EventHandler(this.txtMessage_TextChanged);
			// 
			// btnHideCheckLength
			// 
			this.btnHideCheckLength.Location = new System.Drawing.Point(0, 0);
			this.btnHideCheckLength.Name = "btnHideCheckLength";
			this.btnHideCheckLength.Size = new System.Drawing.Size(226, 23);
			this.btnHideCheckLength.TabIndex = 8;
			this.btnHideCheckLength.Text = "Check length";
			this.btnHideCheckLength.Click += new System.EventHandler(this.btnCheckLength_Click);
			// 
			// lblRequiredSeconds
			// 
			this.lblRequiredSeconds.AutoSize = true;
			this.lblRequiredSeconds.Location = new System.Drawing.Point(3, 34);
			this.lblRequiredSeconds.Name = "lblRequiredSeconds";
			this.lblRequiredSeconds.Size = new System.Drawing.Size(53, 13);
			this.lblRequiredSeconds.TabIndex = 9;
			this.lblRequiredSeconds.Text = "[unknown]";
			// 
			// btnHide
			// 
			this.btnHide.Enabled = false;
			this.btnHide.Location = new System.Drawing.Point(437, 117);
			this.btnHide.Name = "btnHide";
			this.btnHide.Size = new System.Drawing.Size(238, 23);
			this.btnHide.TabIndex = 10;
			this.btnHide.Text = "Write";
			this.btnHide.Click += new System.EventHandler(this.btnHide_Click);
			// 
			// numExtractFrequency
			// 
			this.numExtractFrequency.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
			this.numExtractFrequency.Location = new System.Drawing.Point(133, 22);
			this.numExtractFrequency.Maximum = new decimal(new int[] {
            4000,
            0,
            0,
            0});
			this.numExtractFrequency.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
			this.numExtractFrequency.Name = "numExtractFrequency";
			this.numExtractFrequency.Size = new System.Drawing.Size(50, 20);
			this.numExtractFrequency.TabIndex = 11;
			this.numExtractFrequency.Value = new decimal(new int[] {
            2500,
            0,
            0,
            0});
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(58, 29);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(75, 13);
			this.label1.TabIndex = 12;
			this.label1.Text = "Frequency (Hz)";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(74, 73);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(53, 13);
			this.label2.TabIndex = 14;
			this.label2.Text = "Volume";
			// 
			// numExtractVolume
			// 
			this.numExtractVolume.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
			this.numExtractVolume.Location = new System.Drawing.Point(133, 70);
			this.numExtractVolume.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
			this.numExtractVolume.Minimum = new decimal(new int[] {
            0,
            0,
            0,
            0});
			this.numExtractVolume.Name = "numExtractVolume";
			this.numExtractVolume.Size = new System.Drawing.Size(50, 20);
			this.numExtractVolume.TabIndex = 13;
			this.numExtractVolume.Value = new decimal(new int[] {
            6000,
            0,
            0,
            0});
			// 
			// btnExtractFilterVolume
			// 
			this.btnExtractFilterVolume.Location = new System.Drawing.Point(189, 68);
			this.btnExtractFilterVolume.Name = "btnExtractFilterVolume";
			this.btnExtractFilterVolume.Size = new System.Drawing.Size(92, 23);
			this.btnExtractFilterVolume.TabIndex = 15;
			this.btnExtractFilterVolume.Text = "Filter sound";
			this.btnExtractFilterVolume.Click += new System.EventHandler(this.btnExtractFilterVolume_Click);
			// 
			// btnExtractBandPass
			// 
			this.btnExtractBandPass.Location = new System.Drawing.Point(189, 17);
			this.btnExtractBandPass.Name = "btnExtractBandPass";
			this.btnExtractBandPass.Size = new System.Drawing.Size(92, 23);
			this.btnExtractBandPass.TabIndex = 16;
			this.btnExtractBandPass.Text = "Filter sound";
			this.btnExtractBandPass.Click += new System.EventHandler(this.btnExtractBandPass_Click);
			// 
			// tabControl1
			// 
			this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.tabControl1.Controls.Add(this.tabHide);
			this.tabControl1.Controls.Add(this.tabFind);
			this.tabControl1.Location = new System.Drawing.Point(12, 328);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(768, 245);
			this.tabControl1.TabIndex = 17;
			// 
			// tabHide
			// 
			this.tabHide.Controls.Add(this.panelStep3);
			this.tabHide.Controls.Add(this.panelStep2);
			this.tabHide.Controls.Add(this.label16);
			this.tabHide.Controls.Add(this.label15);
			this.tabHide.Controls.Add(this.label14);
			this.tabHide.Controls.Add(this.label11);
			this.tabHide.Controls.Add(this.label10);
			this.tabHide.Controls.Add(this.label9);
			this.tabHide.Controls.Add(this.label7);
			this.tabHide.Controls.Add(this.txtHideMessage);
			this.tabHide.Controls.Add(this.btnHide);
			this.tabHide.Location = new System.Drawing.Point(4, 22);
			this.tabHide.Name = "tabHide";
			this.tabHide.Padding = new System.Windows.Forms.Padding(3);
			this.tabHide.Size = new System.Drawing.Size(760, 219);
			this.tabHide.TabIndex = 0;
			this.tabHide.Text = "Hide";
			// 
			// panelStep3
			// 
			this.panelStep3.Controls.Add(this.label12);
			this.panelStep3.Controls.Add(this.numHideVolume);
			this.panelStep3.Controls.Add(this.numHideFrequency);
			this.panelStep3.Controls.Add(this.label13);
			this.panelStep3.Controls.Add(this.btnHideCheckSettings);
			this.panelStep3.Enabled = false;
			this.panelStep3.Location = new System.Drawing.Point(424, 29);
			this.panelStep3.Name = "panelStep3";
			this.panelStep3.Size = new System.Drawing.Size(251, 58);
			this.panelStep3.TabIndex = 30;
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(12, 7);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(75, 13);
			this.label12.TabIndex = 22;
			this.label12.Text = "Frequency (Hz)";
			// 
			// numHideVolume
			// 
			this.numHideVolume.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
			this.numHideVolume.Location = new System.Drawing.Point(87, 32);
			this.numHideVolume.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
			this.numHideVolume.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
			this.numHideVolume.Name = "numHideVolume";
			this.numHideVolume.Size = new System.Drawing.Size(50, 20);
			this.numHideVolume.TabIndex = 23;
			this.numHideVolume.Value = new decimal(new int[] {
            6000,
            0,
            0,
            0});
			// 
			// numHideFrequency
			// 
			this.numHideFrequency.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
			this.numHideFrequency.Location = new System.Drawing.Point(87, 0);
			this.numHideFrequency.Maximum = new decimal(new int[] {
            4000,
            0,
            0,
            0});
			this.numHideFrequency.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
			this.numHideFrequency.Name = "numHideFrequency";
			this.numHideFrequency.Size = new System.Drawing.Size(50, 20);
			this.numHideFrequency.TabIndex = 21;
			this.numHideFrequency.Value = new decimal(new int[] {
            2500,
            0,
            0,
            0});
			// 
			// label13
			// 
			this.label13.AutoSize = true;
			this.label13.Location = new System.Drawing.Point(49, 37);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(38, 13);
			this.label13.TabIndex = 24;
			this.label13.Text = "Volume";
			// 
			// btnHideCheckSettings
			// 
			this.btnHideCheckSettings.Location = new System.Drawing.Point(159, 32);
			this.btnHideCheckSettings.Name = "btnHideCheckSettings";
			this.btnHideCheckSettings.Size = new System.Drawing.Size(92, 23);
			this.btnHideCheckSettings.TabIndex = 25;
			this.btnHideCheckSettings.Text = "Check sound";
			this.btnHideCheckSettings.Click += new System.EventHandler(this.btnCheckHideSettings_Click);
			// 
			// panelStep2
			// 
			this.panelStep2.Controls.Add(this.btnHideCheckLength);
			this.panelStep2.Controls.Add(this.label8);
			this.panelStep2.Controls.Add(this.lblRequiredSeconds);
			this.panelStep2.Enabled = false;
			this.panelStep2.Location = new System.Drawing.Point(53, 150);
			this.panelStep2.Name = "panelStep2";
			this.panelStep2.Size = new System.Drawing.Size(227, 52);
			this.panelStep2.TabIndex = 29;
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(62, 34);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(86, 13);
			this.label8.TabIndex = 12;
			this.label8.Text = "Seconds required";
			// 
			// label16
			// 
			this.label16.AutoSize = true;
			this.label16.Location = new System.Drawing.Point(436, 195);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(195, 13);
			this.label16.TabIndex = 28;
			this.label16.Text = "Now you can play and record the sound.";
			// 
			// label15
			// 
			this.label15.AutoSize = true;
			this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label15.Location = new System.Drawing.Point(396, 180);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(22, 31);
			this.label15.TabIndex = 27;
			this.label15.Text = "5";
			// 
			// label14
			// 
			this.label14.AutoSize = true;
			this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label14.Location = new System.Drawing.Point(396, 111);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(22, 31);
			this.label14.TabIndex = 26;
			this.label14.Text = "4";
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label11.Location = new System.Drawing.Point(396, 19);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(22, 31);
			this.label11.TabIndex = 20;
			this.label11.Text = "3";
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label10.Location = new System.Drawing.Point(20, 140);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(22, 31);
			this.label10.TabIndex = 19;
			this.label10.Text = "2";
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label9.Location = new System.Drawing.Point(20, 19);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(22, 31);
			this.label9.TabIndex = 18;
			this.label9.Text = "1";
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(52, 32);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(73, 13);
			this.label7.TabIndex = 11;
			this.label7.Text = "Enter message";
			// 
			// tabFind
			// 
			this.tabFind.Controls.Add(this.panelFind);
			this.tabFind.Location = new System.Drawing.Point(4, 22);
			this.tabFind.Name = "tabFind";
			this.tabFind.Padding = new System.Windows.Forms.Padding(3);
			this.tabFind.Size = new System.Drawing.Size(760, 219);
			this.tabFind.TabIndex = 1;
			this.tabFind.Text = "Find";
			// 
			// panelFind
			// 
			this.panelFind.Controls.Add(this.label3);
			this.panelFind.Controls.Add(this.txtExtractMessage);
			this.panelFind.Controls.Add(this.numExtractVolume);
			this.panelFind.Controls.Add(this.label5);
			this.panelFind.Controls.Add(this.numExtractFrequency);
			this.panelFind.Controls.Add(this.label4);
			this.panelFind.Controls.Add(this.label2);
			this.panelFind.Controls.Add(this.label1);
			this.panelFind.Controls.Add(this.btnFind);
			this.panelFind.Controls.Add(this.btnExtractFilterVolume);
			this.panelFind.Controls.Add(this.btnExtractBandPass);
			this.panelFind.Controls.Add(this.btnExtract);
			this.panelFind.Enabled = false;
			this.panelFind.Location = new System.Drawing.Point(8, 8);
			this.panelFind.Name = "panelFind";
			this.panelFind.Size = new System.Drawing.Size(734, 207);
			this.panelFind.TabIndex = 21;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.Location = new System.Drawing.Point(12, 11);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(22, 31);
			this.label3.TabIndex = 17;
			this.label3.Text = "1";
			// 
			// txtExtractMessage
			// 
			this.txtExtractMessage.Location = new System.Drawing.Point(427, 106);
			this.txtExtractMessage.Multiline = true;
			this.txtExtractMessage.Name = "txtExtractMessage";
			this.txtExtractMessage.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.txtExtractMessage.Size = new System.Drawing.Size(298, 100);
			this.txtExtractMessage.TabIndex = 20;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label5.Location = new System.Drawing.Point(377, 60);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(22, 31);
			this.label5.TabIndex = 19;
			this.label5.Text = "3";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.Location = new System.Drawing.Point(377, 9);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(22, 31);
			this.label4.TabIndex = 18;
			this.label4.Text = "2";
			// 
			// images
			// 
			this.images.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
			this.images.ImageSize = new System.Drawing.Size(16, 16);
			this.images.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// errorProvider
			// 
			this.errorProvider.ContainerControl = this;
			// 
			// waveControl
			// 
			this.waveControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
						| System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.waveControl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.waveControl.Location = new System.Drawing.Point(12, 1);
			this.waveControl.Name = "waveControl";
			this.waveControl.Size = new System.Drawing.Size(768, 310);
			this.waveControl.SoxPath = null;
			this.waveControl.TabIndex = 4;
			this.waveControl.WaveSound = null;
			this.waveControl.ZoomPercent = 5F;
			this.waveControl.Open += new System.EventHandler(this.waveControl_Open);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(792, 573);
			this.Controls.Add(this.waveControl);
			this.Controls.Add(this.tabControl1);
			this.Name = "MainForm";
			this.Text = "Analog Steganography";
			this.Load += new System.EventHandler(this.MainForm_Load);
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
			((System.ComponentModel.ISupportInitialize)(this.numExtractFrequency)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numExtractVolume)).EndInit();
			this.tabControl1.ResumeLayout(false);
			this.tabHide.ResumeLayout(false);
			this.tabHide.PerformLayout();
			this.panelStep3.ResumeLayout(false);
			this.panelStep3.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.numHideVolume)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numHideFrequency)).EndInit();
			this.panelStep2.ResumeLayout(false);
			this.panelStep2.PerformLayout();
			this.tabFind.ResumeLayout(false);
			this.panelFind.ResumeLayout(false);
			this.panelFind.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
			this.ResumeLayout(false);

        }

        #endregion

		private System.Windows.Forms.Button btnFind;
		private System.Windows.Forms.Button btnExtract;
		private System.Windows.Forms.TextBox txtHideMessage;
		private System.Windows.Forms.Button btnHideCheckLength;
		private System.Windows.Forms.Label lblRequiredSeconds;
		private System.Windows.Forms.Button btnHide;
		private System.Windows.Forms.NumericUpDown numExtractFrequency;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.NumericUpDown numExtractVolume;
		private System.Windows.Forms.Button btnExtractFilterVolume;
		private System.Windows.Forms.Button btnExtractBandPass;
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabFind;
		private System.Windows.Forms.TabPage tabHide;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Button btnHideCheckSettings;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.NumericUpDown numHideFrequency;
		private System.Windows.Forms.NumericUpDown numHideVolume;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.ImageList images;
		private System.Windows.Forms.ErrorProvider errorProvider;
		private System.Windows.Forms.Panel panelStep2;
		private System.Windows.Forms.Panel panelStep3;
		private WaveDisplayControl waveControl;
		private System.Windows.Forms.TextBox txtExtractMessage;
		private System.Windows.Forms.Panel panelFind;
    }
}

