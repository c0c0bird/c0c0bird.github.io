﻿using System;

namespace SteganoMusic
{
	public class ComparableNote: IComparable
    {
        private string noteName;
        private int index;

        public string NoteName
        {
            get { return this.noteName; }
        }

        public int Index
        {
            get { return this.index; }
        }

        public ComparableNote(string noteName, int index)
        {
            this.noteName = noteName;
            this.index = index;
        }

        public int CompareTo(object obj)
        {
            ComparableNote other = obj as ComparableNote;
            if (obj == null)
            {
                return 1;
            }
            else
            {
                return (this.index.CompareTo(other.Index));
            }
        }

        public override string ToString()
        {
            return noteName;
        }
    }
}
