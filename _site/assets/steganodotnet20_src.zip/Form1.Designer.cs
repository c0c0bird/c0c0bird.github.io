﻿namespace SteganoMusic
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        //private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            /*if (disposing && (components != null))
            {
                components.Dispose();
            }*/
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnC = new System.Windows.Forms.Button();
            this.btnD = new System.Windows.Forms.Button();
            this.btnCS = new System.Windows.Forms.Button();
            this.btnDS = new System.Windows.Forms.Button();
            this.btnE = new System.Windows.Forms.Button();
            this.btnF = new System.Windows.Forms.Button();
            this.btnFS = new System.Windows.Forms.Button();
            this.btnG = new System.Windows.Forms.Button();
            this.btnGS = new System.Windows.Forms.Button();
            this.btnB = new System.Windows.Forms.Button();
            this.btnA = new System.Windows.Forms.Button();
            this.btnH = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtKey = new System.Windows.Forms.TextBox();
            this.rdoSimpleQuarters = new System.Windows.Forms.RadioButton();
            this.rdoMakeMelody = new System.Windows.Forms.RadioButton();
            this.txtSrcList = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtMessage = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtMaxValue = new System.Windows.Forms.TextBox();
            this.txtTextValue = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtCapacityLeft = new System.Windows.Forms.TextBox();
            this.txtCapacity = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnEncode = new System.Windows.Forms.Button();
            this.btnDecode = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.txtEncodedMessage = new System.Windows.Forms.TextBox();
            this.pnlResultNotes = new System.Windows.Forms.Panel();
            this.btnPlayEncodedText = new System.Windows.Forms.Button();
            this.cmbAlphabet = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // btnC
            // 
            this.btnC.BackColor = System.Drawing.Color.White;
            this.btnC.Location = new System.Drawing.Point(25, 11);
            this.btnC.Name = "btnC";
            this.btnC.Size = new System.Drawing.Size(21, 60);
            this.btnC.TabIndex = 0;
            this.btnC.Tag = "0";
            this.btnC.Text = "C";
            this.btnC.UseVisualStyleBackColor = false;
            this.btnC.Click += new System.EventHandler(this.btnKey_Click);
            // 
            // btnD
            // 
            this.btnD.BackColor = System.Drawing.Color.White;
            this.btnD.Location = new System.Drawing.Point(69, 11);
            this.btnD.Name = "btnD";
            this.btnD.Size = new System.Drawing.Size(21, 60);
            this.btnD.TabIndex = 0;
            this.btnD.Tag = "2";
            this.btnD.Text = "D";
            this.btnD.UseVisualStyleBackColor = false;
            this.btnD.Click += new System.EventHandler(this.btnKey_Click);
            // 
            // btnCS
            // 
            this.btnCS.BackColor = System.Drawing.Color.Black;
            this.btnCS.ForeColor = System.Drawing.Color.White;
            this.btnCS.Location = new System.Drawing.Point(47, 11);
            this.btnCS.Name = "btnCS";
            this.btnCS.Size = new System.Drawing.Size(21, 46);
            this.btnCS.TabIndex = 1;
            this.btnCS.Tag = "1";
            this.btnCS.Text = "C#";
            this.btnCS.UseVisualStyleBackColor = false;
            this.btnCS.Click += new System.EventHandler(this.btnKey_Click);
            // 
            // btnDS
            // 
            this.btnDS.BackColor = System.Drawing.Color.Black;
            this.btnDS.ForeColor = System.Drawing.Color.White;
            this.btnDS.Location = new System.Drawing.Point(91, 11);
            this.btnDS.Name = "btnDS";
            this.btnDS.Size = new System.Drawing.Size(21, 46);
            this.btnDS.TabIndex = 1;
            this.btnDS.Tag = "3";
            this.btnDS.Text = "D#";
            this.btnDS.UseVisualStyleBackColor = false;
            this.btnDS.Click += new System.EventHandler(this.btnKey_Click);
            // 
            // btnE
            // 
            this.btnE.BackColor = System.Drawing.Color.White;
            this.btnE.Location = new System.Drawing.Point(112, 11);
            this.btnE.Name = "btnE";
            this.btnE.Size = new System.Drawing.Size(21, 60);
            this.btnE.TabIndex = 2;
            this.btnE.Tag = "4";
            this.btnE.Text = "E";
            this.btnE.UseVisualStyleBackColor = false;
            this.btnE.Click += new System.EventHandler(this.btnKey_Click);
            // 
            // btnF
            // 
            this.btnF.BackColor = System.Drawing.Color.White;
            this.btnF.Location = new System.Drawing.Point(134, 11);
            this.btnF.Name = "btnF";
            this.btnF.Size = new System.Drawing.Size(21, 60);
            this.btnF.TabIndex = 2;
            this.btnF.Tag = "5";
            this.btnF.Text = "F";
            this.btnF.UseVisualStyleBackColor = false;
            this.btnF.Click += new System.EventHandler(this.btnKey_Click);
            // 
            // btnFS
            // 
            this.btnFS.BackColor = System.Drawing.Color.Black;
            this.btnFS.ForeColor = System.Drawing.Color.White;
            this.btnFS.Location = new System.Drawing.Point(156, 11);
            this.btnFS.Name = "btnFS";
            this.btnFS.Size = new System.Drawing.Size(21, 46);
            this.btnFS.TabIndex = 3;
            this.btnFS.Tag = "6";
            this.btnFS.Text = "F#";
            this.btnFS.UseVisualStyleBackColor = false;
            this.btnFS.Click += new System.EventHandler(this.btnKey_Click);
            // 
            // btnG
            // 
            this.btnG.BackColor = System.Drawing.Color.White;
            this.btnG.Location = new System.Drawing.Point(177, 11);
            this.btnG.Name = "btnG";
            this.btnG.Size = new System.Drawing.Size(21, 60);
            this.btnG.TabIndex = 4;
            this.btnG.Tag = "7";
            this.btnG.Text = "G";
            this.btnG.UseVisualStyleBackColor = false;
            this.btnG.Click += new System.EventHandler(this.btnKey_Click);
            // 
            // btnGS
            // 
            this.btnGS.BackColor = System.Drawing.Color.Black;
            this.btnGS.ForeColor = System.Drawing.Color.White;
            this.btnGS.Location = new System.Drawing.Point(198, 11);
            this.btnGS.Name = "btnGS";
            this.btnGS.Size = new System.Drawing.Size(21, 46);
            this.btnGS.TabIndex = 5;
            this.btnGS.Tag = "8";
            this.btnGS.Text = "G#";
            this.btnGS.UseVisualStyleBackColor = false;
            this.btnGS.Click += new System.EventHandler(this.btnKey_Click);
            // 
            // btnB
            // 
            this.btnB.BackColor = System.Drawing.Color.Black;
            this.btnB.ForeColor = System.Drawing.Color.White;
            this.btnB.Location = new System.Drawing.Point(261, 11);
            this.btnB.Name = "btnB";
            this.btnB.Size = new System.Drawing.Size(21, 46);
            this.btnB.TabIndex = 7;
            this.btnB.Tag = "11";
            this.btnB.Text = "B";
            this.btnB.UseVisualStyleBackColor = false;
            this.btnB.Click += new System.EventHandler(this.btnKey_Click);
            // 
            // btnA
            // 
            this.btnA.BackColor = System.Drawing.Color.White;
            this.btnA.Location = new System.Drawing.Point(219, 11);
            this.btnA.Name = "btnA";
            this.btnA.Size = new System.Drawing.Size(21, 60);
            this.btnA.TabIndex = 6;
            this.btnA.Tag = "9";
            this.btnA.Text = "A";
            this.btnA.UseVisualStyleBackColor = false;
            this.btnA.Click += new System.EventHandler(this.btnKey_Click);
            // 
            // btnH
            // 
            this.btnH.BackColor = System.Drawing.Color.White;
            this.btnH.Location = new System.Drawing.Point(240, 11);
            this.btnH.Name = "btnH";
            this.btnH.Size = new System.Drawing.Size(21, 60);
            this.btnH.TabIndex = 6;
            this.btnH.Tag = "10";
            this.btnH.Text = "H";
            this.btnH.UseVisualStyleBackColor = false;
            this.btnH.Click += new System.EventHandler(this.btnKey_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 102);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Tonality";
            // 
            // txtKey
            // 
            this.txtKey.Location = new System.Drawing.Point(66, 99);
            this.txtKey.Name = "txtKey";
            this.txtKey.ReadOnly = true;
            this.txtKey.Size = new System.Drawing.Size(55, 20);
            this.txtKey.TabIndex = 9;
            // 
            // rdoMajor
            // 
            this.rdoSimpleQuarters.AutoSize = true;
            this.rdoSimpleQuarters.Checked = true;
            this.rdoSimpleQuarters.Location = new System.Drawing.Point(297, 11);
            this.rdoSimpleQuarters.Name = "rdoSimpleQuarters";
            this.rdoSimpleQuarters.Size = new System.Drawing.Size(42, 17);
            this.rdoSimpleQuarters.TabIndex = 10;
            this.rdoSimpleQuarters.TabStop = true;
            this.rdoSimpleQuarters.Text = "Simple quarters";
            this.rdoSimpleQuarters.UseVisualStyleBackColor = true;
            // 
            // rdoMinor
            // 
            this.rdoMakeMelody.AutoSize = true;
            this.rdoMakeMelody.Location = new System.Drawing.Point(297, 33);
            this.rdoMakeMelody.Name = "rdoMakeMelody";
            this.rdoMakeMelody.Size = new System.Drawing.Size(43, 17);
            this.rdoMakeMelody.TabIndex = 11;
            this.rdoMakeMelody.Text = "Random melody";
            this.rdoMakeMelody.UseVisualStyleBackColor = true;
            // 
            // txtSrcList
            // 
            this.txtSrcList.Location = new System.Drawing.Point(169, 99);
            this.txtSrcList.Multiline = true;
            this.txtSrcList.Name = "txtSrcList";
            this.txtSrcList.ReadOnly = true;
            this.txtSrcList.Size = new System.Drawing.Size(171, 47);
            this.txtSrcList.TabIndex = 12;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(131, 102);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Notes";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 152);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 13);
            this.label3.TabIndex = 14;
            this.label3.Text = "Content";
            // 
            // txtMessage
            // 
            this.txtMessage.Location = new System.Drawing.Point(66, 152);
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.Size = new System.Drawing.Size(273, 20);
            this.txtMessage.TabIndex = 15;
            this.txtMessage.TextChanged += new System.EventHandler(this.txtMessage_TextChanged);
			this.txtMessage.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TextBox_KeyDown);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(66, 205);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 13);
            this.label4.TabIndex = 17;
            this.label4.Text = "Content numeric";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(64, 231);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 13);
            this.label5.TabIndex = 17;
            this.label5.Text = "Max. number";
            // 
            // txtMaxValue
            // 
            this.txtMaxValue.Location = new System.Drawing.Point(152, 228);
            this.txtMaxValue.Name = "txtMaxValue";
            this.txtMaxValue.ReadOnly = true;
            this.txtMaxValue.Size = new System.Drawing.Size(186, 20);
            this.txtMaxValue.TabIndex = 9;
			this.txtMaxValue.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TextBox_KeyDown);
            // 
            // txtTextValue
            // 
            this.txtTextValue.Location = new System.Drawing.Point(152, 202);
            this.txtTextValue.Name = "txtTextValue";
            this.txtTextValue.ReadOnly = true;
            this.txtTextValue.Size = new System.Drawing.Size(186, 20);
            this.txtTextValue.TabIndex = 9;
			this.txtTextValue.DoubleClick += txtTextValue_DoubleClick;
			this.txtTextValue.TextChanged += txtTextValue_TextChanged;
			this.txtTextValue.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TextBox_KeyDown);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(66, 179);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 13);
            this.label7.TabIndex = 21;
            this.label7.Text = "Letters left";
            // 
            // txtCapacityLeft
            // 
            this.txtCapacityLeft.Location = new System.Drawing.Point(152, 176);
            this.txtCapacityLeft.Name = "txtCapacityLeft";
            this.txtCapacityLeft.ReadOnly = true;
            this.txtCapacityLeft.Size = new System.Drawing.Size(46, 20);
            this.txtCapacityLeft.TabIndex = 18;
			this.txtCapacityLeft.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TextBox_KeyDown);
            // 
            // txtCapacity
            // 
            this.txtCapacity.Location = new System.Drawing.Point(253, 176);
            this.txtCapacity.Name = "txtCapacity";
            this.txtCapacity.ReadOnly = true;
            this.txtCapacity.Size = new System.Drawing.Size(46, 20);
            this.txtCapacity.TabIndex = 18;
			this.txtCapacity.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TextBox_KeyDown);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(204, 179);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 13);
            this.label6.TabIndex = 21;
            this.label6.Text = "of ca.";
            // 
            // btnEncode
            // 
            this.btnEncode.Location = new System.Drawing.Point(66, 259);
            this.btnEncode.Name = "btnEncode";
            this.btnEncode.Size = new System.Drawing.Size(132, 23);
            this.btnEncode.TabIndex = 22;
            this.btnEncode.Text = "Mix";
            this.btnEncode.UseVisualStyleBackColor = true;
            this.btnEncode.Click += new System.EventHandler(this.btnEncode_Click);
            // 
            // btnDecode
            // 
            this.btnDecode.Location = new System.Drawing.Point(208, 259);
            this.btnDecode.Name = "btnDecode";
            this.btnDecode.Size = new System.Drawing.Size(132, 23);
            this.btnDecode.TabIndex = 22;
            this.btnDecode.Text = "Unmix";
            this.btnDecode.UseVisualStyleBackColor = true;
            this.btnDecode.Click += new System.EventHandler(this.btnDecode_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(13, 291);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Result";
            // 
            // txtEncodedMessage
            // 
            this.txtEncodedMessage.Location = new System.Drawing.Point(67, 288);
            this.txtEncodedMessage.Name = "txtEncodedMessage";
            this.txtEncodedMessage.Size = new System.Drawing.Size(273, 20);
            this.txtEncodedMessage.TabIndex = 15;
            this.txtEncodedMessage.Leave += new System.EventHandler(this.txtEncodedMessage_TextChanged);
			this.txtEncodedMessage.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TextBox_KeyDown);
            // 
            // pnlResultNotes
            // 
            this.pnlResultNotes.Location = new System.Drawing.Point(17, 320);//363);
            this.pnlResultNotes.Name = "pnlResultNotes";
            this.pnlResultNotes.Size = new System.Drawing.Size(384, 110);//50);
            this.pnlResultNotes.TabIndex = 23;
			this.pnlResultNotes.AutoScroll = true;
			this.pnlResultNotes.AutoScrollMinSize = new System.Drawing.Size(10, 200);
			//this.pnlResultNotes.Click += pnlResultNotes_Click;
			this.pnlResultNotes.MouseDown += pnlResultNotes_MouseDown;
            // 
            // btnPlayEncodedText
            // 
            this.btnPlayEncodedText.Location = new System.Drawing.Point(345, 286);
            this.btnPlayEncodedText.Name = "btnPlayEncodedText";
            this.btnPlayEncodedText.Size = new System.Drawing.Size(56, 23);
            this.btnPlayEncodedText.TabIndex = 24;
            this.btnPlayEncodedText.Text = "Play";
            this.btnPlayEncodedText.UseVisualStyleBackColor = true;
            this.btnPlayEncodedText.Click += new System.EventHandler(this.btnPlayEncodedText_Click);
            // 
            // cmbAlphabet
            // 
            this.cmbAlphabet.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAlphabet.FormattingEnabled = true;
            this.cmbAlphabet.Items.AddRange(new object[] {
            "42 Zeichen",
            "27 Zeichen"});
            this.cmbAlphabet.Location = new System.Drawing.Point(345, 152);
            this.cmbAlphabet.Name = "cmbAlphabet";
            this.cmbAlphabet.Size = new System.Drawing.Size(56, 21);
            this.cmbAlphabet.TabIndex = 25;
            this.cmbAlphabet.SelectedIndexChanged += new System.EventHandler(this.cmbAlphabet_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(432, 418);
            this.Controls.Add(this.cmbAlphabet);
            this.Controls.Add(this.btnPlayEncodedText);
            this.Controls.Add(this.pnlResultNotes);
            this.Controls.Add(this.btnDecode);
            this.Controls.Add(this.btnEncode);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtCapacity);
            this.Controls.Add(this.txtCapacityLeft);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtEncodedMessage);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtMessage);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtSrcList);
            this.Controls.Add(this.rdoMakeMelody);
            this.Controls.Add(this.rdoSimpleQuarters);
            this.Controls.Add(this.txtTextValue);
            this.Controls.Add(this.txtMaxValue);
            this.Controls.Add(this.txtKey);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnB);
            this.Controls.Add(this.btnH);
            this.Controls.Add(this.btnA);
            this.Controls.Add(this.btnGS);
            this.Controls.Add(this.btnG);
            this.Controls.Add(this.btnFS);
            this.Controls.Add(this.btnF);
            this.Controls.Add(this.btnE);
            this.Controls.Add(this.btnDS);
            this.Controls.Add(this.btnCS);
            this.Controls.Add(this.btnD);
            this.Controls.Add(this.btnC);
            this.Name = "Form1";
            this.Text = "Characters: a-z 0-9 .:-()";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnC;
        private System.Windows.Forms.Button btnD;
        private System.Windows.Forms.Button btnCS;
        private System.Windows.Forms.Button btnDS;
        private System.Windows.Forms.Button btnE;
        private System.Windows.Forms.Button btnF;
        private System.Windows.Forms.Button btnFS;
        private System.Windows.Forms.Button btnG;
        private System.Windows.Forms.Button btnGS;
        private System.Windows.Forms.Button btnB;
        private System.Windows.Forms.Button btnA;
        private System.Windows.Forms.Button btnH;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtKey;
        private System.Windows.Forms.RadioButton rdoSimpleQuarters;
        private System.Windows.Forms.RadioButton rdoMakeMelody;
        private System.Windows.Forms.TextBox txtSrcList;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtMessage;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtMaxValue;
        private System.Windows.Forms.TextBox txtTextValue;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtCapacityLeft;
        private System.Windows.Forms.TextBox txtCapacity;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnEncode;
        private System.Windows.Forms.Button btnDecode;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtEncodedMessage;
        private System.Windows.Forms.Panel pnlResultNotes;
        private System.Windows.Forms.Button btnPlayEncodedText;
        private System.Windows.Forms.ComboBox cmbAlphabet;
    }
}

