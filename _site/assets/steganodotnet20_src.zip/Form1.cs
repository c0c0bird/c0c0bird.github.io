/*
 * ToDo:
 * Lange Texte abschnittweise
 * Nur Töne einer Tonart 
 * Nur Harmonien zu fester Melodie
 */

#define OFF_IsMono

﻿using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

namespace SteganoMusic
{
    public partial class Form1 : Form
    {
		private const String charsAlphabet27 = "a-z space";
		private const String charsAlphabet42 = "a-z 0-9 .:-() space";
		
        private int alphabetSize = 42;
        private int alphabetBitsPerChar = 6;
        SortedList<Notes, float> noteToFrequency = new SortedList<Notes, float>();
        private long capacity;
        
		private struct Note{
			public Notes Value;
			public int Length;
			
			public Note(string noteText){
				string name = noteText;
				
				if(int.TryParse(noteText.Substring(noteText.Length-1), out this.Length)){
					name = noteText.Remove(noteText.Length-1);
				}else{
					this.Length = 4;
				}
				
				this.Value = (Notes)Enum.Parse(typeof(Notes), name);
			}
			
			public override string ToString(){
				return this.Value.ToString() + this.Length.ToString();
			}
		}
		
        private enum Notes
        {
            C = 0,
            Cis,
            D,
            Dis,
            E,
            F,
            Fis,
            G,
            Gis,
            A,
            H,
            B,
            c,
            cis,
            d,
            dis,
            e,
            f,
            fis,
            g,
            gis,
            a,
            h,
            b
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnKey_Click(object sender, EventArgs e)
        {
            int noteOffset = int.Parse(((Button)sender).Tag.ToString());
            txtKey.Text = ((Notes)noteOffset).ToString();

            if (rdoSimpleQuarters.Checked)
            {
                txtKey.Text += " major";
            }
            else
            {
                txtKey.Text += " minor";
            }

            StringBuilder scaleBuilder = new StringBuilder();
            for (int index = 0; index < 24; index++)
            {
                int currentNoteOffset = (index + noteOffset) % 24;
                scaleBuilder.AppendFormat("{0} ", ((Notes)currentNoteOffset).ToString());
            }
            txtSrcList.Text = scaleBuilder.ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            InitFrequencies();
            cmbAlphabet.SelectedIndex = 0;
            btnC.PerformClick();
        }

        private void InitCapacity()
        {
            this.capacity = OrderUtility.GetCapacity(24, alphabetBitsPerChar);
            txtCapacity.Text = capacity.ToString();
            txtMaxValue.Text = OrderUtility.Factorial(24).ToString();
            txtCapacityLeft.Text = txtCapacity.Text;
            UpdateTextInfo();
        }

        private BigInteger Pow(int val, int exp)
        {
            BigInteger result;
            if (exp == 0)
            {
                result = new BigInteger(1);
            }
            else
            {
                result = new BigInteger(val);
                for (int n = 1; n < exp; n++)
                {
                    result = result * val;
                }
            }
            return result;
        }

        private int GetCharCode(byte charByte)
        {
            int charCode = -1;

            if (alphabetSize == 27)
            {   // a-z + space
                if (charByte == 32)
                {
                    charCode = 26; // space
                }
                else
                {
                    charCode = charByte - 97; // letters
                }
            }
            else
            {    // a-z 0-9 .:-() + space
                if (charByte > 96 && charByte < 123)
                {
                    charCode = charByte - 97; // letters
                }
                else if (charByte > 47 && charByte < 58)
                {
                    charCode = charByte - 22; // numbers
                }
                else if (charByte == 32)
                {
                    charCode = 36; // space
                }
                else if (charByte == 58)
                {
                    charCode = 37; // :
                }
                else if (charByte == 45)
                {
                    charCode = 38; // -
                }
                else if (charByte == 40)
                {
                    charCode = 39; // (
                }
                else if (charByte == 41)
                {
                    charCode = 40; // )
                }
                else if (charByte == 46)
                {
                    charCode = 41; // .
                }
            }
            return charCode;
        }

        private String GetCharValue(int charCode)
        {
            String text = String.Empty;

            if (alphabetSize == 27)
            {   // a-z + space
                if (charCode == 26)
                {
                    text = " ";
                }
                else
                {
                    text = Encoding.UTF8.GetString(new byte[] { (byte)(charCode + 97) });
                }
            }
            else
            {   // a-z 0-9 .:-() + space
                if (charCode < 26)
                { // letters
                    text = Encoding.UTF8.GetString(new byte[] { (byte)(charCode + 97) });
                }
                else if (charCode < 36)
                { // numbers
                    text = Encoding.UTF8.GetString(new byte[] { (byte)(charCode + 22) });
                }
                else if (charCode == 36)
                {
                    text = " ";
                }
                else if (charCode == 58)
                {
                    text = ":";
                }
                else if (charCode == 38)
                {
                    text = "-";
                }
                else if (charCode == 39)
                {
                    text = "(";
                }
                else if (charCode == 40)
                {
                    text = ")";
                }
                else if (charCode == 41)
                {
                    text = ".";
                }
            }
            return text;
        }

        private BigInteger TextToNumber(string text)
        {
            BigInteger textNumber = new BigInteger(0);
            text = text.ToLower();

            byte[] bytes = Encoding.UTF8.GetBytes(text);
            for (int n = 0; n < text.Length; n++)
            {
                int charCode = GetCharCode(bytes[n]);
                if (charCode > -1)
                {
                    BigInteger charValue = Pow(alphabetSize, text.Length - 1 - n);
                    charValue = charCode * charValue;
                    textNumber = textNumber + charValue;

                    //Console.WriteLine("{0} * Pow({3}, {1}) = {2}", charCode, text.Length - 1 - n, charValue, countChars);
                }
            }

            /*Console.WriteLine("in: " + textNumber.ToString());
            foreach (byte b in textNumber.getBytes())
            {
                Console.WriteLine("in: " + b);
            }*/

            return textNumber;
        }

        private String StreamToText(MemoryStream stream)
        {
            BigInteger textNumber = new BigInteger(stream.GetBuffer(), (int)stream.Length);
            String result = NumberToText(textNumber);
			return result;
		}
		
		private String NumberToText(BigInteger textNumber)
        {
            BigInteger temp = new BigInteger(textNumber);
			StringBuilder resultBuilder = new StringBuilder();

            Console.WriteLine("out: " + textNumber.ToString());
            foreach (byte b in textNumber.getBytes())
            {
                Console.WriteLine("out: " + b);
            }

            int maxExp = -1;
            while (temp > 0)
            {
                maxExp++;
                temp = temp / alphabetSize;
            }

            //Console.WriteLine("maxExp: " + maxExp);

            for (int n = maxExp; n > -1; n--)
            {
                BigInteger positionValue = Pow(alphabetSize, n);
                BigInteger charValue = (textNumber / positionValue);
                textNumber = textNumber % positionValue;

                resultBuilder.Append(GetCharValue(charValue.IntValue()));

                //Console.WriteLine("{0} / Pow({3}, {1}) = {2}", textNumber.ToString(), n, charValue.ToString(), alphabetSize);
            }
            return resultBuilder.ToString();
        }    

        private void txtMessage_TextChanged(object sender, EventArgs e)
        {
            UpdateTextInfo();
        }
		
		private void TextBox_KeyDown(object sender, KeyEventArgs e)
		{
			if(e.Control && e.KeyCode == Keys.Y){
				Control ctl = sender as Control;
				if(ctl != null){
					SetClipboard(ctl.Text);
				}
			}
		}

		private void SetClipboard(string text)
		{
			string path = Path.GetDirectoryName(Application.ExecutablePath) + Path.DirectorySeparatorChar;
			using(FileStream fs = new FileStream(path+"clipboard.txt", FileMode.Append))
			{
				using(StreamWriter sw = new StreamWriter(fs)){
					sw.WriteLine();
					sw.WriteLine(text);
				}
			}
		}
		
        private void UpdateTextInfo()
        {
            BigInteger textNumber = TextToNumber(txtMessage.Text);
            txtTextValue.Text = textNumber.ToString();
            txtCapacityLeft.Text = (this.capacity - txtMessage.Text.Length).ToString();
        }

        private Collection<IComparable> GetTextAsList(string text, string referenceList, bool removeMelody)
        {
			IList<string> lstStrings;
            if(removeMelody){
				lstStrings = MelodyToText(text);
			}else{
				lstStrings = text.Split(new char[] { ',', ' ', '\n' }, StringSplitOptions.RemoveEmptyEntries);
			}
            string[] txtRefStrings = referenceList.Split(new char[] { ',', ' ', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            
			
            Collection<IComparable> result = new Collection<IComparable>();
            foreach (string s in lstStrings)
            {
                int index = Array.IndexOf(txtRefStrings, s);
                if (index > -1)
                {
                    result.Add(new ComparableNote(s, index));
                    index++;
                }
            }
            return result;
        }

        private Collection<string> GetTextAsList(string text)
        {
            string[] txtStrings = text.Split(new char[] { ',', ' ', '\n' }, StringSplitOptions.RemoveEmptyEntries);

            Collection<string> txtList = new Collection<string>();
            foreach (string s in txtStrings)
            {
                txtList.Add(s.Trim());
            }
            return txtList;
        }
		
		private string GetListAsText(Collection<string> list)
		{
			string[] listAsArray = new string[list.Count];
			list.CopyTo(listAsArray, 0);
			string result = string.Join(" ", listAsArray);
			return result;
		}

        private void btnEncode_Click(object sender, EventArgs e)
        {
			try{
	            Collection<IComparable> sourceList = GetTextAsList(txtSrcList.Text, txtSrcList.Text, false);
	            
	            BigInteger messageNumber = TextToNumber(txtMessage.Text);
	            Stream message = new MemoryStream(messageNumber.getBytes());
	            Collection<IComparable> result = new Collection<IComparable>();
	            OrderUtility.Encode(sourceList, result, message);
	
	            StringBuilder resultBuilder = new StringBuilder();
	            foreach (ComparableNote n in result)
	            {
	                resultBuilder.AppendFormat("{0} ", n.NoteName);
	            }
	            
	            Collection<string> notesList = GetTextAsList(resultBuilder.ToString());
				if(rdoMakeMelody.Checked){
					notesList = TextToMelody(notesList);
				}
				
				txtEncodedMessage.Text = GetListAsText(notesList);
				txtEncodedMessage_TextChanged(txtMessage, EventArgs.Empty);
			}catch(Exception ex){
				MessageBox.Show(ex.ToString());
			}
        }

        private void btnDecode_Click(object sender, EventArgs e)
        {
			try{
         		Collection<IComparable> carrier = GetTextAsList(txtEncodedMessage.Text, txtSrcList.Text, true);
           		MemoryStream message = new MemoryStream();
           		OrderUtility.Decode(carrier, message);
           		txtMessage.Text = StreamToText(message);
			}catch(Exception ex){
				MessageBox.Show(ex.ToString());
			}
        }
		
		private Collection<string> TextToMelody(Collection<string> notesList)
		{
			int noteLength = 4;
			int randomIndex = 0;
			Random random = new Random();
			Collection<string> result = new Collection<string>();
			Collection<string> usedNotes = new Collection<string>();
			
			for(int index=0; index<notesList.Count; index++)
			{
				noteLength = random.Next(99);
				if(noteLength < 75){ noteLength = 1; }
				else{ noteLength = 2; }
				
				for(int n=0; n<noteLength; n++){
					// ein Viertel oder zwei Achtel einfügen
					result.Add(notesList[index]+(noteLength*4).ToString());
				}
				
				usedNotes.Add(notesList[index]);
				
				randomIndex = random.Next(0, usedNotes.Count-1);
				
				Console.WriteLine(randomIndex);
				
				if(randomIndex > usedNotes.Count/2){
					result.Add(usedNotes[randomIndex]+(noteLength*4).ToString());
					
					Console.WriteLine(result[result.Count-1]);
				}
			}
			
			return result;
		}
		
		private Collection<string> MelodyToText(string text){
			string[] txtStrings = text.Split(new char[] { ',', ' ', '\n' }, StringSplitOptions.RemoveEmptyEntries);
			Collection<string> result = new Collection<string>();
			
			for(int index=0; index<txtStrings.Length; index++)
			{
				Note note = new Note(txtStrings[index]);
				string noteName = note.Value.ToString();
				
				if(result.IndexOf(noteName) < 0){
					result.Add(noteName);
					Console.WriteLine(noteName);
				}
			}
			return result;
		}

        private void txtEncodedMessage_TextChanged(object sender, EventArgs e)
        {
			try{
	            pnlResultNotes.Controls.Clear();
				Collection<string> notesList = GetTextAsList(txtEncodedMessage.Text);
				
				Bitmap bmp = new Bitmap(384, 80);
				
				using(Graphics graphics = Graphics.FromImage(bmp))
				{
		            for (int index = 0; index < notesList.Count; index++)
		            {
						Note note = new Note(notesList[index]);
						
		                string fileName = "note_" + note.Value.ToString() + note.Length;
		                if ((int)note.Value > 11)
		                {   // zweite Oktave
		                    fileName += "_";
		                }
		                fileName += ".gif";
						fileName = Path.Combine("images", fileName);
		                fileName = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), fileName);
						
						if(!File.Exists(fileName)){
							fileName = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "images/noteEmpty.gif");
						}
					
						using(Image imgNote = Image.FromFile(fileName))
						{
							int imgTop = (index / 24) * 40;
		                	int imgLeft = (index % 24) * 16;
		                	graphics.DrawImage(imgNote, imgLeft, imgTop);
						}
		            }
						
					PictureBox pic = new PictureBox();
					pic.MouseDown += pnlResultNotes_MouseDown;
		            pic.Width = bmp.Width;
					pic.Height = bmp.Height;
					pic.Image = bmp;	
					pic.Left = 0;
				 	pic.Top = 0;
					pic.Show();
	                pnlResultNotes.Controls.Add(pic);
				}
			}catch(Exception ex){
				MessageBox.Show(ex.ToString());
			}
        }
		
		private void pnlResultNotes_MouseDown(object sender, MouseEventArgs e)
		{
			string path = Path.GetDirectoryName(Application.ExecutablePath) + Path.DirectorySeparatorChar;
			
			if(e.Button == MouseButtons.Left)
			{
				if(pnlResultNotes.Controls.Count > 0)
				{
					PictureBox pic = pnlResultNotes.Controls[0] as PictureBox;
					if(pic != null)
					{
						if(pic.Image != null){
							string fileName = path + "pic_"+DateTime.Now.ToString("yyyymmdd_hhmmss")+".png";
							Console.WriteLine(fileName);
							pic.Image.Save(fileName);
						}
					}
				}				
			}
			else
			{	
				string fileName = path + "temp.wav";
				SaveSoundToFile(fileName);
			}
		}

        private void InitFrequencies()
        {
            noteToFrequency.Add(Notes.C, 261.626f);
            noteToFrequency.Add(Notes.Cis, 277.183f);
            noteToFrequency.Add(Notes.D, 293.665f);
            noteToFrequency.Add(Notes.Dis, 311.127f);
            noteToFrequency.Add(Notes.E, 329.628f);
            noteToFrequency.Add(Notes.F, 349.228f);
            noteToFrequency.Add(Notes.Fis, 369.994f);
            noteToFrequency.Add(Notes.G, 391.995f);
            noteToFrequency.Add(Notes.Gis, 415.305f);
            noteToFrequency.Add(Notes.A, 440f);
            noteToFrequency.Add(Notes.H, 466.164f);
            noteToFrequency.Add(Notes.B, 493.883f);
            noteToFrequency.Add(Notes.c, 523.251f);
            noteToFrequency.Add(Notes.cis, 554.365f);
            noteToFrequency.Add(Notes.d, 587.330f);
            noteToFrequency.Add(Notes.dis, 622.254f);
            noteToFrequency.Add(Notes.e, 659.255f);
            noteToFrequency.Add(Notes.f, 698.456f);
            noteToFrequency.Add(Notes.fis, 739.989f);
            noteToFrequency.Add(Notes.g, 783.991f);
            noteToFrequency.Add(Notes.gis, 830.609f);
            noteToFrequency.Add(Notes.a, 880f);
            noteToFrequency.Add(Notes.h, 932.328f);
            noteToFrequency.Add(Notes.b, 987.767f);
        }

        private void btnPlayEncodedText_Click(object sender, EventArgs e)
        {
#if IsMono
			// save to file and let sox play
			string tempFileName = Path.GetTempFileName()+".wav";
			SaveSoundToFile(tempFileName);
			System.Diagnostics.Process.Start("play", tempFileName);
#else
			// beep note by note
			Collection<string> notesList = GetTextAsList(txtEncodedMessage.Text);	
			for (int index = 0; index < notesList.Count; index++)
            {
                Note note = new Note(notesList[index]);
				float frequency = noteToFrequency[note.Value];
                Console.Beep((int)frequency, 1000/note.Length);
            }
#endif
		}
		
		private void SaveSoundToFile(string fileName)
		{
			Collection<string> notesList = GetTextAsList(txtEncodedMessage.Text);
			
			WaveFormat format = new WaveFormat(44100, 16, 2);
			short[] samples = new short[(int)(format.Channels * format.SamplesPerSec * 6)];
			WaveSound waveSound = new WaveSound(format, samples);
			
			WaveUtility utility = new WaveUtility();			

            for (int index = 0; index < notesList.Count; index++)
            {
                Note note = new Note(notesList[index]);
				float frequency = noteToFrequency[note.Value];
				utility.AddWave(waveSound, frequency, index/4f, 1f/note.Length, 24000);
            }
			
			waveSound.SaveToFile(fileName);
		}

        private void cmbAlphabet_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbAlphabet.SelectedIndex == 0)
            {
                alphabetSize = 42;
                alphabetBitsPerChar = 6;
				this.Text = charsAlphabet42;
            }
            else
            {
                alphabetSize = 27;
                alphabetBitsPerChar = 5;
				this.Text = charsAlphabet27;
            }
            InitCapacity();
        }
		
		private void txtTextValue_DoubleClick(object sender, EventArgs e)
        {
			// swap ReadOnly
			txtTextValue.ReadOnly = !txtTextValue.ReadOnly;
			txtMessage.ReadOnly  = !txtTextValue.ReadOnly; 
		}
		
		private String RemoveInvalidChars(String numberText){
			int index = numberText.Length-1;
			while((numberText.Length > 0)&&(index > -1)){
				if((numberText[index] < '0')||(numberText[index] > '9')){
					numberText = numberText.Remove(index, 1);
				}
				index--;
			}
			return numberText;
		}
		
		private void txtTextValue_TextChanged(object sender, EventArgs e)
        {
			if(!txtTextValue.ReadOnly){
				if(txtTextValue.Text.Length == 0){
					txtMessage.Text = String.Empty;
				}else{
					String numberText = RemoveInvalidChars(txtTextValue.Text);
					try{
						BigInteger intValue = new BigInteger(numberText, 10);
				 		txtMessage.Text = NumberToText(intValue);
					}catch(Exception ex){
						txtMessage.Text = ex.Message;
					}
				}
			}
		}
    }
}