﻿namespace SteganoRegion
{
    partial class RegionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnNext = new System.Windows.Forms.Button();
            this.picImage = new System.Windows.Forms.PictureBox();
            this.mnuDeleteRegion = new System.Windows.Forms.MenuItem();
            this.picMap = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.contextmenuImage = new System.Windows.Forms.ContextMenu();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblMessageSize = new System.Windows.Forms.Label();
            this.lblSelectedPixels = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblHeaderSpace = new System.Windows.Forms.Label();
            this.lblHeaderSize = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblPercent = new System.Windows.Forms.Label();
            this.lblCapacity = new System.Windows.Forms.Label();
            this.errors = new System.Windows.Forms.ErrorProvider();
            this.ctlRegions = new SteganoRegion.RegionInfoList();
            ((System.ComponentModel.ISupportInitialize)(this.picImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMap)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errors)).BeginInit();
            this.SuspendLayout();
// 
// btnNext
// 
            this.btnNext.Location = new System.Drawing.Point(544, 504);
            this.btnNext.Name = "btnNext";
            this.btnNext.TabIndex = 0;
            this.btnNext.Text = "Next >>";
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
// 
// picImage
// 
            this.picImage.Location = new System.Drawing.Point(0, 0);
            this.picImage.Name = "picImage";
            this.picImage.Size = new System.Drawing.Size(216, 192);
            this.picImage.TabIndex = 2;
            this.picImage.TabStop = false;
            this.picImage.DoubleClick += new System.EventHandler(this.picImage_DoubleClick);
            this.picImage.MouseUp += new System.Windows.Forms.MouseEventHandler(this.picImage_MouseUp);
            this.picImage.MouseDown += new System.Windows.Forms.MouseEventHandler(this.picImage_MouseDown);
// 
// mnuDeleteRegion
// 
            this.mnuDeleteRegion.Index = 0;
            this.mnuDeleteRegion.Name = "mnuDeleteRegion";
            this.mnuDeleteRegion.Text = "Delete";
            this.mnuDeleteRegion.Click += new System.EventHandler(this.mnuDeleteRegion_Click);
// 
// picMap
// 
            this.picMap.Location = new System.Drawing.Point(0, 0);
            this.picMap.Name = "picMap";
            this.picMap.Size = new System.Drawing.Size(216, 200);
            this.picMap.TabIndex = 3;
            this.picMap.TabStop = false;
// 
// panel1
// 
            this.panel1.AutoScroll = true;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.picImage);
            this.panel1.Location = new System.Drawing.Point(13, 37);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 1, 3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(280, 240);
            this.panel1.TabIndex = 4;
// 
// panel2
// 
            this.panel2.AutoScroll = true;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.picMap);
            this.panel2.Location = new System.Drawing.Point(347, 37);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 1, 3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(272, 240);
            this.panel2.TabIndex = 5;
// 
// label3
// 
            this.label3.Location = new System.Drawing.Point(345, 13);
            this.label3.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label3.Name = "label3";
            this.label3.TabIndex = 10;
            this.label3.Text = "Regions only";
// 
// contextmenuImage
// 
            this.contextmenuImage.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                this.mnuDeleteRegion
            });
            this.contextmenuImage.Name = "contextmenuImage";
// 
// label2
// 
            this.label2.Location = new System.Drawing.Point(13, 13);
            this.label2.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(237, 23);
            this.label2.TabIndex = 9;
            this.label2.Text = "Image and Regions - Click to Draw a Region";
// 
// label1
// 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 472);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 14);
            this.label1.TabIndex = 13;
            this.label1.Text = "Message Size:";
// 
// label5
// 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(22, 492);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(70, 14);
            this.label5.TabIndex = 15;
            this.label5.Text = "Header Size:";
// 
// lblMessageSize
// 
            this.lblMessageSize.AutoSize = true;
            this.lblMessageSize.Location = new System.Drawing.Point(122, 471);
            this.lblMessageSize.Name = "lblMessageSize";
            this.lblMessageSize.Size = new System.Drawing.Size(84, 14);
            this.lblMessageSize.TabIndex = 17;
            this.lblMessageSize.Text = "lblMessageSize";
// 
// lblSelectedPixels
// 
            this.lblSelectedPixels.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectedPixels.Location = new System.Drawing.Point(108, 424);
            this.lblSelectedPixels.Name = "lblSelectedPixels";
            this.lblSelectedPixels.Size = new System.Drawing.Size(94, 14);
            this.lblSelectedPixels.TabIndex = 18;
            this.lblSelectedPixels.Text = "lblSelectedPixels";
// 
// label6
// 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(22, 513);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(96, 14);
            this.label6.TabIndex = 19;
            this.label6.Text = "Space for Header:";
// 
// lblHeaderSpace
// 
            this.lblHeaderSpace.AutoSize = true;
            this.lblHeaderSpace.Location = new System.Drawing.Point(122, 513);
            this.lblHeaderSpace.Name = "lblHeaderSpace";
            this.lblHeaderSpace.Size = new System.Drawing.Size(85, 14);
            this.lblHeaderSpace.TabIndex = 20;
            this.lblHeaderSpace.Text = "lblHeaderSpace";
// 
// lblHeaderSize
// 
            this.lblHeaderSize.AutoSize = true;
            this.lblHeaderSize.Location = new System.Drawing.Point(122, 492);
            this.lblHeaderSize.Name = "lblHeaderSize";
            this.lblHeaderSize.Size = new System.Drawing.Size(75, 14);
            this.lblHeaderSize.TabIndex = 21;
            this.lblHeaderSize.Text = "lblHeaderSize";
// 
// label7
// 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(45, 424);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 14);
            this.label7.TabIndex = 22;
            this.label7.Text = "Summary:";
// 
// lblPercent
// 
            this.lblPercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPercent.Location = new System.Drawing.Point(212, 425);
            this.lblPercent.Name = "lblPercent";
            this.lblPercent.Size = new System.Drawing.Size(57, 14);
            this.lblPercent.TabIndex = 23;
            this.lblPercent.Text = "lblPercent";
// 
// lblCapacity
// 
            this.lblCapacity.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCapacity.Location = new System.Drawing.Point(327, 424);
            this.lblCapacity.Name = "lblCapacity";
            this.lblCapacity.Size = new System.Drawing.Size(72, 14);
            this.lblCapacity.TabIndex = 24;
            this.lblCapacity.Text = "lblCapacity";
// 
// errors
// 
            this.errors.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            this.errors.ContainerControl = this;
// 
// ctlRegions
// 
            this.ctlRegions.AutoScroll = true;
            this.ctlRegions.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ctlRegions.Location = new System.Drawing.Point(45, 313);
            this.ctlRegions.Name = "ctlRegions";
            this.ctlRegions.Size = new System.Drawing.Size(546, 104);
            this.ctlRegions.TabIndex = 2;
            this.ctlRegions.SelectionChanged += new SteganoRegion.RegionInfoList.RegionEventHandler(this.ctlRegions_SelectionChanged);
            this.ctlRegions.Delete += new SteganoRegion.RegionInfoList.RegionEventHandler(this.ctlRegions_Delete);
// 
// RegionForm
// 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(636, 539);
            this.Controls.Add(this.lblCapacity);
            this.Controls.Add(this.lblPercent);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lblHeaderSize);
            this.Controls.Add(this.lblHeaderSpace);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lblSelectedPixels);
            this.Controls.Add(this.lblMessageSize);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.ctlRegions);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "RegionForm";
            this.Text = "Step 2 - Define the Regions of the Image";
            ((System.ComponentModel.ISupportInitialize)(this.picImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMap)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.errors)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblMessageSize;
        private System.Windows.Forms.Label lblSelectedPixels;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblHeaderSpace;
        private System.Windows.Forms.Label lblHeaderSize;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblPercent;
        private System.Windows.Forms.Label lblCapacity;
        private System.Windows.Forms.ErrorProvider errors;
        private RegionInfoList ctlRegions;
    }
}