﻿#region Using directives

using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;
using System.Drawing;

#endregion

namespace SteganoRegion
{
    static class Start
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main() {
            MainForm frmMain = new MainForm();

            //show the first dialog
            //let the user enter file names, key and message
            if (frmMain.ShowDialog() == DialogResult.OK) {

                if (frmMain.HideMessage) {
                    //the user decided to hide a message in an image

                    //get stream for message and key
                    Stream messageStream = frmMain.MessageStream;
                    Stream keyStream = frmMain.KeyStream;

                    String destinationFileName = frmMain.DestinationFileName;
                    RegionForm frmRegions = new RegionForm(frmMain.SourceFileName, (Int32)messageStream.Length);

                    //show the regions dialog
                    //let the user define regions
                    if (frmRegions.ShowDialog() == DialogResult.OK) {
                        //get image and regions
                        ImageInfo info = frmRegions.ImageInfo;
                        info.DestinationFileName = destinationFileName;

                        //hide the message in the specified regions of the image
                        ImageUtility utility = new ImageUtility(info);
                        utility.Hide(messageStream, keyStream);
                        MessageBox.Show("Finished.");
                    }

                    frmRegions.Dispose();
                    messageStream.Close();
                    keyStream.Close();

                } else {
                    //the user decided to extract a message from an image

                    ImageInfo info = new ImageInfo(Image.FromFile(frmMain.SourceFileName), new RegionInfo[0]);
                    ImageUtility utility = new ImageUtility(info);
                    MemoryStream messageStream = new MemoryStream();
                    Stream keyStream = frmMain.KeyStream;

                    //extract the regions
                    info.RegionInfo = utility.ExtractRegionData(keyStream);

                    //extract the message from the regions
                    utility.Extract(messageStream, keyStream);

                    //save or read the message stream

                    String messageFileName = frmMain.MessageDestinationFileName;
                    String messageText;

                    messageStream.Seek(0, SeekOrigin.Begin);

                    if (messageFileName.Length > 0) {
                        //copy the stream into a file
                        FileStream fileStream = new FileStream(messageFileName, FileMode.Create);
                        byte[] content = new byte[messageStream.Length];
                        messageStream.Read(content, 0, content.Length);
                        fileStream.Write(content, 0, content.Length);
                        fileStream.Close();
                        messageText = String.Format("The message has been saved to {0}.", messageFileName);
                    } else {
                        //read text from the stream
                        StreamReader reader = new StreamReader(messageStream);
                        messageText = reader.ReadToEnd();
                    }

                    messageStream.Close();
                    keyStream.Close();

                    //display regions and text
                    ExtractForm frmExtract = new ExtractForm(info, messageText);
                    frmExtract.ShowDialog();
                    frmExtract.Dispose();
                }
            }
        }
    }
}