﻿#region Using directives

using System;
using System.Drawing;

#endregion

namespace SteganoRegion
{
    public class ImageInfo
    {
        private Image image;
        public Image Image
        {
            get { return image; }
        }

        private RegionInfo[] regionInfo;
        public RegionInfo[] RegionInfo
        {
            get { return regionInfo; }
            set { regionInfo = value; }
        }

        private String destinationFileName = String.Empty;
        public String DestinationFileName
        {
            get { return destinationFileName; }
            set { destinationFileName = value; }
        }

        public ImageInfo(Image image, RegionInfo[] regionInfo)
        {
            this.image = image;
            this.regionInfo = regionInfo;
        }
    }
}
