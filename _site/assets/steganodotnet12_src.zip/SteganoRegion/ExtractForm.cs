﻿#region Using directives

using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

#endregion

namespace SteganoRegion
{
    partial class ExtractForm : Form
    {
        private System.Windows.Forms.PictureBox picImage;
        private System.Windows.Forms.TextBox txtMessage;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnClose;

        public ExtractForm(ImageInfo imageInfo, String messageText)
        {
            //
            // The InitializeComponent() call is required for Windows Forms designer support.
            //
            InitializeComponent();

            DrawRegions(imageInfo);
            txtMessage.Text = messageText;
        }

        /// <summary>Draw the image and the carrier regions</summary>
        /// <param name="imageInfo">Image and regions</param>
        private void DrawRegions(ImageInfo imageInfo)
        {
            picImage.Image = (Image)imageInfo.Image;
            picImage.Size = picImage.Image.Size;
            Graphics graphics = Graphics.FromImage(picImage.Image);
            
            foreach (RegionInfo info in imageInfo.RegionInfo)
            {
                graphics.FillRegion(new SolidBrush(Color.Red), info.Region);
            }

            graphics.Dispose();
            picImage.Invalidate();
        }

        private void btnClose_Click(object sender, System.EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            Close();
        }
    }
}