﻿#region Using directives

using System;
using System.Windows.Forms;
using System.Text;
using System.IO;

#endregion

namespace SteganoRegion {
    partial class MainForm : Form {
        private System.Windows.Forms.TextBox txtMessageText;
        private System.Windows.Forms.RadioButton rdoPassword;
        private System.Windows.Forms.RadioButton rdoKeyFile;
        private System.Windows.Forms.Panel panelHide;
        private System.Windows.Forms.Label lblImageDstFile;
        private System.Windows.Forms.Button btnImageSrcFile;
        private System.Windows.Forms.RadioButton rdoHide;
        private System.Windows.Forms.Button btnKeyFile;
        private System.Windows.Forms.RadioButton rdoMessageText;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.GroupBox grpImage;
        private System.Windows.Forms.GroupBox grpMessage;
        private System.Windows.Forms.RadioButton rdoExtract;
        private System.Windows.Forms.TextBox txtMessageFile;
        private System.Windows.Forms.Button btnMessageFile;
        private System.Windows.Forms.GroupBox grpSecurity;
        private System.Windows.Forms.RadioButton rdoMessageFile;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtImageDstFile;
        private System.Windows.Forms.Button btnImageDstFile;
        private System.Windows.Forms.TextBox txtKeyFile;
        private System.Windows.Forms.TextBox txtImageSrcFile;
        public MainForm() {
            //
            // The InitializeComponent() call is required for Windows Forms designer support.
            //
            InitializeComponent();
        }

        private void FillFileBox(TextBox txtBox, String filter, bool saveFile) {
            FileDialog dlg;
            if (saveFile) {
                dlg = new SaveFileDialog();
            } else {
                dlg = new OpenFileDialog();
            }
            dlg.Filter = filter;
            if (dlg.ShowDialog() == DialogResult.OK) {
                txtBox.Text = dlg.FileName;
            }
        }

        private void txtKeyFile_TextChanged(object sender, System.EventArgs e) {
            rdoKeyFile.Checked = txtKeyFile.Text.Length > 0;
        }

        private void txtPassword_TextChanged(object sender, System.EventArgs e) {
            rdoPassword.Checked = txtPassword.Text.Length > 0;
        }

        private void txtMessageFile_TextChanged(object sender, System.EventArgs e) {
            rdoMessageFile.Checked = txtMessageFile.Text.Length > 0;
        }

        private void txtMessageText_TextChanged(object sender, System.EventArgs e) {
            rdoMessageText.Checked = txtMessageText.Text.Length > 0;
        }

        private void btnImageSrcFile_Click(object sender, System.EventArgs e) {
            FillFileBox(txtImageSrcFile, "Image Files (*.bmp,*.png,*.gif,*.jpg,*.jpeg,*.tif,*.tiff)|*.bmp;*.png;*.gif;*.jpg;*.jpeg;*.tif;*.tiff", false);
        }

        private void btnKeyFile_Click(object sender, System.EventArgs e) {
            FillFileBox(txtKeyFile, String.Empty, false);
        }

        private void btnMessageFile_Click(object sender, System.EventArgs e) {
            FillFileBox(txtMessageFile, String.Empty, !rdoHide.Checked);
        }

        private void btnImageDstFile_Click(object sender, System.EventArgs e) {
            FillFileBox(txtImageDstFile, "Image Files (*.bmp,*.png,*.tif,*.tiff)|*.bmp;*.png;*.tif;*.tiff", true);
        }

        private void rdoWhatToDo_CheckedChanged(object sender, System.EventArgs e) {
            lblImageDstFile.Enabled = txtImageDstFile.Enabled
                = btnImageDstFile.Enabled = txtMessageText.Enabled = rdoHide.Checked;
        }

        private void btnNext_Click(object sender, System.EventArgs e) {
            bool isOkay = true;
            if (txtImageSrcFile.Text.Length == 0) {
                errors.SetError(txtImageSrcFile, "Please choose a carrier image");
                isOkay = false;
            } else {
                errors.SetError(txtImageSrcFile, String.Empty);
            }

            if (rdoKeyFile.Checked && txtKeyFile.Text.Length == 0) {
                errors.SetError(txtKeyFile, "Please choose a key file or enter a password.");
                isOkay = false;
            } else {
                errors.SetError(txtKeyFile, String.Empty);
            }

            if (rdoPassword.Checked && txtPassword.Text.Length == 0) {
                errors.SetError(txtPassword, "Please enter a password or choose a key file.");
                isOkay = false;
            } else {
                errors.SetError(txtPassword, String.Empty);
            }

            if (rdoHide.Checked) {
                if (txtImageDstFile.Text.Length == 0) {
                    errors.SetError(txtImageDstFile, "Please choose a name for the generated image");
                    isOkay = false;
                } else {
                    errors.SetError(txtImageDstFile, String.Empty);
                }

                if (rdoMessageFile.Checked && txtMessageFile.Text.Length == 0) {
                    errors.SetError(txtMessageFile, "Please choose a message file or enter a text.");
                    isOkay = false;
                } else {
                    errors.SetError(txtMessageFile, String.Empty);
                }

                if (rdoMessageText.Checked && txtMessageText.Text.Length == 0) {
                    errors.SetError(txtMessageText, "Please enter a text or choose a message file.");
                    isOkay = false;
                } else {
                    errors.SetError(txtMessageText, String.Empty);
                }
            }

            if (isOkay) {
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
        }

        public bool HideMessage {
            get { return rdoHide.Checked; }
        }

        public String SourceFileName {
            get { return txtImageSrcFile.Text; }
        }

        public String DestinationFileName {
            get { return txtImageDstFile.Text; }
        }

        public Stream KeyStream {
            get {
                if (rdoKeyFile.Checked) {
                    return new FileStream(txtKeyFile.Text, FileMode.Open);
                } else {
                    return new MemoryStream(Encoding.ASCII.GetBytes(txtPassword.Text));
                }
            }
        }

        public Stream MessageStream {
            get {
                if (rdoMessageFile.Checked) {
                    return new FileStream(txtMessageFile.Text, FileMode.Open);
                } else {
                    return new MemoryStream(Encoding.ASCII.GetBytes(txtMessageText.Text));
                }
            }
        }

        public String MessageDestinationFileName {
            get {
                if (rdoMessageFile.Checked) {
                    return txtMessageFile.Text;
                } else {
                    return String.Empty;
                }
            }
        }
    }
}