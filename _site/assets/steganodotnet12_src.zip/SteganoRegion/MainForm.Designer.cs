﻿namespace SteganoRegion
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtImageSrcFile = new System.Windows.Forms.TextBox();
            this.txtKeyFile = new System.Windows.Forms.TextBox();
            this.btnImageDstFile = new System.Windows.Forms.Button();
            this.txtImageDstFile = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.rdoMessageFile = new System.Windows.Forms.RadioButton();
            this.grpSecurity = new System.Windows.Forms.GroupBox();
            this.rdoKeyFile = new System.Windows.Forms.RadioButton();
            this.btnKeyFile = new System.Windows.Forms.Button();
            this.rdoPassword = new System.Windows.Forms.RadioButton();
            this.btnMessageFile = new System.Windows.Forms.Button();
            this.txtMessageFile = new System.Windows.Forms.TextBox();
            this.rdoExtract = new System.Windows.Forms.RadioButton();
            this.grpMessage = new System.Windows.Forms.GroupBox();
            this.txtMessageText = new System.Windows.Forms.TextBox();
            this.rdoMessageText = new System.Windows.Forms.RadioButton();
            this.grpImage = new System.Windows.Forms.GroupBox();
            this.btnImageSrcFile = new System.Windows.Forms.Button();
            this.lblImageDstFile = new System.Windows.Forms.Label();
            this.btnNext = new System.Windows.Forms.Button();
            this.rdoHide = new System.Windows.Forms.RadioButton();
            this.panelHide = new System.Windows.Forms.Panel();
            this.errors = new System.Windows.Forms.ErrorProvider();
            this.grpSecurity.SuspendLayout();
            this.grpMessage.SuspendLayout();
            this.grpImage.SuspendLayout();
            this.panelHide.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errors)).BeginInit();
            this.SuspendLayout();
// 
// txtImageSrcFile
// 
            this.errors.SetIconAlignment(this.txtImageSrcFile, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.txtImageSrcFile.Location = new System.Drawing.Point(96, 30);
            this.txtImageSrcFile.Name = "txtImageSrcFile";
            this.txtImageSrcFile.Size = new System.Drawing.Size(416, 20);
            this.txtImageSrcFile.TabIndex = 5;
// 
// txtKeyFile
// 
            this.errors.SetIconAlignment(this.txtKeyFile, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.txtKeyFile.Location = new System.Drawing.Point(96, 30);
            this.txtKeyFile.Name = "txtKeyFile";
            this.txtKeyFile.Size = new System.Drawing.Size(416, 20);
            this.txtKeyFile.TabIndex = 11;
            this.txtKeyFile.TextChanged += new System.EventHandler(this.txtKeyFile_TextChanged);
// 
// btnImageDstFile
// 
            this.btnImageDstFile.Location = new System.Drawing.Point(512, 59);
            this.btnImageDstFile.Name = "btnImageDstFile";
            this.btnImageDstFile.Size = new System.Drawing.Size(75, 22);
            this.btnImageDstFile.TabIndex = 8;
            this.btnImageDstFile.Text = "Browse...";
            this.btnImageDstFile.Click += new System.EventHandler(this.btnImageDstFile_Click);
// 
// txtImageDstFile
// 
            this.errors.SetIconAlignment(this.txtImageDstFile, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.txtImageDstFile.Location = new System.Drawing.Point(96, 59);
            this.txtImageDstFile.Name = "txtImageDstFile";
            this.txtImageDstFile.Size = new System.Drawing.Size(416, 20);
            this.txtImageDstFile.TabIndex = 7;
// 
// label1
// 
            this.label1.Location = new System.Drawing.Point(16, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 21);
            this.label1.TabIndex = 10;
            this.label1.Text = "Image File:";
// 
// txtPassword
// 
            this.errors.SetIconAlignment(this.txtPassword, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.txtPassword.Location = new System.Drawing.Point(96, 59);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(416, 20);
            this.txtPassword.TabIndex = 14;
            this.txtPassword.Text = "test";
            this.txtPassword.TextChanged += new System.EventHandler(this.txtPassword_TextChanged);
// 
// rdoMessageFile
// 
            this.rdoMessageFile.Location = new System.Drawing.Point(16, 30);
            this.rdoMessageFile.Name = "rdoMessageFile";
            this.rdoMessageFile.Size = new System.Drawing.Size(88, 22);
            this.rdoMessageFile.TabIndex = 16;
            this.rdoMessageFile.Text = "Message File";
// 
// grpSecurity
// 
            this.grpSecurity.Controls.Add(this.rdoKeyFile);
            this.grpSecurity.Controls.Add(this.txtKeyFile);
            this.grpSecurity.Controls.Add(this.btnKeyFile);
            this.grpSecurity.Controls.Add(this.txtPassword);
            this.grpSecurity.Controls.Add(this.rdoPassword);
            this.grpSecurity.Location = new System.Drawing.Point(8, 111);
            this.grpSecurity.Name = "grpSecurity";
            this.grpSecurity.Size = new System.Drawing.Size(608, 97);
            this.grpSecurity.TabIndex = 9;
            this.grpSecurity.TabStop = false;
            this.grpSecurity.Text = "Security";
// 
// rdoKeyFile
// 
            this.rdoKeyFile.Location = new System.Drawing.Point(16, 30);
            this.rdoKeyFile.Name = "rdoKeyFile";
            this.rdoKeyFile.Size = new System.Drawing.Size(72, 22);
            this.rdoKeyFile.TabIndex = 10;
            this.rdoKeyFile.Text = "Key File";
// 
// btnKeyFile
// 
            this.btnKeyFile.Location = new System.Drawing.Point(512, 30);
            this.btnKeyFile.Name = "btnKeyFile";
            this.btnKeyFile.Size = new System.Drawing.Size(75, 21);
            this.btnKeyFile.TabIndex = 12;
            this.btnKeyFile.Text = "Browse...";
            this.btnKeyFile.Click += new System.EventHandler(this.btnKeyFile_Click);
// 
// rdoPassword
// 
            this.rdoPassword.Checked = true;
            this.rdoPassword.Location = new System.Drawing.Point(16, 59);
            this.rdoPassword.Name = "rdoPassword";
            this.rdoPassword.Size = new System.Drawing.Size(72, 23);
            this.rdoPassword.TabIndex = 13;
            this.rdoPassword.TabStop = true;
            this.rdoPassword.Text = "Password";
// 
// btnMessageFile
// 
            this.btnMessageFile.Location = new System.Drawing.Point(512, 30);
            this.btnMessageFile.Name = "btnMessageFile";
            this.btnMessageFile.Size = new System.Drawing.Size(75, 21);
            this.btnMessageFile.TabIndex = 18;
            this.btnMessageFile.Text = "Browse...";
            this.btnMessageFile.Click += new System.EventHandler(this.btnMessageFile_Click);
// 
// txtMessageFile
// 
            this.errors.SetIconAlignment(this.txtMessageFile, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.txtMessageFile.Location = new System.Drawing.Point(104, 30);
            this.txtMessageFile.Name = "txtMessageFile";
            this.txtMessageFile.Size = new System.Drawing.Size(408, 20);
            this.txtMessageFile.TabIndex = 17;
            this.txtMessageFile.TextChanged += new System.EventHandler(this.txtMessageFile_TextChanged);
// 
// rdoExtract
// 
            this.rdoExtract.Location = new System.Drawing.Point(208, 15);
            this.rdoExtract.Name = "rdoExtract";
            this.rdoExtract.Size = new System.Drawing.Size(144, 22);
            this.rdoExtract.TabIndex = 2;
            this.rdoExtract.Text = "Extract a Message";
            this.rdoExtract.CheckedChanged += new System.EventHandler(this.rdoWhatToDo_CheckedChanged);
// 
// grpMessage
// 
            this.grpMessage.Controls.Add(this.rdoMessageFile);
            this.grpMessage.Controls.Add(this.txtMessageFile);
            this.grpMessage.Controls.Add(this.btnMessageFile);
            this.grpMessage.Controls.Add(this.txtMessageText);
            this.grpMessage.Controls.Add(this.rdoMessageText);
            this.grpMessage.Location = new System.Drawing.Point(8, 215);
            this.grpMessage.Name = "grpMessage";
            this.grpMessage.Size = new System.Drawing.Size(608, 186);
            this.grpMessage.TabIndex = 15;
            this.grpMessage.TabStop = false;
            this.grpMessage.Text = "Message";
// 
// txtMessageText
// 
            this.errors.SetIconAlignment(this.txtMessageText, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.txtMessageText.Location = new System.Drawing.Point(104, 59);
            this.txtMessageText.Multiline = true;
            this.txtMessageText.Name = "txtMessageText";
            this.txtMessageText.Size = new System.Drawing.Size(408, 112);
            this.txtMessageText.TabIndex = 20;
            this.txtMessageText.Text = "test";
            this.txtMessageText.TextChanged += new System.EventHandler(this.txtMessageText_TextChanged);
// 
// rdoMessageText
// 
            this.rdoMessageText.Checked = true;
            this.rdoMessageText.Location = new System.Drawing.Point(16, 59);
            this.rdoMessageText.Name = "rdoMessageText";
            this.rdoMessageText.Size = new System.Drawing.Size(88, 23);
            this.rdoMessageText.TabIndex = 19;
            this.rdoMessageText.TabStop = true;
            this.rdoMessageText.Text = "Text";
// 
// grpImage
// 
            this.grpImage.Controls.Add(this.label1);
            this.grpImage.Controls.Add(this.txtImageSrcFile);
            this.grpImage.Controls.Add(this.btnImageSrcFile);
            this.grpImage.Controls.Add(this.txtImageDstFile);
            this.grpImage.Controls.Add(this.lblImageDstFile);
            this.grpImage.Controls.Add(this.btnImageDstFile);
            this.grpImage.Location = new System.Drawing.Point(8, 7);
            this.grpImage.Name = "grpImage";
            this.grpImage.Size = new System.Drawing.Size(608, 93);
            this.grpImage.TabIndex = 4;
            this.grpImage.TabStop = false;
            this.grpImage.Text = "Image";
// 
// btnImageSrcFile
// 
            this.btnImageSrcFile.Location = new System.Drawing.Point(512, 30);
            this.btnImageSrcFile.Name = "btnImageSrcFile";
            this.btnImageSrcFile.Size = new System.Drawing.Size(75, 21);
            this.btnImageSrcFile.TabIndex = 6;
            this.btnImageSrcFile.Text = "Browse...";
            this.btnImageSrcFile.Click += new System.EventHandler(this.btnImageSrcFile_Click);
// 
// lblImageDstFile
// 
            this.lblImageDstFile.Location = new System.Drawing.Point(16, 59);
            this.lblImageDstFile.Name = "lblImageDstFile";
            this.lblImageDstFile.Size = new System.Drawing.Size(80, 22);
            this.lblImageDstFile.TabIndex = 22;
            this.lblImageDstFile.Text = "Save As:";
// 
// btnNext
// 
            this.btnNext.Location = new System.Drawing.Point(565, 470);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(75, 22);
            this.btnNext.TabIndex = 21;
            this.btnNext.Text = "Next >>";
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
// 
// rdoHide
// 
            this.rdoHide.Checked = true;
            this.rdoHide.Location = new System.Drawing.Point(64, 15);
            this.rdoHide.Name = "rdoHide";
            this.rdoHide.Size = new System.Drawing.Size(144, 22);
            this.rdoHide.TabIndex = 1;
            this.rdoHide.TabStop = true;
            this.rdoHide.Text = "Hide a Message";
            this.rdoHide.CheckedChanged += new System.EventHandler(this.rdoWhatToDo_CheckedChanged);
// 
// panelHide
// 
            this.panelHide.Controls.Add(this.grpImage);
            this.panelHide.Controls.Add(this.grpMessage);
            this.panelHide.Controls.Add(this.grpSecurity);
            this.panelHide.Location = new System.Drawing.Point(16, 51);
            this.panelHide.Name = "panelHide";
            this.panelHide.Size = new System.Drawing.Size(624, 409);
            this.panelHide.TabIndex = 3;
// 
// errors
// 
            this.errors.ContainerControl = this;
// 
// MainForm
// 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(655, 499);
            this.Controls.Add(this.panelHide);
            this.Controls.Add(this.rdoExtract);
            this.Controls.Add(this.rdoHide);
            this.Controls.Add(this.btnNext);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "MainForm";
            this.Text = "Step 1 - Select Files";
            this.grpSecurity.ResumeLayout(false);
            this.grpSecurity.PerformLayout();
            this.grpMessage.ResumeLayout(false);
            this.grpMessage.PerformLayout();
            this.grpImage.ResumeLayout(false);
            this.grpImage.PerformLayout();
            this.panelHide.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.errors)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ErrorProvider errors;
    }
}