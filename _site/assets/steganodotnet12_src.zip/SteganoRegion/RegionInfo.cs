﻿/* This class has been written by
 * Corinna John (Hannover, Germany)
 * cj@binary-universe.net
 * 
 * You may do with this code whatever you like,
 * except selling it or claiming any rights/ownership.
 * 
 * Please send me a little feedback about what you're
 * using this code for and what changes you'd like to
 * see in later versions. (And please excuse my bad english.)
 * 
 * WARNING: This is experimental code.
 * Some bugs and flaws have been left in there,
 * to keep the code readable to people who want
 * to understand the algorithm.
 * Please do not expect "Release Quality".
 * */

#region Using directives

using System;
using System.Collections;
using System.Drawing;
using System.Drawing.Drawing2D;

#endregion

namespace SteganoRegion
{
    public class RegionInfo
    {
        private Region region;
        private Point[] points;
        private ArrayList pixels = new ArrayList();
        private Size imageSize;
        private int capacity = 1;
        private byte countUsedBitsPerPixel = 1;

        public Region Region
        {
            get { return region; }
        }

        public Point[] Points
        {
            get { return points; }
        }

        public int Capacity
        {
            get { return capacity; }
            set { capacity = value; }
        }

        public byte CountUsedBitsPerPixel
        {
            get { return countUsedBitsPerPixel; }
            set { countUsedBitsPerPixel = value; }
        }

        public long CountPixels
        {
            get { return pixels.Count; }
        }

        public ArrayList PixelIndices
        {
            get { return pixels; }
        }

        public decimal PercentOfImage
        {
            get
            {
                return (100 * (decimal)pixels.Count / (imageSize.Width * imageSize.Height));
            }
        }

        public RegionInfo(GraphicsPath path, Point[] points, Size imageSize)
        {
            this.region = new Region(path);
            this.points = points;
            this.imageSize = imageSize;
            UpdateCountPixels();
        }

        public RegionInfo(Region region, int capacity, byte bitsPerPixel, Size imageSize)
        {
            this.region = region;
            this.capacity = capacity;
            this.countUsedBitsPerPixel = bitsPerPixel;
            this.imageSize = imageSize;
            UpdateCountPixels();
        }

        public void AddPoints(Point[] addPoints)
        {
            Point[] newPoints = new Point[points.Length + addPoints.Length];
            points.CopyTo(newPoints, 0);
            addPoints.CopyTo(newPoints, points.Length);
            points = newPoints;
        }

        /*public void UpdateCountPixels(GraphicsPath path)
        {
            pixels.Clear();
            RectangleF box = path.GetBounds();
            for (int y = (int)box.Top; y < box.Bottom; y++)
            {
                for (int x = (int)box.Left; x < box.Right; x++)
                {
                    if (path.IsVisible(x, y))
                    {
                        pixels.Add(GetPixelIndex(x, y)); //new Point(x,y));
                    }
                }
            }
            pixels.Sort();
        }*/

        public void UpdateCountPixels()
        {
            pixels.Clear();
            for (int y = 0; y < imageSize.Height; y++)
            {
                for (int x = 0; x < imageSize.Width; x++)
                {
                    if (region.IsVisible(x, y))
                    {
                        pixels.Add(GetPixelIndex(x, y)); //new Point(x,y));
                    }
                }
            }
            pixels.Sort();
        }

        /*public void UpdateCountPixels(Graphics graphics)
        {
            pixels.Clear();
            RectangleF box = region.GetBounds(graphics);
            for (int y = (int)box.Top; y < box.Bottom; y++)
            {
                for (int x = (int)box.Left; x < box.Right; x++)
                {
                    if (region.IsVisible(x, y))
                    {
                        pixels.Add(GetPixelIndex(x, y)); //new Point(x,y));
                    }
                }
            }
            pixels.Sort();
        }*/

        private int GetPixelIndex(int x, int y)
        {
            return x + (y * imageSize.Width);
        }

    }
}
