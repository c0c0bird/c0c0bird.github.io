import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import javax.swing.*;
import org.apache.batik.anim.dom.SVGDOMImplementation;
import org.apache.batik.svggen.SVGGraphics2D;
import org.apache.batik.swing.JSVGCanvas;
import org.apache.batik.swing.gvt.*;
import org.apache.batik.swing.svg.*;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.svg.SVGDocument;

/**
 * 
 */

/**
 * @author coco
 *
 */
public class ChartFrame extends JFrame {
	private static final long serialVersionUID = 1L;
	
	private final int boxSize = 15;
	private final int boxPadding = 2;
	private int countColumns;
	private int countRows;
	private String titleText;

    // The SVG canvas.
    protected JSVGCanvas svgCanvas = new JSVGCanvas();

    public ChartFrame(){
        // Add components to the frame.
        this.add(createComponents());

        // Display the frame.
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
    
    public void drawChart(String title, String base4Digits){
    	titleText = title;
    	
    	DOMImplementation impl = SVGDOMImplementation.getDOMImplementation();
    	String svgNS = SVGDOMImplementation.SVG_NAMESPACE_URI;
    	SVGDocument doc = (SVGDocument) impl.createDocument(svgNS, "svg", null);
    	SVGGraphics2D g = new SVGGraphics2D(doc);
    	g.setFont(new Font("sans serif", Font.PLAIN, 10));
    	
    	// count columns = row numbers + edges + (symbols for each digit)
    	countColumns = getCountCols(base4Digits);
    	countRows = (int)(200 / boxSize);
    	svgCanvas.setSize((2+countColumns)*boxSize, countRows*boxSize);
    	
    	g.setPaint(Color.darkGray);
    	g.fillRect(0, 0, svgCanvas.getWidth(), svgCanvas.getHeight());
    	
    	for(int y = 0; y < (countRows-2); y+=2){
	    	drawOddRow(y, base4Digits, g);
	    	drawEvenRow(y+1, base4Digits, g);	    	
	    }
    	
    	for(int x=0; x<countColumns; x++){
    		drawColNumber(x+1, countRows-1, g);
    	}
    	
    	titleText = titleText + " - " + "start with " + (base4Digits.length()+2) + " stitches";
    	
    	g.getRoot(doc.getDocumentElement());
    	svgCanvas.setSVGDocument(doc);
    	svgCanvas.getParent().setPreferredSize(svgCanvas.getSize());
    	pack();
    	setVisible(true);
    }
    
    private int getCountCols(String base4Digits){
    	int count = 2;
    	
    	for(int n=0; n<base4Digits.length(); n++){
    		char currentChar = base4Digits.charAt(n);
    		
    		switch(currentChar){
	    		case '0':	
	    		case '1': count += 1;
	    				  break;
	    		case '2':
	    		case '3': count += 2;
	    				  break;
    		}
    	}
    	
    	return count;
    }
    
    private void drawOddRow(int y, String base4Digits, SVGGraphics2D g){
    	int x = 0;
    	
    	drawRowNumber(x, y, g);
    	x++;
    	
    	// left edge
    	drawKnit(x, y, g);
    	x++;
    	
    	for(int n=0; n<base4Digits.length(); n++){
    		char currentChar = base4Digits.charAt(n);
    		
    		/* draw box
    		   0 = knit
			   1 = purl
			   2 = yarn over, knit
			   3 = yarn over, purl
			*/
    		switch(currentChar){
	    		case '0': drawKnit(x, y, g); break;
	    		case '1': drawPurl(x, y, g); break;
	    		case '2': drawYarnOver(x, y, g);
	    				  drawKnit(++x, y, g);
	    		          break;
	    		case '3': drawYarnOver(x, y, g);
	    				  drawPurl(++x, y, g);
	    				  break;
    		}
    		
    		x++;
    	}

    	// right edge
    	drawKnit(x, y, g);
    }

    private void drawEvenRow(int y, String base4Digits, SVGGraphics2D g){
    	int x = 1;
    	
    	// left edge
    	drawPurl(x, y, g);
    	x++;
    	
    	for(int n=0; n<base4Digits.length(); n++){
    		char currentChar = base4Digits.charAt(n);
    		
    		/* draw box
    		   0 = purl
			   1 = knit
			   2 = knit 2 together, purl
			   3 = knit 2 together, knit
			*/
    		switch(currentChar){
	    		case '0': drawPurl(x, y, g); break;
	    		case '1': drawKnit(x, y, g); break;
	    		case '2': drawK2tog(x, y, g);
	    				  drawPurl(++x, y, g);
	    				  break;
	    		case '3': drawK2tog(x, y, g);
				  		  drawKnit(++x, y, g);
				  		  break;
    		}
    		
    		x++;
    	}

    	// right edge
    	drawPurl(x, y, g);
    	x++;
    	
    	drawRowNumber(x, y, g);
    }
    
    private void drawBox(int col, int row, SVGGraphics2D g){
    	int x = col*boxSize;
    	int y = row*boxSize;
    	Rectangle2D.Double box = new Rectangle2D.Double(x, y, boxSize, boxSize);
    	
    	g.fill(box);    	
    	g.setColor(Color.black);
    	g.draw(box);
    }
    
    private void drawColNumber(int col, int row, SVGGraphics2D g){
    	g.setColor(Color.black);
    	g.setPaint(Color.cyan);
    	drawBox(col, row, g);
    	g.drawString(String.valueOf(col), (col*boxSize)+boxPadding, (row*boxSize)+boxSize-boxPadding);
    }
    
    private void drawRowNumber(int col, int row, SVGGraphics2D g){
    	g.setColor(Color.black);
    	g.setPaint(Color.green);
    	drawBox(col, row, g);
		g.drawString(String.valueOf(row+1), (col*boxSize)+boxPadding, (row*boxSize)+boxSize-boxPadding);
    }
    
    private void drawKnit(int col, int row, SVGGraphics2D g){
    	g.setColor(Color.black);
    	g.setPaint(Color.white);
    	drawBox(col, row, g);
    }
    
    private void drawPurl(int col, int row, SVGGraphics2D g){
    	g.setColor(Color.black);
    	g.setPaint(Color.lightGray);
    	drawBox(col, row, g);
    }
    
    private void drawYarnOver(int col, int row, SVGGraphics2D g){
    	g.setColor(Color.black);
    	g.setPaint(Color.white);
    	
    	int x = col*boxSize;
    	int y = row*boxSize;
    	int height = boxSize-(boxPadding*2);
    	
    	Ellipse2D circle = new Ellipse2D.Double(
    						x+boxPadding, 
    						y+boxPadding, 
    						height,
    						height);
    	
    	drawBox(col, row, g);
    	g.draw(circle);
    }

    private void drawK2tog(int col, int row, SVGGraphics2D g){
    	g.setColor(Color.black);
    	g.setPaint(Color.white);
    	
    	int x = col*boxSize;
    	int y = row*boxSize;
    	int innerHeight = boxSize-(boxPadding*2);
    	
    	Line2D line = new Line2D.Double(
    						x+innerHeight+boxPadding,
    						y+boxPadding,
    						x+boxPadding,
    						y+innerHeight+boxPadding);
    	
    	drawBox(col, row, g);
    	g.draw(line);
    }
    
    private void drawK1tbl(int col, int row, SVGGraphics2D g){
    	g.setColor(Color.black);
    	g.setPaint(Color.white);
    	
    	int x = col*boxSize;
    	int y = row*boxSize;
    	int innerHeight = boxSize-(boxPadding*2);
    	
    	Line2D line = new Line2D.Double(
    						x+boxPadding,
    						y+innerHeight+boxPadding,
    						x+innerHeight+boxPadding,
    						y+innerHeight+boxPadding);
    	
    	Ellipse2D circle = new Ellipse2D.Double(
    						x+boxPadding+((float)innerHeight/4),
    						y+boxPadding,
    						(float)innerHeight/2,
    						innerHeight - boxPadding); 
    	
    	drawBox(col, row, g);
       	g.draw(line);
       	g.draw(circle);
    }
    
	public JComponent createComponents() {
        // Create a panel and add the button, status label and the SVG canvas.
        final JPanel panel = new JPanel(new BorderLayout());
        panel.add("Center", svgCanvas);
        
        svgCanvas.addGVTTreeBuilderListener(new GVTTreeBuilderAdapter() {
            public void gvtBuildStarted(GVTTreeBuilderEvent e) {
                setTitle("Build Started...");
            }
            public void gvtBuildCompleted(GVTTreeBuilderEvent e) {
            	setTitle("Build Done.");
                pack();
            }
        });

        svgCanvas.addGVTTreeRendererListener(new GVTTreeRendererAdapter() {
            public void gvtRenderingPrepare(GVTTreeRendererEvent e) {
            	setTitle("Rendering Started...");
            }
            public void gvtRenderingCompleted(GVTTreeRendererEvent e) {
            	setTitle(titleText);
            }
        });

        return panel;
    }
}
