import java.nio.*;
import java.nio.charset.*;

public class SteganoYarn {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//ChartFrame frame = new ChartFrame();
		//frame.setVisible(true);
		
		
		
		if(args.length > 1) {
			String command = args[0];
			
			if(command.equals("-e")){
				encode(args[1]);
			}else if(command.equals("-d")){
				decode(args[1]);
			}else{
				printUsage();
			}
			
		}else{
			printUsage();
		}
	}
	
	private static void encode(String clearText){
		ByteBuffer bytes = Charset.forName("ISO-8859-15").encode(clearText);
		StringBuilder resultBuilder = new StringBuilder(clearText.length() * 4);

		while(bytes.hasRemaining()){
			int currentValue = bytes.get();			
			String currentWord = Integer.toString(currentValue, 4);
			
			while(currentWord.length() < 4){
				currentWord = "0" + currentWord;
			}
			
			resultBuilder.append(currentWord);
		}
		
		System.out.println(resultBuilder.toString());
		
		ChartFrame frame = new ChartFrame();
		frame.drawChart(clearText, resultBuilder.toString());
	}
	
	private static void decode(String encodedText){
		int n = 0;
		StringBuilder resultBuilder = new StringBuilder(encodedText);

		while(n < resultBuilder.length()){
			String currentWord = resultBuilder.substring(n, n+4);
			
			int currentValue = Integer.parseInt(currentWord, 4);
			String currentClearChar;
			
			if(currentValue < 256){
				ByteBuffer buffer = ByteBuffer.wrap(new byte[]{(byte)currentValue});
				currentClearChar = Charset.forName("ISO-8859-15").decode(buffer).toString();
			}else{
				currentClearChar = "?";
			}
					
			resultBuilder.replace(n, n+4, currentClearChar);
			n++;
		}
		
		System.out.println(resultBuilder.toString());
	}
	
	private static void printUsage(){
		System.out.println("Usage: SteganoYarn -e|-d TEXT");
		System.out.println("Example: SteganoYarn -e \"your plain text\"");
		System.out.println("Example: SteganoYarn -d \"lrllrlrrl\"");
	}

}
