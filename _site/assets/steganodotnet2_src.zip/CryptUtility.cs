/*
 * This class has been written by
 * Corinna John (Hannover, Germany)
 * picturekey@binary-universe.net
 * 
 * You can use the code in any context you like,
 * as long as you do not delete this comment.
 * 
 * Please send me a little feedback about what you're
 * using this code for and what changes you'd like to
 * see in later versions. (And please excuse the bad english)
 * */

using System;
using System.Drawing;
using System.Windows.Forms;
using System.Text;
using System.IO;

namespace PictureKey {

	public class CryptUtility {

		/// <summary>Hides a message in a bitmap</summary>
		/// <param name="messageStream">The message to hide</param>
		/// <param name="bitmap">The carrier bitmap</param>
		/// <param name="keyStream">The key to use</param>
		public static void HideMessageInBitmap(Stream messageStream, CarrierImage[] imageFiles, FilePasswordPair[] keys){
			HideOrExtract(ref messageStream, imageFiles, keys, false);
			messageStream = null;
		}

		/// <summary>Extracts an hidden message from a bitmap</summary>
		/// <param name="bitmap">The carrier bitmap</param>
		/// <param name="keyStream">The key used for hiding the message</param>
		/// <param name="messageStream">Empty stream to receive the message</param>
		public static void ExtractMessageFromBitmap(CarrierImage[] imageFiles, FilePasswordPair[] keys, ref Stream messageStream){
			HideOrExtract(ref messageStream, imageFiles, keys, true);
		}

		/// <summary>Stepts through the pixels of a bitmap using a key pattern and hides or extracts a message</summary>
		/// <param name="messageStream">If exctract is false, the message to hide - otherwise an empty stream to receive the extracted message</param>
		/// <param name="bitmap">The carrier bitmap</param>
		/// <param name="keyStream">The key specifying the unchanged pixels between two hidden bytes</param>
		/// <param name="extract">Extract a hidden message (true), or hide a message in a clean carrier bitmap (false)</param>
		private static void HideOrExtract(ref Stream messageStream, CarrierImage[] imageFiles, FilePasswordPair[] keys, bool extract){
			//Current count of pixels between two hidden message-bytes
			//Changes with every hidden byte according to the key
			int currentStepWidth = 0;
			//Current byte in the key stream - normal direction
			byte currentKeyByte;
			//Current byte in the key stream - reverse direction
			byte currentReverseKeyByte;
			//current position in the key stream
			long keyPosition;
			//index for imageFiles
			int indexBitmaps = 0;
			
			//load all bitmaps and count available pixels
			Bitmap[] bitmaps = new Bitmap[imageFiles.Length];
			long countPixels = 0;
			for(indexBitmaps=0; indexBitmaps<imageFiles.Length; indexBitmaps++){
				bitmaps[indexBitmaps] = new Bitmap(imageFiles[indexBitmaps].sourceFileName);
				countPixels += imageFiles[indexBitmaps].countPixels;
			}
			indexBitmaps = 0;

			//maximum X and Y position in the current bitmap
			int bitmapWidth = bitmaps[0].Width-1;
			int bitmapHeight = bitmaps[0].Height-1;

			//Color component to hide the next byte in (0-R, 1-G, 2-B)
			//Rotates with every hidden byte
			int currentColorComponent = 0;
			
			//Stores the color of a pixel
			Color pixelColor;
			
			//Length of the message
			Int32 messageLength;

			//combine all keys
			Stream keyStream = GetKeyStream(keys);

			if(extract){
				//Read the length of the hidden message from the first pixel
				pixelColor = bitmaps[0].GetPixel(0,0);
				messageLength = (pixelColor.R << 16) + (pixelColor.G << 8) + pixelColor.B;
				messageStream = new MemoryStream(messageLength);
			}else{
				
				messageLength = (Int32)messageStream.Length;

				if(messageStream.Length >= 16777215){ //The message is too long
					String exceptionMessage = "The message is too long, only 16777215 bytes are allowed.";
					throw new Exception(exceptionMessage);
				}
			}

			//calculate count of message-bytes to hide in (or extract from) each image
			long sumBytes = 0;
			for(int n=0; n<imageFiles.Length; n++){
				float pixels = (float)imageFiles[n].countPixels / (float)countPixels;
				imageFiles[n].messageBytesToHide = (long)Math.Ceiling( (float)messageLength * pixels );
				sumBytes += imageFiles[n].messageBytesToHide;
			}
			if(sumBytes > messageLength){
				//correct Math.Ceiling effects
				imageFiles[imageFiles.Length-1].messageBytesToHide -= (sumBytes - messageLength);
			}

			if( ! extract){
				
				//Check size of the carrier image

				long countRequiredPixels;
				int readByte;
				String errorMessage = String.Empty;
				for(int n=0; n<imageFiles.Length; n++){
					//One pixel of the first image is used for the message's length
					countRequiredPixels = (n==0)?1:0;

					//Count pixels
					for(int countBytes=0; countBytes<imageFiles[n].messageBytesToHide; countBytes++){
						readByte = keyStream.ReadByte();
						if(readByte < 0){
							keyStream.Seek(0, SeekOrigin.Begin);
							readByte = keyStream.ReadByte();
						}
						countRequiredPixels += readByte;
					}

					if(countRequiredPixels > imageFiles[n].countPixels){
						errorMessage += "The images "+imageFiles[n].sourceFileName+" is too small for this message and key. "+countRequiredPixels+" pixels are required.\n";
					}
				}

				if(errorMessage.Length > 0){
					//One or more images are too small
					throw new Exception(errorMessage);
				}
				
				//Write length of the bitmap into the first pixel
				int colorValue = messageLength;
				int red = colorValue >> 16;
				colorValue -= red << 16;
				int green = colorValue >> 8;
				int blue = colorValue - (green << 8);
				pixelColor = Color.FromArgb(red, green, blue);
				bitmaps[0].SetPixel(0,0, pixelColor);
			}

			//Reset the streams
			keyStream.Seek(0, SeekOrigin.Begin);
			messageStream.Seek(0, SeekOrigin.Begin);

			//Current position in the carrier bitmap
			//Start with 1, because (0,0) contains the message length
			Point pixelPosition = new Point(1,0);

			//Count of bytes already hidden in the current image
			int countBytesInCurrentImage = 0;

			//Loop over the message and hide each byte
			for(int messageIndex=0; messageIndex<messageLength; messageIndex++){
				
				//Repeat the key, if it is shorter than the message
				if(keyStream.Position == keyStream.Length){
					keyStream.Seek(0, SeekOrigin.Begin);
				}
				//Get the next pixel-count from the key, use "1" if it's 0
				currentKeyByte = (byte)keyStream.ReadByte();
				currentStepWidth = (currentKeyByte==0) ? (byte)1 : currentKeyByte;

				//jump to reverse-read position and read from the end of the stream
				keyPosition = keyStream.Position;
				keyStream.Seek(-keyPosition, SeekOrigin.End);
				currentReverseKeyByte = (byte)keyStream.ReadByte();
				//jump back to normal read position
				keyStream.Seek(keyPosition, SeekOrigin.Begin);
				
				//Perform line breaks, if current step is wider than the image
				while(currentStepWidth > bitmapWidth){
					currentStepWidth -= bitmapWidth;
					pixelPosition.Y++;
				}
				
				//Move X-position
				if((bitmapWidth - pixelPosition.X) < currentStepWidth){
					pixelPosition.X = currentStepWidth - (bitmapWidth - pixelPosition.X);	
					pixelPosition.Y++;
				}else{
					pixelPosition.X += currentStepWidth;
				}
				
				//Proceed to the next bitmap
				if(countBytesInCurrentImage == imageFiles[indexBitmaps].messageBytesToHide){
					indexBitmaps++;
					pixelPosition.Y = 0;
					countBytesInCurrentImage = 0;
					bitmapWidth = bitmaps[indexBitmaps].Width-1;
					bitmapHeight = bitmaps[indexBitmaps].Height-1;
					if(pixelPosition.X > bitmapWidth){ pixelPosition.X = 0; }
				}
				countBytesInCurrentImage++;
			
				//Get color of the "clean" pixel
				pixelColor = bitmaps[indexBitmaps].GetPixel(pixelPosition.X, pixelPosition.Y);

				if(extract){
					//Extract the hidden message-byte from the color
					byte foundByte = (byte)(currentReverseKeyByte ^ GetColorComponent(pixelColor, currentColorComponent));
					messageStream.WriteByte(foundByte);
					//Rotate color components
					currentColorComponent = (currentColorComponent==2) ? 0 : (currentColorComponent+1);

				}else{
					//To add a bit of confusion, xor the byte with a byte read from the keyStream
					int currentByte = messageStream.ReadByte() ^ currentReverseKeyByte;
					
					if(imageFiles[indexBitmaps].useGrayscale){
						pixelColor = Color.FromArgb(currentByte, currentByte, currentByte);
					}else{
						//Change one component of the color to the message-byte
						SetColorComponent(ref pixelColor, currentColorComponent, currentByte);
						//Rotate color components
						currentColorComponent = (currentColorComponent==2) ? 0 : (currentColorComponent+1);
					}
					bitmaps[indexBitmaps].SetPixel(pixelPosition.X, pixelPosition.Y, pixelColor);
				}
			}

			for(indexBitmaps=0; indexBitmaps<bitmaps.Length; indexBitmaps++){
				if( ! extract ){
					SaveBitmap( bitmaps[indexBitmaps], imageFiles[indexBitmaps].resultFileName );
				}
				bitmaps[indexBitmaps].Dispose();
			}
			keyStream.Close();
		}

		/// <summary>Return one component of a color</summary>
		/// <param name="pixelColor">The Color</param>
		/// <param name="colorComponent">The component to return (0-R, 1-G, 2-B)</param>
		/// <returns>The requested component</returns>
		private static byte GetColorComponent(Color pixelColor, int colorComponent){
			byte returnValue = 0;
			switch(colorComponent){
				case 0:
					returnValue = pixelColor.R;
					break;
				case 1:
					returnValue = pixelColor.G;
					break;
				case 2:
					returnValue = pixelColor.B;
					break;
			}
			return returnValue;
		}

		/// <summary>Changees one component of a color</summary>
		/// <param name="pixelColor">The Color</param>
		/// <param name="colorComponent">The component to change (0-R, 1-G, 2-B)</param>
		/// <param name="newValue">New value of the component</param>
		private static void SetColorComponent(ref Color pixelColor, int colorComponent, int newValue){
			switch(colorComponent){
				case 0:
					pixelColor = Color.FromArgb(newValue, pixelColor.G, pixelColor.B);
					break;
				case 1:
					pixelColor = Color.FromArgb(pixelColor.R, newValue, pixelColor.B);
					break;
				case 2:
					pixelColor = Color.FromArgb(pixelColor.R, pixelColor.G, newValue);
					break;
			}
		}

		private static String UnTrimColorString(String color, int desiredLength){
			int difference = desiredLength - color.Length;
			if(difference > 0){
				color = new String('0', difference) + color;
			}
			return color;
		}


		private static void SaveBitmap(Bitmap bitmap, String fileName){
			String fileNameLower = fileName.ToLower();
			
			System.Drawing.Imaging.ImageFormat format = System.Drawing.Imaging.ImageFormat.Bmp;			
			if((fileNameLower.EndsWith("tif"))||(fileNameLower.EndsWith("tiff"))){
				format = System.Drawing.Imaging.ImageFormat.Tiff;
			}else if(fileNameLower.EndsWith("png")){
				format = System.Drawing.Imaging.ImageFormat.Png;
			}
				
			//copy the bitmap
			Image img = new Bitmap(bitmap);
				
			//close bitmap file
			bitmap.Dispose();
			//save new bitmap
			img.Save(fileName, format);
			img.Dispose();
		}

		//--------------------------------------------- combining the keys

		/// <summary>Combines key file and password using XOR</summary>
		/// <param name="key">The key/password pair to combine</param>
		/// <returns>The stream created from key and password</returns>
		public static MemoryStream CreateKeyStream(FilePasswordPair key){
			FileStream fileStream = new FileStream(key.fileName, FileMode.Open);
			MemoryStream resultStream = new MemoryStream();
			int passwordIndex = 0;
			int currentByte = 0;

			while( (currentByte = fileStream.ReadByte()) >= 0 ){
				//combine the key-byte with the corresponding password-byte
				currentByte = currentByte ^ key.password[passwordIndex];

				//add the result to the key stream
				resultStream.WriteByte((byte)currentByte);

				//proceed to the next letter or repeat the password
				passwordIndex++;
				if(passwordIndex == key.password.Length){
					passwordIndex = 0;
				}
			}

			fileStream.Close();

			resultStream.Seek(0, SeekOrigin.Begin);
			return resultStream;
		}

		/// <summary>Combines all key files and passwords into one key stream</summary>
		/// <param name="keys">The keys to combine</param>
		/// <returns>The resulting key stream</returns>
		private static MemoryStream GetKeyStream(FilePasswordPair[] keys){
			//Xor the keys an their passwords
			MemoryStream[] keyStreams = new MemoryStream[keys.Length];
			for(int n=0; n<keys.Length; n++){
				keyStreams[n] = CreateKeyStream(keys[n]);				
			}
			
			//Buffer for the resulting stream
			MemoryStream resultKeyStream = new MemoryStream();

			//Find length of longest stream
			long maxLength = 0;
			foreach(MemoryStream stream in keyStreams){
				if( stream.Length > maxLength ){
					maxLength = stream.Length;
				}
			}
			
			int readByte = 0;
			for(long n=0; n<=maxLength; n++){
				for(int streamIndex=0; streamIndex<keyStreams.Length; streamIndex++){
					if(keyStreams[streamIndex] != null){
						readByte = keyStreams[streamIndex].ReadByte();
						if(readByte < 0){
							//end of stream - close the file
							//the last loop (n==maxLength) will close the last stream
							keyStreams[streamIndex].Close();
							keyStreams[streamIndex] = null;
						}else{
							//copy a byte into the result key
							resultKeyStream.WriteByte( (byte)readByte );
						}
					}
				}
			}
			
			return resultKeyStream;
		}

	}
}
