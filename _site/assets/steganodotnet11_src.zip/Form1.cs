using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Text;

namespace SteganoPalette
{
	/// <summary>
	/// Zusammenfassung f�r Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TextBox txtSrcFileName;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button btnSrcFileName;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox txtKeyFileName;
		private System.Windows.Forms.Button btnKeyFileName;
		private System.Windows.Forms.Button btnDstFileName;
		private System.Windows.Forms.TextBox txtDstFileName;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabHide;
		private System.Windows.Forms.TabPage tabExtract;
		private System.Windows.Forms.TextBox txtMessageHide;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Button btnHide;
		private System.Windows.Forms.TextBox txtMessageExtract;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Button btnExtract;
		/// <summary>
		/// Erforderliche Designervariable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Erforderlich f�r die Windows Form-Designerunterst�tzung
			//
			InitializeComponent();

			//
			// TODO: F�gen Sie den Konstruktorcode nach dem Aufruf von InitializeComponent hinzu
			//
		}

		/// <summary>
		/// Die verwendeten Ressourcen bereinigen.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Vom Windows Form-Designer generierter Code
		/// <summary>
		/// Erforderliche Methode f�r die Designerunterst�tzung. 
		/// Der Inhalt der Methode darf nicht mit dem Code-Editor ge�ndert werden.
		/// </summary>
		private void InitializeComponent()
		{
			this.txtSrcFileName = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.btnSrcFileName = new System.Windows.Forms.Button();
			this.label2 = new System.Windows.Forms.Label();
			this.txtKeyFileName = new System.Windows.Forms.TextBox();
			this.btnKeyFileName = new System.Windows.Forms.Button();
			this.btnDstFileName = new System.Windows.Forms.Button();
			this.txtDstFileName = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabHide = new System.Windows.Forms.TabPage();
			this.txtMessageHide = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.btnHide = new System.Windows.Forms.Button();
			this.tabExtract = new System.Windows.Forms.TabPage();
			this.txtMessageExtract = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.btnExtract = new System.Windows.Forms.Button();
			this.tabControl1.SuspendLayout();
			this.tabHide.SuspendLayout();
			this.tabExtract.SuspendLayout();
			this.SuspendLayout();
			// 
			// txtSrcFileName
			// 
			this.txtSrcFileName.Location = new System.Drawing.Point(154, 20);
			this.txtSrcFileName.Name = "txtSrcFileName";
			this.txtSrcFileName.Size = new System.Drawing.Size(389, 22);
			this.txtSrcFileName.TabIndex = 1;
			this.txtSrcFileName.Text = "";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(20, 20);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(128, 28);
			this.label1.TabIndex = 2;
			this.label1.Text = "Carrier Image";
			// 
			// btnSrcFileName
			// 
			this.btnSrcFileName.Location = new System.Drawing.Point(543, 20);
			this.btnSrcFileName.Name = "btnSrcFileName";
			this.btnSrcFileName.Size = new System.Drawing.Size(96, 24);
			this.btnSrcFileName.TabIndex = 3;
			this.btnSrcFileName.Text = "Browse...";
			this.btnSrcFileName.Click += new System.EventHandler(this.btnSrcFileName_Click);
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(20, 59);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(128, 29);
			this.label2.TabIndex = 2;
			this.label2.Text = "Key File";
			// 
			// txtKeyFileName
			// 
			this.txtKeyFileName.Location = new System.Drawing.Point(154, 59);
			this.txtKeyFileName.Name = "txtKeyFileName";
			this.txtKeyFileName.Size = new System.Drawing.Size(389, 22);
			this.txtKeyFileName.TabIndex = 1;
			this.txtKeyFileName.Text = "";
			// 
			// btnKeyFileName
			// 
			this.btnKeyFileName.Location = new System.Drawing.Point(543, 59);
			this.btnKeyFileName.Name = "btnKeyFileName";
			this.btnKeyFileName.Size = new System.Drawing.Size(96, 25);
			this.btnKeyFileName.TabIndex = 3;
			this.btnKeyFileName.Text = "Browse...";
			this.btnKeyFileName.Click += new System.EventHandler(this.btnKeyFileName_Click);
			// 
			// btnDstFileName
			// 
			this.btnDstFileName.Location = new System.Drawing.Point(461, 10);
			this.btnDstFileName.Name = "btnDstFileName";
			this.btnDstFileName.Size = new System.Drawing.Size(96, 25);
			this.btnDstFileName.TabIndex = 3;
			this.btnDstFileName.Text = "Browse...";
			this.btnDstFileName.Click += new System.EventHandler(this.btnDstFileName_Click);
			// 
			// txtDstFileName
			// 
			this.txtDstFileName.Location = new System.Drawing.Point(143, 10);
			this.txtDstFileName.Name = "txtDstFileName";
			this.txtDstFileName.Size = new System.Drawing.Size(318, 22);
			this.txtDstFileName.TabIndex = 1;
			this.txtDstFileName.Text = "";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(10, 10);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(128, 28);
			this.label3.TabIndex = 2;
			this.label3.Text = "Save as";
			// 
			// tabControl1
			// 
			this.tabControl1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					  this.tabHide,
																					  this.tabExtract});
			this.tabControl1.Location = new System.Drawing.Point(20, 109);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(625, 276);
			this.tabControl1.TabIndex = 4;
			// 
			// tabHide
			// 
			this.tabHide.Controls.AddRange(new System.Windows.Forms.Control[] {
																				  this.txtMessageHide,
																				  this.btnDstFileName,
																				  this.label3,
																				  this.txtDstFileName,
																				  this.label4,
																				  this.btnHide});
			this.tabHide.Location = new System.Drawing.Point(4, 25);
			this.tabHide.Name = "tabHide";
			this.tabHide.Size = new System.Drawing.Size(617, 247);
			this.tabHide.TabIndex = 0;
			this.tabHide.Text = "Hide";
			// 
			// txtMessageHide
			// 
			this.txtMessageHide.Location = new System.Drawing.Point(143, 49);
			this.txtMessageHide.Multiline = true;
			this.txtMessageHide.Name = "txtMessageHide";
			this.txtMessageHide.Size = new System.Drawing.Size(318, 139);
			this.txtMessageHide.TabIndex = 4;
			this.txtMessageHide.Text = "";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(10, 49);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(128, 29);
			this.label4.TabIndex = 2;
			this.label4.Text = "Message";
			// 
			// btnHide
			// 
			this.btnHide.Location = new System.Drawing.Point(143, 207);
			this.btnHide.Name = "btnHide";
			this.btnHide.Size = new System.Drawing.Size(318, 25);
			this.btnHide.TabIndex = 3;
			this.btnHide.Text = "Hide";
			this.btnHide.Click += new System.EventHandler(this.btnHide_Click);
			// 
			// tabExtract
			// 
			this.tabExtract.Controls.AddRange(new System.Windows.Forms.Control[] {
																					 this.txtMessageExtract,
																					 this.label5,
																					 this.btnExtract});
			this.tabExtract.Location = new System.Drawing.Point(4, 25);
			this.tabExtract.Name = "tabExtract";
			this.tabExtract.Size = new System.Drawing.Size(617, 247);
			this.tabExtract.TabIndex = 1;
			this.tabExtract.Text = "Extract";
			// 
			// txtMessageExtract
			// 
			this.txtMessageExtract.Location = new System.Drawing.Point(154, 20);
			this.txtMessageExtract.Multiline = true;
			this.txtMessageExtract.Name = "txtMessageExtract";
			this.txtMessageExtract.ReadOnly = true;
			this.txtMessageExtract.Size = new System.Drawing.Size(317, 168);
			this.txtMessageExtract.TabIndex = 7;
			this.txtMessageExtract.Text = "";
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(20, 20);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(128, 28);
			this.label5.TabIndex = 5;
			this.label5.Text = "Message";
			// 
			// btnExtract
			// 
			this.btnExtract.Location = new System.Drawing.Point(154, 207);
			this.btnExtract.Name = "btnExtract";
			this.btnExtract.Size = new System.Drawing.Size(317, 25);
			this.btnExtract.TabIndex = 6;
			this.btnExtract.Text = "Extract";
			this.btnExtract.Click += new System.EventHandler(this.btnExtract_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(6, 15);
			this.ClientSize = new System.Drawing.Size(665, 392);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.tabControl1,
																		  this.btnSrcFileName,
																		  this.label1,
																		  this.txtSrcFileName,
																		  this.btnKeyFileName,
																		  this.txtKeyFileName,
																		  this.label2});
			this.Name = "Form1";
			this.Text = "Simple Steganography Sample for indexed Pictures";
			this.tabControl1.ResumeLayout(false);
			this.tabHide.ResumeLayout(false);
			this.tabExtract.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// Der Haupteinstiegspunkt f�r die Anwendung.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private String GetFileName(String filter){
			OpenFileDialog dlg = new OpenFileDialog();
			dlg.Filter = filter;
			if(dlg.ShowDialog(this) == DialogResult.OK){
				return dlg.FileName;
			}else{
				return null;
			}
		}

		private void btnSrcFileName_Click(object sender, System.EventArgs e) {
			String fileName = GetFileName("Indexed Bitmaps (*.bmp, *.png, *.gif)|*.bmp;*.png;*.gif");
			if(fileName != null){
				txtSrcFileName.Text = fileName;
			}
		}

		private void btnKeyFileName_Click(object sender, System.EventArgs e) {
			String fileName = GetFileName(String.Empty);
			if(fileName != null){
				txtKeyFileName.Text = fileName;
			}
		}

		private void btnDstFileName_Click(object sender, System.EventArgs e) {
			SaveFileDialog dlg = new SaveFileDialog();
			dlg.Filter = "Indexed Bitmaps (*.bmp, *.png, *.gif)|*.bmp;*.png;*.gif";
			if(dlg.ShowDialog() == DialogResult.OK){
				txtDstFileName.Text = dlg.FileName;
			}
		}

		private void btnHide_Click(object sender, System.EventArgs e) {

			Bitmap bmp = new Bitmap(txtSrcFileName.Text);

			if(bmp.Palette.Entries.Length > 128){
				MessageBox.Show(this,
					"The image contains "+bmp.Palette.Entries.Length.ToString()
					+" colours. Please select an image with 128 or less colours.");
					
				return;
			}
			
			//int maxPaletteSize = 256; //enlarge palette to the maximum
			
			//don't add more than 3 new colors per existing color
			int maxPaletteSize = (bmp.Palette.Entries.Length * 3);
			if(maxPaletteSize > 256){
				maxPaletteSize = 256;
			}
			bmp.Dispose();

			PaletteUtility util = new PaletteUtility(txtSrcFileName.Text, txtDstFileName.Text);

			//create a stream from the message and its length
			byte[] messageBytes = ASCIIEncoding.ASCII.GetBytes( txtMessageHide.Text );
			BinaryWriter messageWriter = new BinaryWriter(new MemoryStream());
			messageWriter.Write(messageBytes.Length);
			messageWriter.Write(messageBytes);
			messageWriter.Seek(0, SeekOrigin.Begin);
			
			FileStream key = new FileStream(txtKeyFileName.Text, FileMode.Open);
			
			long countUseablePixels = util.CountUseableUnits(key);
			if(countUseablePixels < (messageWriter.BaseStream.Length*8)){
				MessageBox.Show(this, "The image is too small for this message and key. Please use a larger image or another key.");
			}
			else{
				util.Hide(maxPaletteSize, messageWriter.BaseStream, key);
			}

			key.Close();
			messageWriter.Close();
		}

		private void btnExtract_Click(object sender, System.EventArgs e) {
			MemoryStream message = new MemoryStream();
			FileStream key = new FileStream(txtKeyFileName.Text, FileMode.Open);
			
			PaletteUtility util = new PaletteUtility(txtSrcFileName.Text, null);
			util.Extract(message, key);
			
			message.Seek(0, SeekOrigin.Begin);
			StreamReader reader = new StreamReader(message);
			
			txtMessageExtract.Text = reader.ReadToEnd();
			
			reader.Close();
			key.Close();
		}
	}
}
