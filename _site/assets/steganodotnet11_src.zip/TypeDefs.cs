using System;
using System.Runtime.InteropServices;

namespace SteganoPalette {
	[StructLayout(LayoutKind.Sequential, Pack=1)]
	public struct BITMAPINFOHEADER {
		public  Int32 biSize;
		public  Int32 biWidth;
		public  Int32 biHeight;
		public  Int16 biPlanes;
		public  Int16 biBitCount;
		public UInt32 biCompression;
		public  Int32 biSizeImage;
		public  Int32 biXPelsPerMeter;
		public  Int32 biYPelsPerMeter;
		public UInt32 biClrUsed;
		public UInt32 biClrImportant;
	}
	
	[StructLayout(LayoutKind.Sequential, Pack=1)]
	public struct BITMAPFILEHEADER{
		public Int16 bfType;
		public Int32 bfSize;
		public Int16 bfReserved1;
		public Int16 bfReserved2;
		public Int32 bfOffBits;
	}

}
