using System;
using System.IO;
using System.Collections;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;

namespace SteganoPalette
{
	public class PaletteUtility
	{

		private String sourceFileName;
		private String destinationFileName;

		/// <summary>Counts the pixels which will be used with the specified key</summary>
		/// <param name="keyStream">The key</param>
		/// <returns>Count of pixels that will be used for hiding data</returns>
		public long CountUseableUnits(Stream keyStream){
			long countUseableUnits = 0;
			long unitIndex = 0;
			byte key;

			Bitmap bmp = new Bitmap(sourceFileName);
			long countUnits = bmp.Width*bmp.Height;
			bmp.Dispose();
			
			while(true){
				key = GetKey(keyStream);
				if(unitIndex + key < countUnits){
					unitIndex += key;
					countUseableUnits++;
				}else{
					break;
				}
			}
			keyStream.Seek(0, SeekOrigin.Begin);
			return countUseableUnits;
		}

		/// <summary>Hides the content of [messageStream] in the picture</summary>
		/// <param name="maxPaletteSize">Maximum count of colors in the new palette</param>
		/// <param name="messageStream">The secret message</param>
		/// <param name="keyStream">
		/// A key to locate the pixels that are going to carry the bits of the message.
		/// All other pixels will contain random bits.
		/// </param>
		public void Hide(int maxPaletteSize, Stream messageStream, Stream keyStream){
			//load the original image
			Bitmap bmp = new Bitmap(sourceFileName);

			ArrayList newPalette = null; //receives the stretched palette
			Hashtable colorIndexToNewIndices = null; //recevies the list of new color indices

			//create a new palette from the existing one
			StretchPalette(bmp.Palette, maxPaletteSize, ref newPalette, ref colorIndexToNewIndices);

			//create a bitmap with the new palette and the hidden message
			Bitmap newBmp = CreateBitmap(bmp, newPalette, colorIndexToNewIndices, messageStream, keyStream);

			//save the new bitmap
			newBmp.Save(destinationFileName);
			newBmp.Dispose();
			bmp.Dispose();
		}

		/// <summary>Extracts a hidden message from a picture</summary>
		/// <param name="messageStream">Empty stream to receive the extracted message</param>
		/// <param name="keyStream">The key that has been used to hide the message</param>
		public void Extract(Stream messageStream, Stream keyStream){
			//load the carrier image
			Bitmap bmp = new Bitmap(sourceFileName);
			BitmapData bmpData = bmp.LockBits(new Rectangle(0,0,bmp.Width, bmp.Height), ImageLockMode.ReadWrite, PixelFormat.Format8bppIndexed);
			
			//copy all pixels
			byte[] pixels = new byte[bmpData.Stride*bmpData.Height];
			Marshal.Copy(bmpData.Scan0, pixels, 0, pixels.Length);

			Color[] palette = bmp.Palette.Entries;
			byte messageByte=0, messageBitIndex=0, pixel=0;
			int messageLength=0, pixelIndex=0;

			//read pixels until the message is complete
			while((messageLength==0) || (messageStream.Length < messageLength)){
				//locate the next pixel that carries a hidden bit
				pixelIndex += GetKey(keyStream);
				pixel = pixels[pixelIndex];
				
				if( (palette[pixel].B % 2) == 1 ){
					//odd blue-component: message-bit was "1"
					messageByte += (byte)(1 << messageBitIndex);
				} //else: messageBit was "0", nothing to do

				if(messageBitIndex == 7){ //a byte is complete
					//save and reset messageByte, reset messageBitIndex
					messageStream.WriteByte(messageByte);
					messageBitIndex = 0;
					messageByte = 0;

					if((messageLength == 0)&&(messageStream.Length==4)){
						//message's length has been read
						messageStream.Seek(0, SeekOrigin.Begin);
						messageLength = new BinaryReader(messageStream).ReadInt32();
						messageStream.SetLength(0);
					}
				}else{
					messageBitIndex++; //next bit
				}
			}

			//release the carrier bitmap
			bmp.UnlockBits(bmpData);
			bmp.Dispose();
		}

		/// <summary>Creates a larger palette by duplicating and changing the colors of another palette</summary>
		/// <param name="oldPalette">The palette to stretch</param>
		/// <param name="maxPaletteSize">Count of colors in the new palette</param>
		/// <param name="newPalette">Receives the new palette entries</param>
		/// <param name="colorIndexToNewIndices">
		/// Receives a Hashtable with the original indices as the keys,
		/// and the corresponding new indices as the values
		/// </param>
		private void StretchPalette(ColorPalette oldPalette, int maxPaletteSize, ref ArrayList newPalette, ref Hashtable colorIndexToNewIndices){
			newPalette = new ArrayList(maxPaletteSize);
			colorIndexToNewIndices = new Hashtable( oldPalette.Entries.Length );
			
			Random random = new Random();
			byte indexInNewPalette;
			Color color, newColor;
			ColorIndexList colorIndexList;
			
			while(newPalette.Count < maxPaletteSize){ //repeat the palette if necessary
				for(byte n=0; n<oldPalette.Entries.Length; n++){ //loop over old palette entries
					color = oldPalette.Entries[n]; //original color
					
					if(colorIndexToNewIndices.ContainsKey(n)){
						//this color from the original palette already has one or more copies in the new palette
						colorIndexList = (ColorIndexList)colorIndexToNewIndices[n];
					}else{
						if(color.B%2 > 0){ //make even
							color = Color.FromArgb(color.R, color.G, color.B-1);
						}
						indexInNewPalette = (byte)newPalette.Add(color); //add color
						colorIndexList = new ColorIndexList(random);
						colorIndexList.Add(indexInNewPalette);
						colorIndexToNewIndices.Add(n, colorIndexList);
					}
				
					if(newPalette.Count < maxPaletteSize){
						//create a non-exact copy of the color
						newColor = GetSimilarColor(random, newPalette, color);
						
						if(newColor.B%2 == 0){ //make odd
							newColor = Color.FromArgb(newColor.R, newColor.G, newColor.B+1);
						}
						
						//add the changed color to the new palette
						indexInNewPalette = (byte)newPalette.Add(newColor);
						//add the new index to the list of alternative indices
						colorIndexList.Add(indexInNewPalette);
					}

					//update the Hashtable
					colorIndexToNewIndices[n] = colorIndexList;

					if(newPalette.Count == maxPaletteSize){
						break; //the new palette is full - cancel
					}
				}
			}
		}
		
		/// <summary>Calculates a color that looks nearly the same</summary>
		/// <param name="random"></param>
		/// <param name="excludeColors">List of colors that may not be returned again</param>
		/// <param name="color">Original color</param>
		/// <returns>A new color that differs a little from [color]</returns>
		private Color GetSimilarColor(Random random, ArrayList excludeColors, Color color){
			Color newColor = color;
			int countLoops = 0, red, green, blue;
			do{
				red = GetSimilarColorComponent(random, newColor.R);
				green = GetSimilarColorComponent(random, newColor.G);
				blue = GetSimilarColorComponent(random, newColor.B);
				newColor = Color.FromArgb(red, green, blue);
				countLoops++;
			}while(excludeColors.Contains(newColor)&&(countLoops<10)); //make sure that there are no duplicate colors
			
			return newColor;
		}

		/// <summary>Calculates a color component that looks nearly the same</summary>
		/// <param name="random"></param>
		/// <param name="colorValue">Original color component</param>
		/// <returns>[colorValue]*1.0x if [colorValue] is less than 128, or [colorValue]/1.0x for higher values</returns>
		private byte GetSimilarColorComponent(Random random, byte colorValue){
			if(colorValue < 128){
				colorValue = (byte)(colorValue * (1 + random.Next(1,8)/(float)100) );
			}else{
				colorValue = (byte)(colorValue / (1 + random.Next(1,8)/(float)100) );
			}			
			return colorValue;
		}

		/// <summary>
		/// Creates an image with a stretched palette, converts the pixels of the
		/// original image for that new palette, and hides a message in the converted pixels
		/// </summary>
		/// <param name="bmp">The original image</param>
		/// <param name="palette">The new palette</param>
		/// <param name="colorIndexToNewIndices">
		/// Hashtable which maps every index in the original palette
		/// to a list of indices in the new palette.
		/// </param>
		/// <param name="messageStream">The secret message</param>
		/// <param name="keyStream">A key that specifies the distances between two pixels used to hide a bit</param>
		/// <returns>The new bitmap</returns>
		private Bitmap CreateBitmap(Bitmap bmp, ArrayList palette, Hashtable colorIndexToNewIndices, Stream messageStream, Stream keyStream){
			BitmapData bmpData = bmp.LockBits(new Rectangle(0,0,bmp.Width, bmp.Height), ImageLockMode.ReadWrite, PixelFormat.Format8bppIndexed);
			
			//size of the image data in bytes
			int imageSize = (bmpData.Height * bmpData.Stride) + (palette.Count * 4);

			//copy all pixels
			byte[] pixels = new byte[imageSize];
			Marshal.Copy(bmpData.Scan0, pixels, 0, (bmpData.Height * bmpData.Stride));
			
			int messageByte=0, messageBitIndex=7;
			bool messageBit;
			ColorIndexList newColorIndices;
			Random random = new Random();
			
			//index of the next pixel that's going to hide one bit
			int nextUseablePixelIndex = GetKey(keyStream);
			
			//loop over the pixels
			for(int pixelIndex=0; pixelIndex<pixels.Length; pixelIndex++){
				
				//get the list of new color indices for the current pixel
				newColorIndices = (ColorIndexList)colorIndexToNewIndices[pixels[pixelIndex]];
				
				if((pixelIndex < nextUseablePixelIndex) || messageByte < 0){
					//message complete or this pixel has to be skipped - use a random color
					pixels[pixelIndex] = newColorIndices.GetIndex();
				}else{
					//message not complete yet
					
					if(messageBitIndex == 7){
						//one byte has been hidden - proceed to the next one
						messageBitIndex = 0;
						messageByte = messageStream.ReadByte();
					}else{
						messageBitIndex++; //next bit
					}
					
					//get a bit out of the current byte
					messageBit = (messageByte & (1 << messageBitIndex)) > 0;
					//get the index of a similar color in the new palette
					pixels[pixelIndex] = newColorIndices.GetIndex(messageBit);
					
					nextUseablePixelIndex += GetKey(keyStream);
				}
			}

			//Now we have the palette and the new pixels - enough data to write the bitmap!
			
			BinaryWriter bw = new BinaryWriter( new MemoryStream() );

			//write bitmap file header
			bw.Write( System.Text.ASCIIEncoding.ASCII.GetBytes("BM") ); //BITMAPFILEHEADER.bfType;
			bw.Write((Int32)(55 + imageSize)); //BITMAPFILEHEADER.bfSize;
			bw.Write((Int16)0); //BITMAPFILEHEADER.bfReserved1;
			bw.Write((Int16)0); //BITMAPFILEHEADER.bfReserved2;
			bw.Write(
				(Int32)(
				Marshal.SizeOf(typeof(BITMAPINFOHEADER))
				+ Marshal.SizeOf(typeof(BITMAPFILEHEADER))
				+ palette.Count*4)
				); //BITMAPFILEHEADER.bfOffBits;
			
			//write bitmap info header
			bw.Write((Int32)Marshal.SizeOf(typeof(BITMAPINFOHEADER)));
			bw.Write((Int32)bmp.Width); //BITMAPINFOHEADER.biWidth
			bw.Write((Int32)bmp.Height); //BITMAPINFOHEADER.biHeight
			bw.Write((Int16)1); //BITMAPINFOHEADER.biPlanes
			bw.Write((Int16)8); //BITMAPINFOHEADER.biBitCount
			bw.Write((UInt32)0); //BITMAPINFOHEADER.biCompression
			bw.Write((Int32) (bmpData.Height * bmpData.Stride) + (palette.Count * 4) ); //BITMAPINFOHEADER.biSizeImage
			bw.Write((Int32)0); //BITMAPINFOHEADER.biXPelsPerMeter
			bw.Write((Int32)0); //BITMAPINFOHEADER.biYPelsPerMeter
			bw.Write((UInt32)palette.Count); //BITMAPINFOHEADER.biClrUsed
			bw.Write((UInt32)palette.Count); //BITMAPINFOHEADER.biClrImportant
			
			//write palette
			foreach(Color color in palette){
				bw.Write((UInt32)color.ToArgb());
			}
			//write pixels
			bw.Write(pixels);

			bmp.UnlockBits(bmpData);
			
			Bitmap newImage = (Bitmap)Image.FromStream(bw.BaseStream);
			newImage.RotateFlip(RotateFlipType.RotateNoneFlipY);

			bw.Close();
			return newImage;
		}

		/// <summary>Get the next value from the key stream</summary>
		/// <param name="keyStream">The key</param>
		/// <returns>Next value from [key]</returns>
		private byte GetKey(Stream keyStream){
			int keyByte = keyStream.ReadByte();
			if(keyByte < 0){
				keyStream.Seek(0, SeekOrigin.Begin);
				keyByte = keyStream.ReadByte();
			}
			if(keyByte == 0){ keyByte = 1; }

			return (byte)keyByte;
		}

		/// <summary>Initialises a new PaletteUtility for an image</summary>
		/// <param name="sourceFileName">Name of the source image file</param>
		/// <param name="destinationFileName">Name for the file created by Hide()</param>
		public PaletteUtility(String sourceFileName, String destinationFileName){
			this.sourceFileName = sourceFileName;
			this.destinationFileName = destinationFileName;
		}
	}
}
