using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Text;
using System.IO;
using System.Diagnostics;

namespace SteganoDotNet
{
	/// <summary>
	/// Zusammendfassende Beschreibung f�r Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnHide;
		private System.Windows.Forms.Button btnExtract;
		private System.Windows.Forms.Button btnAnalyse;
		private System.Windows.Forms.TextBox txtSrcFile;
		private System.Windows.Forms.Button btnSrcFile;
		private System.Windows.Forms.Button btnDstFile;
		private System.Windows.Forms.TextBox txtReport;
		private System.Windows.Forms.TextBox txtBytesPerMethod;
		private System.Windows.Forms.TextBox txtDstFile;
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabHide;
		private System.Windows.Forms.TabPage tabExtract;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.TextBox txtMessage;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.GroupBox groupBox4;
		private System.Windows.Forms.TextBox txtExtractedMessage;
		private System.Windows.Forms.Button btnIlAsm;
		private System.Windows.Forms.TextBox txtIlAsm;
		private System.Windows.Forms.Button btnIlDAsm;
		private System.Windows.Forms.TextBox txtIlDAsm;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		/// <summary>
		/// Erforderliche Designervariable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.Button btnKeyFile;
		private System.Windows.Forms.TextBox txtKeyFile;
		private System.Windows.Forms.Label label7;

		private String ilFileName = String.Empty;

		public Form1()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Die verwendeten Ressourcen bereinigen.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Erforderliche Methode f�r die Designerunterst�tzung. 
		/// Der Inhalt der Methode darf nicht mit dem Code-Editor ge�ndert werden.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnHide = new System.Windows.Forms.Button();
			this.btnExtract = new System.Windows.Forms.Button();
			this.btnAnalyse = new System.Windows.Forms.Button();
			this.txtSrcFile = new System.Windows.Forms.TextBox();
			this.btnSrcFile = new System.Windows.Forms.Button();
			this.btnDstFile = new System.Windows.Forms.Button();
			this.txtDstFile = new System.Windows.Forms.TextBox();
			this.txtReport = new System.Windows.Forms.TextBox();
			this.txtBytesPerMethod = new System.Windows.Forms.TextBox();
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabHide = new System.Windows.Forms.TabPage();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.txtMessage = new System.Windows.Forms.TextBox();
			this.tabExtract = new System.Windows.Forms.TabPage();
			this.groupBox4 = new System.Windows.Forms.GroupBox();
			this.txtExtractedMessage = new System.Windows.Forms.TextBox();
			this.btnIlAsm = new System.Windows.Forms.Button();
			this.txtIlAsm = new System.Windows.Forms.TextBox();
			this.btnIlDAsm = new System.Windows.Forms.Button();
			this.txtIlDAsm = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.btnKeyFile = new System.Windows.Forms.Button();
			this.txtKeyFile = new System.Windows.Forms.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.tabControl1.SuspendLayout();
			this.tabHide.SuspendLayout();
			this.groupBox3.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.tabExtract.SuspendLayout();
			this.groupBox4.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnHide
			// 
			this.btnHide.Enabled = false;
			this.btnHide.Location = new System.Drawing.Point(24, 32);
			this.btnHide.Name = "btnHide";
			this.btnHide.Size = new System.Drawing.Size(312, 23);
			this.btnHide.TabIndex = 0;
			this.btnHide.Text = "Hide";
			this.btnHide.Click += new System.EventHandler(this.btnHide_Click);
			// 
			// btnExtract
			// 
			this.btnExtract.Location = new System.Drawing.Point(16, 16);
			this.btnExtract.Name = "btnExtract";
			this.btnExtract.Size = new System.Drawing.Size(408, 23);
			this.btnExtract.TabIndex = 1;
			this.btnExtract.Text = "Extract";
			this.btnExtract.Click += new System.EventHandler(this.btnExtract_Click);
			// 
			// btnAnalyse
			// 
			this.btnAnalyse.Location = new System.Drawing.Point(16, 32);
			this.btnAnalyse.Name = "btnAnalyse";
			this.btnAnalyse.Size = new System.Drawing.Size(312, 23);
			this.btnAnalyse.TabIndex = 0;
			this.btnAnalyse.Text = "Analyse";
			this.btnAnalyse.Click += new System.EventHandler(this.btnAnalyse_Click);
			// 
			// txtSrcFile
			// 
			this.txtSrcFile.Location = new System.Drawing.Point(80, 16);
			this.txtSrcFile.Name = "txtSrcFile";
			this.txtSrcFile.Size = new System.Drawing.Size(312, 22);
			this.txtSrcFile.TabIndex = 2;
			this.txtSrcFile.Text = "";
			this.txtSrcFile.TextChanged += new System.EventHandler(this.textfield_TextChanged);
			// 
			// btnSrcFile
			// 
			this.btnSrcFile.Location = new System.Drawing.Point(392, 16);
			this.btnSrcFile.Name = "btnSrcFile";
			this.btnSrcFile.TabIndex = 3;
			this.btnSrcFile.Text = "Browse...";
			this.btnSrcFile.Click += new System.EventHandler(this.btnSrcFile_Click);
			// 
			// btnDstFile
			// 
			this.btnDstFile.Location = new System.Drawing.Point(392, 40);
			this.btnDstFile.Name = "btnDstFile";
			this.btnDstFile.TabIndex = 5;
			this.btnDstFile.Text = "Browse...";
			this.btnDstFile.Click += new System.EventHandler(this.btnDstFile_Click);
			// 
			// txtDstFile
			// 
			this.txtDstFile.Location = new System.Drawing.Point(80, 40);
			this.txtDstFile.Name = "txtDstFile";
			this.txtDstFile.Size = new System.Drawing.Size(312, 22);
			this.txtDstFile.TabIndex = 4;
			this.txtDstFile.Text = "";
			// 
			// txtReport
			// 
			this.txtReport.Location = new System.Drawing.Point(16, 96);
			this.txtReport.Multiline = true;
			this.txtReport.Name = "txtReport";
			this.txtReport.ReadOnly = true;
			this.txtReport.Size = new System.Drawing.Size(312, 56);
			this.txtReport.TabIndex = 4;
			this.txtReport.Text = "";
			// 
			// txtBytesPerMethod
			// 
			this.txtBytesPerMethod.Location = new System.Drawing.Point(16, 160);
			this.txtBytesPerMethod.Name = "txtBytesPerMethod";
			this.txtBytesPerMethod.ReadOnly = true;
			this.txtBytesPerMethod.Size = new System.Drawing.Size(32, 22);
			this.txtBytesPerMethod.TabIndex = 6;
			this.txtBytesPerMethod.Text = "1";
			// 
			// tabControl1
			// 
			this.tabControl1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					  this.tabHide,
																					  this.tabExtract});
			this.tabControl1.Location = new System.Drawing.Point(16, 184);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(448, 448);
			this.tabControl1.TabIndex = 7;
			this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
			// 
			// tabHide
			// 
			this.tabHide.Controls.AddRange(new System.Windows.Forms.Control[] {
																				  this.groupBox3,
																				  this.groupBox2,
																				  this.groupBox1});
			this.tabHide.Location = new System.Drawing.Point(4, 25);
			this.tabHide.Name = "tabHide";
			this.tabHide.Size = new System.Drawing.Size(440, 419);
			this.tabHide.TabIndex = 0;
			this.tabHide.Text = "Hide";
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.btnHide});
			this.groupBox3.Location = new System.Drawing.Point(16, 344);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(408, 64);
			this.groupBox3.TabIndex = 10;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "3. Hide the message";
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.txtReport,
																					this.txtBytesPerMethod,
																					this.label1,
																					this.label2,
																					this.btnAnalyse});
			this.groupBox2.Location = new System.Drawing.Point(16, 128);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(408, 200);
			this.groupBox2.TabIndex = 9;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "2.Analyse the carrier assembly";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 72);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(56, 23);
			this.label1.TabIndex = 7;
			this.label1.Text = "Report";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(48, 160);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(328, 24);
			this.label2.TabIndex = 7;
			this.label2.Text = "Bytes of the message will be hidden in each Method";
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.txtMessage});
			this.groupBox1.Location = new System.Drawing.Point(16, 16);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(408, 100);
			this.groupBox1.TabIndex = 8;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "1. Enter the message";
			// 
			// txtMessage
			// 
			this.txtMessage.Location = new System.Drawing.Point(16, 24);
			this.txtMessage.Multiline = true;
			this.txtMessage.Name = "txtMessage";
			this.txtMessage.Size = new System.Drawing.Size(376, 64);
			this.txtMessage.TabIndex = 0;
			this.txtMessage.Text = "hallo";
			this.txtMessage.TextChanged += new System.EventHandler(this.textfield_TextChanged);
			// 
			// tabExtract
			// 
			this.tabExtract.Controls.AddRange(new System.Windows.Forms.Control[] {
																					 this.groupBox4,
																					 this.btnExtract});
			this.tabExtract.Location = new System.Drawing.Point(4, 25);
			this.tabExtract.Name = "tabExtract";
			this.tabExtract.Size = new System.Drawing.Size(440, 419);
			this.tabExtract.TabIndex = 1;
			this.tabExtract.Text = "Extract";
			// 
			// groupBox4
			// 
			this.groupBox4.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.txtExtractedMessage});
			this.groupBox4.Location = new System.Drawing.Point(16, 48);
			this.groupBox4.Name = "groupBox4";
			this.groupBox4.Size = new System.Drawing.Size(408, 360);
			this.groupBox4.TabIndex = 9;
			this.groupBox4.TabStop = false;
			this.groupBox4.Text = "Extracted message";
			// 
			// txtExtractedMessage
			// 
			this.txtExtractedMessage.Location = new System.Drawing.Point(16, 24);
			this.txtExtractedMessage.Multiline = true;
			this.txtExtractedMessage.Name = "txtExtractedMessage";
			this.txtExtractedMessage.Size = new System.Drawing.Size(376, 320);
			this.txtExtractedMessage.TabIndex = 0;
			this.txtExtractedMessage.Text = "";
			// 
			// btnIlAsm
			// 
			this.btnIlAsm.Location = new System.Drawing.Point(392, 144);
			this.btnIlAsm.Name = "btnIlAsm";
			this.btnIlAsm.TabIndex = 11;
			this.btnIlAsm.Text = "Browse...";
			this.btnIlAsm.Click += new System.EventHandler(this.btnIlAsm_Click);
			// 
			// txtIlAsm
			// 
			this.txtIlAsm.Location = new System.Drawing.Point(80, 144);
			this.txtIlAsm.Name = "txtIlAsm";
			this.txtIlAsm.Size = new System.Drawing.Size(312, 22);
			this.txtIlAsm.TabIndex = 10;
			this.txtIlAsm.Text = "C:\\WINDOWS\\Microsoft.NET\\Framework\\v1.0.3705\\ilasm.exe";
			// 
			// btnIlDAsm
			// 
			this.btnIlDAsm.Location = new System.Drawing.Point(392, 120);
			this.btnIlDAsm.Name = "btnIlDAsm";
			this.btnIlDAsm.TabIndex = 9;
			this.btnIlDAsm.Text = "Browse...";
			this.btnIlDAsm.Click += new System.EventHandler(this.btnIlDAsm_Click);
			// 
			// txtIlDAsm
			// 
			this.txtIlDAsm.Location = new System.Drawing.Point(80, 120);
			this.txtIlDAsm.Name = "txtIlDAsm";
			this.txtIlDAsm.Size = new System.Drawing.Size(312, 22);
			this.txtIlDAsm.TabIndex = 8;
			this.txtIlDAsm.Text = "C:\\programme\\Microsoft.NET\\FrameworkSDK\\Bin\\ildasm.exe";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(8, 16);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(72, 23);
			this.label3.TabIndex = 12;
			this.label3.Text = "Carrier file";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(8, 40);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(72, 23);
			this.label4.TabIndex = 12;
			this.label4.Text = "Save as";
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(8, 120);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(72, 23);
			this.label5.TabIndex = 12;
			this.label5.Text = "ILDAsm";
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(8, 144);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(72, 23);
			this.label6.TabIndex = 12;
			this.label6.Text = "ILAsm";
			// 
			// btnKeyFile
			// 
			this.btnKeyFile.Location = new System.Drawing.Point(392, 80);
			this.btnKeyFile.Name = "btnKeyFile";
			this.btnKeyFile.TabIndex = 7;
			this.btnKeyFile.Text = "Browse...";
			this.btnKeyFile.Click += new System.EventHandler(this.btnKeyFile_Click);
			// 
			// txtKeyFile
			// 
			this.txtKeyFile.Location = new System.Drawing.Point(80, 80);
			this.txtKeyFile.Name = "txtKeyFile";
			this.txtKeyFile.Size = new System.Drawing.Size(312, 22);
			this.txtKeyFile.TabIndex = 6;
			this.txtKeyFile.Text = "";
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(8, 80);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(72, 23);
			this.label7.TabIndex = 15;
			this.label7.Text = "Key file";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(6, 15);
			this.ClientSize = new System.Drawing.Size(480, 639);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.btnKeyFile,
																		  this.txtKeyFile,
																		  this.label7,
																		  this.label3,
																		  this.btnIlAsm,
																		  this.txtIlAsm,
																		  this.btnIlDAsm,
																		  this.txtIlDAsm,
																		  this.tabControl1,
																		  this.btnDstFile,
																		  this.txtDstFile,
																		  this.btnSrcFile,
																		  this.txtSrcFile,
																		  this.label4,
																		  this.label5,
																		  this.label6});
			this.Name = "Form1";
			this.Text = "SteganoDotNet 0.2";
			this.TextChanged += new System.EventHandler(this.textfield_TextChanged);
			this.tabControl1.ResumeLayout(false);
			this.tabHide.ResumeLayout(false);
			this.groupBox3.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.groupBox1.ResumeLayout(false);
			this.tabExtract.ResumeLayout(false);
			this.groupBox4.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// Der Haupteinstiegspunkt f�r die Anwendung.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}
	
		private void btnHide_Click(object sender, System.EventArgs e) {
			ILUtility util = new ILUtility();
			util.BytesPerMethod = int.Parse(txtBytesPerMethod.Text);
			MemoryStream messageStream = new MemoryStream(
				UnicodeEncoding.Unicode.GetBytes(txtMessage.Text));
			
			String dstFileName = txtDstFile.Text;
			bool callILAsm = false;
			if( ! dstFileName.EndsWith(".il")){
				dstFileName = dstFileName.ToLower().Replace(".exe", ".il").Replace(".dll", ".il");
				callILAsm = true;
			}

			Stream keyStream = new FileStream(txtKeyFile.Text, FileMode.Open, FileAccess.Read);
			
			util.Hide(ilFileName, dstFileName, messageStream, keyStream);

			if(callILAsm){
				Process process = Process.Start(txtIlAsm.Text, dstFileName);
				process.WaitForExit();
			}
		}

		private void btnExtract_Click(object sender, System.EventArgs e) {
			
			String carrierILFileName = txtSrcFile.Text;
			if( ! carrierILFileName.ToLower().EndsWith(".il")){
				carrierILFileName = carrierILFileName.ToLower().Replace(".exe", ".il").Replace(".dll", ".il");
				DecompileAssembly(txtSrcFile.Text, carrierILFileName);
			}

			ILUtility util = new ILUtility();
			util.BytesPerMethod = int.Parse(txtBytesPerMethod.Text);
			MemoryStream messageStream = new MemoryStream();
			
			Stream keyStream = new FileStream(txtKeyFile.Text, FileMode.Open, FileAccess.Read);
			
			util.Extract(carrierILFileName, messageStream, keyStream);

			messageStream.Seek(0, SeekOrigin.Begin);
			StreamReader reader = new StreamReader(messageStream, UnicodeEncoding.Unicode);
			txtExtractedMessage.Text = reader.ReadToEnd();
		}

		private void btnAnalyse_Click(object sender, System.EventArgs e) {
			
			ilFileName = txtSrcFile.Text;
			if( ! txtSrcFile.Text.ToLower().EndsWith(".il")){
				//build new path with destination directory path and source file name
				String outputPath = txtDstFile.Text;
				int index = outputPath.LastIndexOf("\\")+1;
				if(index > 0){
					outputPath = outputPath.Substring(0, index);
				}
				outputPath += txtSrcFile.Text.Substring(txtSrcFile.Text.LastIndexOf("\\")+1)
					.Replace(".exe", ".il").Replace(".EXE", ".il").Replace(".dll", ".il").Replace(".DLL", ".il");

				DecompileAssembly(txtSrcFile.Text, outputPath);
				ilFileName = outputPath;
			}

			//analyse the IL file
			ArrayList namespaces, classes, methods;
			ILUtility util = new ILUtility();
			util.Analyse(ilFileName, out namespaces, out classes, out methods);
			//display the result
			txtReport.Text = "namespaces: "+namespaces.Count;
			txtReport.Text += "\r\nclasses: "+classes.Count;
			txtReport.Text += "\r\nmethods: "+methods.Count;
			
			float messageLength = txtMessage.Text.Length*2 +1; //length of Unicode string + 1 position for this length
			int bytesPerMethod = (int)Math.Ceiling( (messageLength / (float)methods.Count));
			txtBytesPerMethod.Text = bytesPerMethod.ToString();

			btnHide.Enabled = true;
		}

		private void textfield_TextChanged(object sender, System.EventArgs e) {
			btnAnalyse.Enabled = (txtMessage.Text.Length > 0);
			btnHide.Enabled = false;
		}

		private void btnSrcFile_Click(object sender, System.EventArgs e) {
			String fileName = GetFileName("Assemblies and IL Files  (*.dll; *.exe; *.il)|*.dll;*.exe;*.il", false);
			if(fileName != null){ txtSrcFile.Text = fileName; }
		}

		private void btnDstFile_Click(object sender, System.EventArgs e) {
			String fileName = GetFileName("Assemblies and IL Files  (*.dll; *.exe; *.il)|*.dll;*.exe;*.il", true);
			if(fileName != null){ txtDstFile.Text = fileName; }
		}

		private void btnKeyFile_Click(object sender, System.EventArgs e) {
			String fileName = GetFileName("All Files  (*.*)|*.*", false);
			if(fileName != null){ txtKeyFile.Text = fileName; }
		}

		private void btnIlDAsm_Click(object sender, System.EventArgs e) {
			String fileName = GetFileName("Program Files (*.exe)|*.exe", false);
			if(fileName != null){ txtIlDAsm.Text = fileName; }
		}

		private void btnIlAsm_Click(object sender, System.EventArgs e) {
			String fileName = GetFileName("Program Files (*.exe)|*.exe", false);
			if(fileName != null){ txtIlAsm.Text = fileName; }
		}
	
		private void tabControl1_SelectedIndexChanged(object sender, System.EventArgs e) {
			txtDstFile.Enabled = txtIlAsm.Enabled = (tabControl1.SelectedIndex == 0);			
		}

		/// <summary>Displays the OpenFile dialog</summary>
		/// <returns>The selected file name, or null</returns>
		private String GetFileName(String filter, bool save){
			FileDialog dlg;
			if(save){
				dlg = new SaveFileDialog();
			}else{
				dlg = new OpenFileDialog();
				((OpenFileDialog)dlg).Multiselect = false;
			}
			if(filter.Length > 0){ dlg.Filter = filter; }

			if( dlg.ShowDialog(this) != DialogResult.Cancel){
				return dlg.FileName;
			}else{
				return null;
			}
		}

		/// <summary>Call ILDAsm to decompile an assembly</summary>
		/// <param name="inFileName">Path of the assembly</param>
		/// <param name="outFileName">Path for the IL file</param>
		private void DecompileAssembly(String inFileName, String outFileName){				
			//call ILDAsm
			String callIldasm = txtIlDAsm.Text;
			Process process = Process.Start(callIldasm, inFileName + " /OUT="+outFileName);
			process.WaitForExit();
			//Console.WriteLine( process.ExitCode );

			//use disassembly as carrier file
			ilFileName = outFileName;	
		}

	}
}
