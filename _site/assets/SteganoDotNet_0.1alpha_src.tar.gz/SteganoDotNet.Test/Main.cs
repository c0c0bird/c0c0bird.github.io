/*
 Created: 13.08.2006
 Author: Corinna John

Copyright (C) 2006 SteganoDotNet Team

http://sourceforge.net/projects/steganodotnet

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
(current version) as published by the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
using System;
using System.IO;
using System.Text;
using System.Drawing;
using SteganoDotNet.Action;

namespace SteganoDotNet.Test
{
	class MainClass
	{
		/*
		The following code is a simple command line tool that
		hide text in and extracts text from indexed bitmaps.
		*/
		
		public static void Main(string[] args)
		{
			Console.WriteLine("Was möchten Sie tun?");
			Console.WriteLine("(1) Text in einem Paletten-Bild verstecken.");
			Console.WriteLine("(2) Text in einem Paletten-Bild finden.");
			int selection = int.Parse( Console.ReadLine() );
			switch (selection)
			{
				default:
				case 1:
					HideInPalette();
					break;
				case 2:
					ReadFromPalette();
					break;
			}
		}

		private static void HideInPalette()
		{
			Console.Write("Where ist the original image file? ");
			string srcFileName = Console.ReadLine();
			
			Console.Write("Where must I store the result file? ");
			string dstFileName = Console.ReadLine();
			
			PaletteFileUtility utility = new PaletteFileUtility(srcFileName);

			utility.DoSortPalette = true;
			utility.DoStretchPalette = true;
			int maxCapacity = utility.Capacity;
			
			utility.DoStretchPalette = false;
			int sortCapacity = utility.Capacity;

			utility.DoSortPalette = false; 
			utility.DoStretchPalette = true;
			int stretchCapacity = utility.Capacity;

			Console.WriteLine("Maximum Capacity: {0}", maxCapacity);
			Console.WriteLine("Capacity by sorting: {0}", sortCapacity);
			Console.WriteLine("Capacity by stretching: {0}", stretchCapacity);

			Console.Write("Please tell me your secret message: ");
			string message = Console.ReadLine();

			int messageLength = message.Length;
			if (messageLength > maxCapacity)
			{
				Console.WriteLine("The message is too large for this picture.");
			}
			else
			{
				Console.WriteLine("How do you want me to hide it?");
				Console.WriteLine("\t(1) Stretch ans sort palette");
				if (messageLength <= stretchCapacity)
				{
					Console.WriteLine("\t(2) Only stretch palette");
				}
				if (messageLength <= sortCapacity)
				{
					Console.WriteLine("\t(3) only sort palette");
				}

				int selection = int.Parse( Console.ReadLine() );
				switch (selection)
				{
					default:
					case 1:
						utility.DoSortPalette = true;
						utility.DoStretchPalette = true;
						break;
					case 2:
						utility.DoSortPalette = false;
						utility.DoStretchPalette = true;
						break;
					case 3:
						utility.DoSortPalette = true;
						utility.DoStretchPalette = false;
						break;
				}
			}

			Stream keyStream = null;
			if (utility.DoStretchPalette)
			{
				Console.Write("Please enter a password to secure the message: ");
				string key = Console.ReadLine();
				if (key.Length > 0)
				{
					byte[] keyBuffer = Encoding.UTF8.GetBytes(key);
					keyStream = new MemoryStream(keyBuffer);
				}
			}

			utility.CountBytesToHide = messageLength;
			byte[] messageBuffer = Encoding.UTF8.GetBytes(message);
			Stream messageStream = new MemoryStream(messageBuffer);
			Stream formattedMessageStream = utility.GetMessagePart(messageStream);

			utility.Hide(formattedMessageStream, keyStream);
			utility.SaveResult(dstFileName);
		}

		private static void ReadFromPalette()
		{
			string srcFileName = @"C:\temp\test.png";
			PaletteFileUtility utility = new PaletteFileUtility(srcFileName);

			Console.Write("Please enter your password: ");
			string key = Console.ReadLine();
			Stream keyStream = null;
			if (key.Length > 0)
			{
				byte[] keyBuffer = Encoding.UTF8.GetBytes(key);
				keyStream = new MemoryStream(keyBuffer);
			}

			Stream messageStream = utility.Extract(keyStream);
			messageStream.Position = 0;
			StreamReader reader = new StreamReader(messageStream);
			string message = reader.ReadToEnd();

			Console.WriteLine(message);
			Console.ReadLine();
		}
		
		/*
		The following code is a prototype that shows how to
		get type descriptor and utility for any carrier file.
		*/
		
		private static void Hide(string[] args)
		{
			string messageText = string.Empty;
			string keyText = string.Empty;
			string srcFileName = string.Empty;
			string dstFileName = string.Empty;
			
			if(args.Length == 1)
			{
				Console.WriteLine("Please enter a secret:");
				messageText = Console.ReadLine();
			
				Console.WriteLine("Please enter a key:");
				keyText = Console.ReadLine();
			
				Console.WriteLine("Please enter a source file name:");
				srcFileName = Console.ReadLine();
			
				Console.WriteLine("Please enter a destination file name:");
				dstFileName = Console.ReadLine();
			}
			else if(args.Length == 5)
			{
				messageText = args[1];
				keyText = args[2];
				srcFileName = args[3];
				dstFileName = args[4];
			}
			
			//perform action
			
			if(srcFileName.Length > 0 && dstFileName.Length > 0)
			{
				FileType fileType = null;
				FileUtility fileUtility = null;
				
				try
				{
					//get FileType and FileUtility
					fileType = FileType.Current.GetFileType(srcFileName);
					fileUtility = fileType.CreateUtility(srcFileName);
					fileUtility.CountUsedBitsPerUnit = 1;
				}
				catch(Exception)
				{
					Console.WriteLine("Unknown file type.");
					throw;
				}
								
				//get message as stream
				Stream rawStream = StringToStream(messageText);
					
				//get key as stream
				Stream keyStream = StringToStream(keyText);
				
				if(fileUtility.Capacity < rawStream.Length)
				{
					Console.WriteLine("The carrier file is too small for the message.");
				}
				else
				{
					fileUtility.CountBytesToHide = (int)rawStream.Length;
					Stream messageStream = fileUtility.GetMessagePart(rawStream);
					
					string errorText = fileUtility.CheckMessageAndKey(messageStream, keyStream);
					if(errorText.Length > 0)
					{
						Console.WriteLine(errorText);
					}
					else
					{
						Console.Write("Hiding ...");
						fileUtility.Hide(messageStream, keyStream);
						fileUtility.SaveResult(dstFileName);
						Console.WriteLine("... done.");
					}
				}
			}
		}
		
		private static void Extract(string[] args)
		{
			string keyText = string.Empty;
			string srcFileName = string.Empty;
			
			if(args.Length == 1)
			{
				Console.WriteLine("Please enter a source file name:");
				srcFileName = Console.ReadLine();
			
				Console.WriteLine("Please enter a key:");
				keyText = Console.ReadLine();
			}
			else if(args.Length == 3)
			{
				keyText = args[1];
				srcFileName = args[2];
			}
			
			//perform action
			
			if(srcFileName.Length > 0)
			{
				FileType fileType = null;
				FileUtility fileUtility = null;
				
				try
				{
					//get FileType and FileUtility
					fileType = FileType.Current.GetFileType(srcFileName);
					fileUtility = fileType.CreateUtility(srcFileName);
				}
				catch(Exception)
				{
					Console.WriteLine("Unknown file type.");
					throw;
				}
				
				//get key as stream
				Stream keyStream = StringToStream(keyText);
				
				//perform action
				Console.WriteLine("Reading ...");
				Stream messageStream = fileUtility.Extract(keyStream);
				messageStream.Position = 0;
				
				//display result
				StreamReader reader = new StreamReader(messageStream, Encoding.Default);
				string message = reader.ReadToEnd();
				Console.WriteLine(message);
			}
		}
		
		private static Stream StringToStream(string text)
		{
			MemoryStream textStream = new MemoryStream();
			byte[] textBytes = Encoding.Default.GetBytes(text);
			textStream.Write(textBytes, 0, textBytes.Length);
			textStream.Position = 0;
			return textStream;
		}
	}
}