﻿using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Text;

namespace SteganoOrder
{
    public class OrderUtility
    {
        public static long GetCapacity(long listLength)
        {
            BigInteger capacity = new BigInteger(listLength);
            capacity = Factorial(capacity);
            int byteCapacity = (capacity.bitCount() / 8) - 1;
            return byteCapacity;
        }

        private static BigInteger Factorial(BigInteger value)
        {
            BigInteger result = new BigInteger(value);
            BigInteger counter = new BigInteger(value-1);

            while(counter > 0)
            {
                result *= counter;
                counter--;
            }
            return result;
        }

        public static void Encode<T>(Collection<T> source, Collection<T> result, Stream messageStream)
            where T: class, IComparable
        {
            T[] sortedItems = new T[source.Count];
            source.CopyTo(sortedItems, 0);
            Array.Sort(sortedItems);
            
            // initialize message
            messageStream.Position = 0;
            byte[] buffer = new byte[messageStream.Length];
            messageStream.Read(buffer, 0, buffer.Length);
            BigInteger message = new BigInteger(buffer);
            
            // initialize carrier
            Collection<int> freeIndexes = new Collection<int>();
            result.Clear();
            for (int n = 0; n < source.Count; n++)
            {
                freeIndexes.Add(n);
                result.Add(null);
            }

            int skip = 0;
            for (int indexSource = 0; indexSource < source.Count; indexSource++)
            {
                skip = (message % freeIndexes.Count).IntValue();
                message = message / freeIndexes.Count;
                int resultIndex = freeIndexes[skip];
                result[resultIndex] = sortedItems[indexSource];
                freeIndexes.RemoveAt(skip);
            }
        }

        public static void Decode<T>(Collection<T> carrier, Stream messageStream)
            where T : class, IComparable
        {
            T[] sortedItems = new T[carrier.Count];
            carrier.CopyTo(sortedItems, 0);
            Array.Sort(sortedItems);
            
            BigInteger message = new BigInteger(0);

            for (int carrierIndex = 0; carrierIndex < carrier.Count; carrierIndex++)
            {
                int skip = 0;
                for (int countIndex = 0; countIndex < carrierIndex; countIndex++)
                {
                    if (carrier[countIndex].CompareTo(carrier[carrierIndex]) > 0)
                    {   // There is a bigger item to the left. It's place
                        // must have been skipped by the current item.
                        skip++;
                    }
                }

                // Revert the division that resulted in this skip value
                int itemOrdinal = Array.IndexOf(sortedItems, carrier[carrierIndex])+1;
                BigInteger value = new BigInteger(skip);
                for (int countIndex = 1; countIndex < itemOrdinal; countIndex++)
                {
                    value *= (carrier.Count - countIndex + 1);
                }
                message += value;
            }

            byte[] messageBytes = message.getBytes();
            messageStream.Write(messageBytes, 0, messageBytes.Length);
            messageStream.Position = 0;
        }
    }
}
