using System;
using System.Text;
using System.Collections.ObjectModel;
using System.IO;
using System.Windows.Forms;
using System.Xml;

namespace SteganoOrder
{
    public partial class Form1 : Form
    {
        private long capacityGC = -1;
        private long capacityAddrBook = -1;
        private long capacityPlainNumbers = -1;
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string geoFileName = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "demo.gpx");
            if (File.Exists(geoFileName))
            {
                ImportGC(geoFileName, lstGC);
            }

            string[] items = txtSourceAddrBook.Text.Split(',');
            capacityAddrBook = CalculateCapacity(items.Length, lblRemainingCharsAddrBook, txtMessageAddrBook);
            capacityPlainNumbers = CalculateCapacity(255, lblRemainingCharsPlainNumbers, txtMessagePlainNumbers);
            capacityGC = CalculateCapacity(lstGC.Items.Count, lblRemainingCharsGC, txtMessageGC);
        }

        private void AddGeoCacheToList(GeoCache gc, ListView lst)
        {
            ListViewItem viewItem = new ListViewItem(gc.Name);
            viewItem.SubItems.Add(gc.CoordsText);
            viewItem.Tag = gc;
            lst.Items.Add(viewItem);
        }

        private Stream TextToStream(string text)
        {
            return new MemoryStream(Encoding.UTF8.GetBytes(text));
        }        

        private void btnEncode_Click(object sender, EventArgs e)
        {
            Stream message = TextToStream(txtMessagePlainNumbers.Text);
            
            Collection<IComparable> source = new Collection<IComparable>();
            for (int n = 1; n < 257; n++)
            {
                source.Add(n);
            }
            
            Collection<IComparable> result = new Collection<IComparable>();
            OrderUtility.Encode(source, result, message);

            txtCodePlainNumbers.Clear();
            foreach (int t in result)
            {
                txtCodePlainNumbers.Text += t.ToString() + ",";
            }
        }

        private void btnDecode_Click(object sender, EventArgs e)
        {
            // initialize carrier
            int c;
            Collection<IComparable> carrier = new Collection<IComparable>();
            string[] carrierStrings = txtCodePlainNumbers.Text.Split(new char[]{','}, StringSplitOptions.RemoveEmptyEntries);
            for (int n = 0; n < carrierStrings.Length; n++)
            {
                if (int.TryParse(carrierStrings[n], out c))
                {
                    carrier.Add(c);
                }
            }

            MemoryStream message = new MemoryStream();
            OrderUtility.Decode(carrier, message);

            txtMessagePlainNumbers.Text = new StreamReader(message).ReadToEnd();
        }

        private void btEncodeAdrBook_Click(object sender, EventArgs e)
        {
            Collection<IComparable> source = new Collection<IComparable>();
            string[] sourceStrings = txtSourceAddrBook.Text.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string s in sourceStrings)
            {
                source.Add(s.Trim());
            }

            Stream message = TextToStream(txtMessageAddrBook.Text);
            Collection<IComparable> result = new Collection<IComparable>();
            OrderUtility.Encode(source, result, message);

            txtCodeAddrBook.Clear();
            foreach (string t in result)
            {
                txtCodeAddrBook.Text += t + ",";
            }
        }

        private void btnDecodeAdrBook_Click(object sender, EventArgs e)
        {
            Collection<IComparable> carrier = new Collection<IComparable>();
            string[] carrierStrings = txtCodeAddrBook.Text.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string s in carrierStrings)
            {
                carrier.Add(s.Trim());
            }
            
            MemoryStream message = new MemoryStream();
            OrderUtility.Decode(carrier, message);

            txtMessageAddrBook.Text = new StreamReader(message).ReadToEnd();
        }

        private string GetGCSortPropertyName()
        {
            if (rdoGCOrderByName.Checked) { return "Name"; }
            if (rdoGCOrderByTitle.Checked) { return "Title"; }
            if (rdoGCOrderByLon.Checked) { return "Longitude"; }
            return "Latitude";
        }

        private void btnEncodeGC_Click(object sender, EventArgs e)
        {
            FlexibleComparableCollection<GeoCache> source = new FlexibleComparableCollection<GeoCache>();
            foreach (ListViewItem viewItem in lstGC.Items)
            {
                source.Add((GeoCache)viewItem.Tag);
            }
            source.ComparablePropertyName = GetGCSortPropertyName();

            Stream message = TextToStream(txtMessageGC.Text);
            Collection<GeoCache> result = new Collection<GeoCache>();

            OrderUtility.Encode<GeoCache>(source, result, message);

            lstResultGC.Items.Clear();
            foreach (GeoCache g in result)
            {
                AddGeoCacheToList(g, lstResultGC);
            }
        }

        private void btnDecodeGC_Click(object sender, EventArgs e)
        {
            FlexibleComparableCollection<GeoCache> carrier = new FlexibleComparableCollection<GeoCache>();
            foreach (ListViewItem viewItem in lstResultGC.Items)
            {
                carrier.Add((GeoCache)viewItem.Tag);
            }
            carrier.ComparablePropertyName = GetGCSortPropertyName();

            MemoryStream message = new MemoryStream();
            OrderUtility.Decode<GeoCache>(carrier, message);

            txtMessageGC.Text = new StreamReader(message).ReadToEnd();
        }

        private void lstGC_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                RemoveSelectedItems(lstGC);
            }
        }

        private void lstResultGC_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                RemoveSelectedItems(lstResultGC);
            }
        }

        private void RemoveSelectedItems(ListView lst)
        {
            while (lstGC.SelectedItems.Count > 0)
            {
                lstGC.Items.Remove(lstGC.SelectedItems[0]);
            }
        }

        private void btmImportSourceGC_Click(object sender, EventArgs e)
        {
            ImportGC(lstGC);
            capacityGC = CalculateCapacity(lstGC.Items.Count, lblRemainingCharsGC, txtMessageGC);
        }

        private long CalculateCapacity(long listLength, Label lblRemainingChars, TextBox txtMessage)
        {
            long capacity = OrderUtility.GetCapacity(listLength);
            if (capacity < 0 || capacity > 32767)
            {
                txtMessage.MaxLength = 32767; // default
            }
            else
            {
                txtMessage.MaxLength = (int)capacity;
            }
            if (txtMessage.Text.Length > txtMessage.MaxLength)
            {
                txtMessage.Text = txtMessage.Text.Substring(0, txtMessage.MaxLength);
            }
            UpdateCapacityInfo(capacity, lblRemainingChars, txtMessage);
            return capacity;
        }

        private void UpdateCapacityInfo(long capacity, Label lblRemainingChars, TextBox txtMessage)
        {
            if (capacity < 0)
            {
                lblRemainingChars.Text = "????";
            }
            else
            {
                lblRemainingChars.Text = (capacity - txtMessage.Text.Length).ToString();
            }
        }

        private void btmImportCodeGC_Click(object sender, EventArgs e)
        {
            ImportGC(lstResultGC);
        }

        private void ImportGC(ListView lst)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Multiselect = true;
            if (dlg.ShowDialog(this) == DialogResult.OK)
            {
                foreach (string fileName in dlg.FileNames)
                {
                    ImportGC(fileName, lst);
                }
            }
        }

        private void ImportGC(string fileName, ListView lst)
        {
            XmlDocument gpxDocument = new XmlDocument();
            gpxDocument.Load(fileName);

            if (fileName.ToLower().EndsWith(".gpx"))
            {
                XmlNodeList wayPointNodes = gpxDocument.GetElementsByTagName("wpt");

                foreach (XmlNode geoNode in wayPointNodes)
                {
                    GeoCache g = new GeoCache();

                    foreach (XmlNode childNode in geoNode.ChildNodes)
                    {
                        if (childNode.Name.ToLower() == "name")
                        {
                            g.Name = childNode.FirstChild.Value;
                            g.Title = g.Name;
                            break;
                        }
                    }
                    if (geoNode.Attributes["lon"] != null)
                    {
                        g.Longitude = geoNode.Attributes["lon"].Value;
                    }
                    if (geoNode.Attributes["lat"] != null)
                    {
                        g.Latitude = geoNode.Attributes["lat"].Value;
                    }
                    AddGeoCacheToList(g, lst);
                }
            }
            else
            {
                XmlNodeList wayPointNodes = gpxDocument.GetElementsByTagName("waypoint");

                foreach (XmlNode geoNode in wayPointNodes)
                {
                    GeoCache g = new GeoCache();

                    foreach (XmlNode childNode in geoNode.ChildNodes)
                    {
                        if (childNode.Name.ToLower() == "name")
                        {
                            g.Title = childNode.FirstChild.Value;
                            if (childNode.Attributes["id"] != null)
                            {
                                g.Name = childNode.Attributes["id"].Value;
                            }
                            break;
                        }
                    }
                    
                    XmlNode coordNode = geoNode.SelectSingleNode("coord");
                    if (coordNode != null)
                    {
                        if (coordNode.Attributes["lon"] != null)
                        {
                            g.Longitude = coordNode.Attributes["lon"].Value;
                        }
                        if (coordNode.Attributes["lat"] != null)
                        {
                            g.Latitude = coordNode.Attributes["lat"].Value;
                        }
                    }

                    AddGeoCacheToList(g, lst);
                }
            }
        }
    

        private void btnExportSourceGC_Click(object sender, EventArgs e)
        {
            ExportGC(lstGC);
        }

        private void btnExportCodeGC_Click(object sender, EventArgs e)
        {
            ExportGC(lstResultGC);
        }

        private void ExportGC(ListView lst)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            if(dlg.ShowDialog(this) == DialogResult.OK){
                
                XmlTextWriter gpxWriter = new XmlTextWriter(dlg.FileName, Encoding.UTF8);
                gpxWriter.Formatting = Formatting.Indented;
                gpxWriter.WriteStartDocument(true);
                
                if (dlg.FileName.ToLower().EndsWith(".gpx"))
                {
                    // write GPX header
                    gpxWriter.WriteStartElement("gpx");
                    gpxWriter.WriteAttributeString("version", "1.0");
                    gpxWriter.WriteAttributeString("xmlns", "http://www.topografix.com/GPX/1/0");
                    gpxWriter.WriteAttributeString("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
                    gpxWriter.WriteAttributeString("xsi:schemaLocation", "http://www.topografix.com/GPX/1/0 http://www.topografix.com/GPX/1/0/gpx.xsd");

                    foreach (ListViewItem viewItem in lst.Items)
                    {
                        GeoCache item = (GeoCache)viewItem.Tag;
                        gpxWriter.WriteStartElement("wpt");
                        gpxWriter.WriteAttributeString("lat", item.Latitude);
                        gpxWriter.WriteAttributeString("lon", item.Longitude);

                        gpxWriter.WriteStartElement("name");
                        gpxWriter.WriteCData(item.Name);
                        gpxWriter.WriteEndElement();

                        // end of "wpt"
                        gpxWriter.WriteEndElement();
                    }
                }
                else
                {
                    // write LOC header
                    gpxWriter.WriteStartElement("loc");
                    gpxWriter.WriteAttributeString("version", "1.0");

                    foreach (ListViewItem viewItem in lst.Items)
                    {
                        GeoCache item = (GeoCache)viewItem.Tag;

                        gpxWriter.WriteStartElement("waypoint");
                        
                        gpxWriter.WriteStartElement("name");
                        gpxWriter.WriteAttributeString("id", item.Name);
                        gpxWriter.WriteCData(item.Title);
                        gpxWriter.WriteEndElement();

                        gpxWriter.WriteStartElement("coord");
                        gpxWriter.WriteAttributeString("lat", item.Latitude);
                        gpxWriter.WriteAttributeString("lon", item.Longitude);
                        gpxWriter.WriteEndElement();

                        gpxWriter.WriteElementString("type", "Geocache");

                        if (item.Name.StartsWith("GC"))
                        {
                            gpxWriter.WriteStartElement("link");
                            gpxWriter.WriteAttributeString("text", "Cache Details");
                            gpxWriter.WriteValue("http://www.geocaching.com/seek/cache_details.aspx?wp=" + item.Name);
                            gpxWriter.WriteEndElement();
                        }

                        // end of "waypoint"
                        gpxWriter.WriteEndElement();
                    }
                }

                gpxWriter.WriteEndDocument();
                gpxWriter.Close();

                MessageBox.Show("Finished");
            }
        }

        private void btnClearSourceGC_Click(object sender, EventArgs e)
        {
            lstGC.Items.Clear();
            capacityGC = CalculateCapacity(lstGC.Items.Count, lblRemainingCharsGC, txtMessageGC);
        }

        private void btnClearCodeGC_Click(object sender, EventArgs e)
        {
            lstResultGC.Items.Clear();
        }

        private void btnGCAdd_Click(object sender, EventArgs e)
        {
            GeoCache g = new GeoCache(txtGCName.Text, txtGCTitle.Text, txtGCLon.Text, txtGCLat.Text);
            AddGeoCacheToList(g, lstGC);
            capacityGC = CalculateCapacity(lstGC.Items.Count, lblRemainingCharsGC, txtMessageGC);
        }

        private void btnGCUpdate_Click(object sender, EventArgs e)
        {
            if (lstGC.SelectedItems.Count > 0)
            {
                ListViewItem viewItem = lstGC.SelectedItems[0];
                GeoCache g = viewItem.Tag as GeoCache;
                g.Name = txtGCName.Text;
                g.Title = txtGCTitle.Text;
                g.Longitude = txtGCLon.Text;
                g.Latitude = txtGCLat.Text;
                viewItem.Text = g.Name;
                viewItem.SubItems[1].Text = g.CoordsText;
                capacityGC = CalculateCapacity(lstGC.Items.Count, lblRemainingCharsGC, txtMessageGC);
            }
        }

        private void btnGCRemove_Click(object sender, EventArgs e)
        {
            RemoveSelectedItems(lstGC);
            capacityGC = CalculateCapacity(lstGC.Items.Count, lblRemainingCharsGC, txtMessageGC);
        }

        private void lstGC_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstGC.SelectedItems.Count > 0)
            {
                GeoCache g = lstGC.SelectedItems[0].Tag as GeoCache;
                txtGCName.Text = g.Name;
                txtGCTitle.Text = g.Title;
                txtGCLat.Text = g.Latitude;
                txtGCLon.Text = g.Longitude;
            }
        }

        private void txtMessageGC_TextChanged(object sender, EventArgs e)
        {
            UpdateCapacityInfo(capacityGC, lblRemainingCharsGC, txtMessageGC);
        }

        private void txtMessageAddrBook_TextChanged(object sender, EventArgs e)
        {
            UpdateCapacityInfo(capacityAddrBook, lblRemainingCharsAddrBook, txtMessageAddrBook);
        }

        private void txtSourceAddrBook_TextChanged(object sender, EventArgs e)
        {
            string[] items = txtSourceAddrBook.Text.Split(',');
            capacityAddrBook = CalculateCapacity(items.Length, lblRemainingCharsAddrBook, txtMessageAddrBook);
        }

        private void txtMessagePlainNumbers_TextChanged(object sender, EventArgs e)
        {
            capacityAddrBook = CalculateCapacity(255, lblRemainingCharsPlainNumbers, txtMessagePlainNumbers);
        }

    }
}
