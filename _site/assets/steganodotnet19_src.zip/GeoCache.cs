﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SteganoOrder
{
    internal class GeoCache : FlexibleComparable
    {
        private string name;
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        private string title;
        public string Title
        {
            get { return title; }
            set { title = value; }
        }

        private string longitude;
        public string Longitude
        {
            get { return longitude; }
            set { longitude = value; }
        }

        private string latitude;
        public string Latitude
        {
            get { return latitude; }
            set { latitude = value; }
        }

        public string CoordsText
        {
            get
            {
                return this.latitude + " - " + this.longitude;
            }
        }

        public GeoCache()
        {
            this.name = string.Empty;
            this.title = string.Empty;
            this.longitude = string.Empty;
            this.latitude = string.Empty;
        }

        public GeoCache(string name, string title, string lon, string lat)
        {
            this.name = name;
            this.title = title;
            this.longitude = lon;
            this.latitude = lat;
        }
    }
}
