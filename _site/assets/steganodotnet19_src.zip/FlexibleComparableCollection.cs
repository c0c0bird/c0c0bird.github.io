using System;
using System.Collections.ObjectModel;
using System.Reflection;
using System.Text;

namespace SteganoOrder
{
    public class FlexibleComparableCollection<T> : Collection<T>
        where T : FlexibleComparable
    {
        private PropertyInfo comparableProperty;

        public string ComparablePropertyName
        {
            get
            {
                if (this.comparableProperty != null)
                {
                    return this.comparableProperty.Name;
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                this.comparableProperty = typeof(T).GetProperty(value);

                foreach (FlexibleComparable item in this.Items)
                {
                    item.UpdateComparableValue(this.comparableProperty);
                }
            }
        }
    }
}
