namespace SteganoOrder
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtCodePlainNumbers = new System.Windows.Forms.TextBox();
            this.txtMessagePlainNumbers = new System.Windows.Forms.TextBox();
            this.btnEncodePlainNumbers = new System.Windows.Forms.Button();
            this.btnDecodePlainNumbers = new System.Windows.Forms.Button();
            this.txtSourceAddrBook = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtMessageAddrBook = new System.Windows.Forms.TextBox();
            this.btnDecodeAddrBook = new System.Windows.Forms.Button();
            this.txtCodeAddrBook = new System.Windows.Forms.TextBox();
            this.btEncodeAddrBook = new System.Windows.Forms.Button();
            this.txtGCName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtGCTitle = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtGCLon = new System.Windows.Forms.TextBox();
            this.txtGCLat = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.lstGC = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.btnGCAdd = new System.Windows.Forms.Button();
            this.btnGCUpdate = new System.Windows.Forms.Button();
            this.btnGCRemove = new System.Windows.Forms.Button();
            this.rdoGCOrderByName = new System.Windows.Forms.RadioButton();
            this.rdoGCOrderByTitle = new System.Windows.Forms.RadioButton();
            this.rdoGCOrderByLat = new System.Windows.Forms.RadioButton();
            this.rdoGCOrderByLon = new System.Windows.Forms.RadioButton();
            this.txtMessageGC = new System.Windows.Forms.TextBox();
            this.lstResultGC = new System.Windows.Forms.ListView();
            this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabGC = new System.Windows.Forms.TabPage();
            this.label9 = new System.Windows.Forms.Label();
            this.lblRemainingCharsGC = new System.Windows.Forms.Label();
            this.btnClearCodeGC = new System.Windows.Forms.Button();
            this.btmImportCodeGC = new System.Windows.Forms.Button();
            this.btnExportCodeGC = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.grpSourceGC = new System.Windows.Forms.GroupBox();
            this.btnExportSourceGC = new System.Windows.Forms.Button();
            this.btnClearSourceGC = new System.Windows.Forms.Button();
            this.btmImportSourceGC = new System.Windows.Forms.Button();
            this.btnDecodeGC = new System.Windows.Forms.Button();
            this.btnEncodeGC = new System.Windows.Forms.Button();
            this.tabAddrBook = new System.Windows.Forms.TabPage();
            this.label6 = new System.Windows.Forms.Label();
            this.lblRemainingCharsAddrBook = new System.Windows.Forms.Label();
            this.tabPlainNumbers = new System.Windows.Forms.TabPage();
            this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
            this.label7 = new System.Windows.Forms.Label();
            this.lblRemainingCharsPlainNumbers = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabGC.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.grpSourceGC.SuspendLayout();
            this.tabAddrBook.SuspendLayout();
            this.tabPlainNumbers.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtCodePlainNumbers
            // 
            this.txtCodePlainNumbers.Location = new System.Drawing.Point(275, 12);
            this.txtCodePlainNumbers.Multiline = true;
            this.txtCodePlainNumbers.Name = "txtCodePlainNumbers";
            this.txtCodePlainNumbers.Size = new System.Drawing.Size(160, 243);
            this.txtCodePlainNumbers.TabIndex = 0;
            // 
            // txtMessagePlainNumbers
            // 
            this.txtMessagePlainNumbers.Location = new System.Drawing.Point(14, 12);
            this.txtMessagePlainNumbers.Multiline = true;
            this.txtMessagePlainNumbers.Name = "txtMessagePlainNumbers";
            this.txtMessagePlainNumbers.Size = new System.Drawing.Size(153, 243);
            this.txtMessagePlainNumbers.TabIndex = 1;
            this.txtMessagePlainNumbers.Text = "text";
            this.txtMessagePlainNumbers.TextChanged += new System.EventHandler(this.txtMessagePlainNumbers_TextChanged);
            // 
            // btnEncodePlainNumbers
            // 
            this.btnEncodePlainNumbers.Location = new System.Drawing.Point(173, 103);
            this.btnEncodePlainNumbers.Name = "btnEncodePlainNumbers";
            this.btnEncodePlainNumbers.Size = new System.Drawing.Size(96, 27);
            this.btnEncodePlainNumbers.TabIndex = 2;
            this.btnEncodePlainNumbers.Text = ">> Encode >>";
            this.btnEncodePlainNumbers.UseVisualStyleBackColor = true;
            this.btnEncodePlainNumbers.Click += new System.EventHandler(this.btnEncode_Click);
            // 
            // btnDecodePlainNumbers
            // 
            this.btnDecodePlainNumbers.Location = new System.Drawing.Point(173, 132);
            this.btnDecodePlainNumbers.Name = "btnDecodePlainNumbers";
            this.btnDecodePlainNumbers.Size = new System.Drawing.Size(96, 27);
            this.btnDecodePlainNumbers.TabIndex = 2;
            this.btnDecodePlainNumbers.Text = "<< Decode <<";
            this.btnDecodePlainNumbers.UseVisualStyleBackColor = true;
            this.btnDecodePlainNumbers.Click += new System.EventHandler(this.btnDecode_Click);
            // 
            // txtSourceAddrBook
            // 
            this.txtSourceAddrBook.Location = new System.Drawing.Point(14, 36);
            this.txtSourceAddrBook.Multiline = true;
            this.txtSourceAddrBook.Name = "txtSourceAddrBook";
            this.txtSourceAddrBook.Size = new System.Drawing.Size(421, 52);
            this.txtSourceAddrBook.TabIndex = 4;
            this.txtSourceAddrBook.Text = "Anna, Paul, Maja, Tom, Larissa, Richard, Mary, Andrew, Sandra, Ian, Mira, Michael" +
                ", Lea, Leo, Tanja, Viktor, Danielle, David, Vanessa, Cory, Lisa, Jim";
            this.txtSourceAddrBook.TextChanged += new System.EventHandler(this.txtSourceAddrBook_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Source List";
            // 
            // txtMessageAddrBook
            // 
            this.txtMessageAddrBook.Location = new System.Drawing.Point(14, 94);
            this.txtMessageAddrBook.Multiline = true;
            this.txtMessageAddrBook.Name = "txtMessageAddrBook";
            this.txtMessageAddrBook.Size = new System.Drawing.Size(153, 160);
            this.txtMessageAddrBook.TabIndex = 7;
            this.txtMessageAddrBook.Text = "text";
            this.txtMessageAddrBook.TextChanged += new System.EventHandler(this.txtMessageAddrBook_TextChanged);
            // 
            // btnDecodeAddrBook
            // 
            this.btnDecodeAddrBook.Location = new System.Drawing.Point(173, 179);
            this.btnDecodeAddrBook.Name = "btnDecodeAddrBook";
            this.btnDecodeAddrBook.Size = new System.Drawing.Size(96, 23);
            this.btnDecodeAddrBook.TabIndex = 9;
            this.btnDecodeAddrBook.Text = "<< Decode <<";
            this.btnDecodeAddrBook.UseVisualStyleBackColor = true;
            this.btnDecodeAddrBook.Click += new System.EventHandler(this.btnDecodeAdrBook_Click);
            // 
            // txtCodeAddrBook
            // 
            this.txtCodeAddrBook.Location = new System.Drawing.Point(275, 94);
            this.txtCodeAddrBook.Multiline = true;
            this.txtCodeAddrBook.Name = "txtCodeAddrBook";
            this.txtCodeAddrBook.Size = new System.Drawing.Size(160, 160);
            this.txtCodeAddrBook.TabIndex = 6;
            // 
            // btEncodeAddrBook
            // 
            this.btEncodeAddrBook.Location = new System.Drawing.Point(173, 150);
            this.btEncodeAddrBook.Name = "btEncodeAddrBook";
            this.btEncodeAddrBook.Size = new System.Drawing.Size(96, 23);
            this.btEncodeAddrBook.TabIndex = 8;
            this.btEncodeAddrBook.Text = ">> Encode >>";
            this.btEncodeAddrBook.UseVisualStyleBackColor = true;
            this.btEncodeAddrBook.Click += new System.EventHandler(this.btEncodeAdrBook_Click);
            // 
            // txtGCName
            // 
            this.txtGCName.Location = new System.Drawing.Point(59, 120);
            this.txtGCName.Name = "txtGCName";
            this.txtGCName.Size = new System.Drawing.Size(100, 20);
            this.txtGCName.TabIndex = 11;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 123);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 12;
            this.label2.Text = "Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(171, 123);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 13);
            this.label3.TabIndex = 14;
            this.label3.Text = "Title";
            // 
            // txtGCTitle
            // 
            this.txtGCTitle.Location = new System.Drawing.Point(204, 120);
            this.txtGCTitle.Name = "txtGCTitle";
            this.txtGCTitle.Size = new System.Drawing.Size(100, 20);
            this.txtGCTitle.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 149);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(28, 13);
            this.label4.TabIndex = 16;
            this.label4.Text = "Lon.";
            // 
            // txtGCLon
            // 
            this.txtGCLon.Location = new System.Drawing.Point(59, 146);
            this.txtGCLon.Name = "txtGCLon";
            this.txtGCLon.Size = new System.Drawing.Size(100, 20);
            this.txtGCLon.TabIndex = 15;
            // 
            // txtGCLat
            // 
            this.txtGCLat.Location = new System.Drawing.Point(204, 146);
            this.txtGCLat.Name = "txtGCLat";
            this.txtGCLat.Size = new System.Drawing.Size(100, 20);
            this.txtGCLat.TabIndex = 17;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(171, 149);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(25, 13);
            this.label5.TabIndex = 18;
            this.label5.Text = "Lat.";
            // 
            // lstGC
            // 
            this.lstGC.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.lstGC.FullRowSelect = true;
            this.lstGC.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lstGC.HideSelection = false;
            this.lstGC.Location = new System.Drawing.Point(15, 44);
            this.lstGC.Name = "lstGC";
            this.lstGC.Size = new System.Drawing.Size(289, 70);
            this.lstGC.TabIndex = 19;
            this.lstGC.UseCompatibleStateImageBehavior = false;
            this.lstGC.View = System.Windows.Forms.View.Details;
            this.lstGC.SelectedIndexChanged += new System.EventHandler(this.lstGC_SelectedIndexChanged);
            this.lstGC.KeyDown += new System.Windows.Forms.KeyEventHandler(this.lstGC_KeyDown);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "GeoCache";
            this.columnHeader1.Width = 80;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Coordinates";
            this.columnHeader2.Width = 190;
            // 
            // btnGCAdd
            // 
            this.btnGCAdd.Location = new System.Drawing.Point(21, 172);
            this.btnGCAdd.Name = "btnGCAdd";
            this.btnGCAdd.Size = new System.Drawing.Size(75, 23);
            this.btnGCAdd.TabIndex = 20;
            this.btnGCAdd.Text = "Add";
            this.btnGCAdd.UseVisualStyleBackColor = true;
            this.btnGCAdd.Click += new System.EventHandler(this.btnGCAdd_Click);
            // 
            // btnGCUpdate
            // 
            this.btnGCUpdate.Location = new System.Drawing.Point(123, 172);
            this.btnGCUpdate.Name = "btnGCUpdate";
            this.btnGCUpdate.Size = new System.Drawing.Size(75, 23);
            this.btnGCUpdate.TabIndex = 21;
            this.btnGCUpdate.Text = "Update";
            this.btnGCUpdate.UseVisualStyleBackColor = true;
            this.btnGCUpdate.Click += new System.EventHandler(this.btnGCUpdate_Click);
            // 
            // btnGCRemove
            // 
            this.btnGCRemove.Location = new System.Drawing.Point(229, 172);
            this.btnGCRemove.Name = "btnGCRemove";
            this.btnGCRemove.Size = new System.Drawing.Size(75, 23);
            this.btnGCRemove.TabIndex = 22;
            this.btnGCRemove.Text = "Remove";
            this.btnGCRemove.UseVisualStyleBackColor = true;
            this.btnGCRemove.Click += new System.EventHandler(this.btnGCRemove_Click);
            // 
            // rdoGCOrderByName
            // 
            this.rdoGCOrderByName.AutoSize = true;
            this.rdoGCOrderByName.Checked = true;
            this.rdoGCOrderByName.Location = new System.Drawing.Point(20, 28);
            this.rdoGCOrderByName.Name = "rdoGCOrderByName";
            this.rdoGCOrderByName.Size = new System.Drawing.Size(53, 17);
            this.rdoGCOrderByName.TabIndex = 23;
            this.rdoGCOrderByName.TabStop = true;
            this.rdoGCOrderByName.Text = "Name";
            this.rdoGCOrderByName.UseVisualStyleBackColor = true;
            // 
            // rdoGCOrderByTitle
            // 
            this.rdoGCOrderByTitle.AutoSize = true;
            this.rdoGCOrderByTitle.Location = new System.Drawing.Point(20, 51);
            this.rdoGCOrderByTitle.Name = "rdoGCOrderByTitle";
            this.rdoGCOrderByTitle.Size = new System.Drawing.Size(45, 17);
            this.rdoGCOrderByTitle.TabIndex = 24;
            this.rdoGCOrderByTitle.Text = "Title";
            this.rdoGCOrderByTitle.UseVisualStyleBackColor = true;
            // 
            // rdoGCOrderByLat
            // 
            this.rdoGCOrderByLat.AutoSize = true;
            this.rdoGCOrderByLat.Location = new System.Drawing.Point(20, 74);
            this.rdoGCOrderByLat.Name = "rdoGCOrderByLat";
            this.rdoGCOrderByLat.Size = new System.Drawing.Size(63, 17);
            this.rdoGCOrderByLat.TabIndex = 23;
            this.rdoGCOrderByLat.Text = "Latitude";
            this.rdoGCOrderByLat.UseVisualStyleBackColor = true;
            // 
            // rdoGCOrderByLon
            // 
            this.rdoGCOrderByLon.AutoSize = true;
            this.rdoGCOrderByLon.Location = new System.Drawing.Point(20, 97);
            this.rdoGCOrderByLon.Name = "rdoGCOrderByLon";
            this.rdoGCOrderByLon.Size = new System.Drawing.Size(72, 17);
            this.rdoGCOrderByLon.TabIndex = 24;
            this.rdoGCOrderByLon.Text = "Longitude";
            this.rdoGCOrderByLon.UseVisualStyleBackColor = true;
            // 
            // txtMessageGC
            // 
            this.txtMessageGC.Location = new System.Drawing.Point(34, 256);
            this.txtMessageGC.Multiline = true;
            this.txtMessageGC.Name = "txtMessageGC";
            this.txtMessageGC.Size = new System.Drawing.Size(289, 42);
            this.txtMessageGC.TabIndex = 26;
            this.txtMessageGC.Text = "text";
            this.txtMessageGC.TextChanged += new System.EventHandler(this.txtMessageGC_TextChanged);
            // 
            // lstResultGC
            // 
            this.lstResultGC.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader3,
            this.columnHeader4});
            this.lstResultGC.FullRowSelect = true;
            this.lstResultGC.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lstResultGC.HideSelection = false;
            this.lstResultGC.Location = new System.Drawing.Point(34, 377);
            this.lstResultGC.Name = "lstResultGC";
            this.lstResultGC.Size = new System.Drawing.Size(289, 66);
            this.lstResultGC.TabIndex = 29;
            this.lstResultGC.UseCompatibleStateImageBehavior = false;
            this.lstResultGC.View = System.Windows.Forms.View.Details;
            this.lstResultGC.KeyDown += new System.Windows.Forms.KeyEventHandler(this.lstResultGC_KeyDown);
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "GeoCache";
            this.columnHeader3.Width = 80;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabGC);
            this.tabControl1.Controls.Add(this.tabAddrBook);
            this.tabControl1.Controls.Add(this.tabPlainNumbers);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(506, 487);
            this.tabControl1.TabIndex = 30;
            // 
            // tabGC
            // 
            this.tabGC.Controls.Add(this.label9);
            this.tabGC.Controls.Add(this.lblRemainingCharsGC);
            this.tabGC.Controls.Add(this.btnClearCodeGC);
            this.tabGC.Controls.Add(this.btmImportCodeGC);
            this.tabGC.Controls.Add(this.btnExportCodeGC);
            this.tabGC.Controls.Add(this.groupBox1);
            this.tabGC.Controls.Add(this.grpSourceGC);
            this.tabGC.Controls.Add(this.lstResultGC);
            this.tabGC.Controls.Add(this.txtMessageGC);
            this.tabGC.Controls.Add(this.btnDecodeGC);
            this.tabGC.Controls.Add(this.btnEncodeGC);
            this.tabGC.Location = new System.Drawing.Point(4, 22);
            this.tabGC.Name = "tabGC";
            this.tabGC.Padding = new System.Windows.Forms.Padding(3);
            this.tabGC.Size = new System.Drawing.Size(498, 461);
            this.tabGC.TabIndex = 0;
            this.tabGC.Text = "GeoCaches";
            this.tabGC.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(354, 283);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(106, 13);
            this.label9.TabIndex = 35;
            this.label9.Text = "Characters remaining";
            // 
            // lblRemainingCharsGC
            // 
            this.lblRemainingCharsGC.AutoSize = true;
            this.lblRemainingCharsGC.Location = new System.Drawing.Point(326, 283);
            this.lblRemainingCharsGC.Name = "lblRemainingCharsGC";
            this.lblRemainingCharsGC.Size = new System.Drawing.Size(31, 13);
            this.lblRemainingCharsGC.TabIndex = 35;
            this.lblRemainingCharsGC.Text = "????";
            // 
            // btnClearCodeGC
            // 
            this.btnClearCodeGC.Location = new System.Drawing.Point(280, 355);
            this.btnClearCodeGC.Name = "btnClearCodeGC";
            this.btnClearCodeGC.Size = new System.Drawing.Size(43, 23);
            this.btnClearCodeGC.TabIndex = 34;
            this.btnClearCodeGC.Text = "Clear";
            this.btnClearCodeGC.UseVisualStyleBackColor = true;
            this.btnClearCodeGC.Click += new System.EventHandler(this.btnClearCodeGC_Click);
            // 
            // btmImportCodeGC
            // 
            this.btmImportCodeGC.Location = new System.Drawing.Point(34, 355);
            this.btmImportCodeGC.Name = "btmImportCodeGC";
            this.btmImportCodeGC.Size = new System.Drawing.Size(122, 23);
            this.btmImportCodeGC.TabIndex = 33;
            this.btmImportCodeGC.Text = "Import from File";
            this.btmImportCodeGC.UseVisualStyleBackColor = true;
            this.btmImportCodeGC.Click += new System.EventHandler(this.btmImportCodeGC_Click);
            // 
            // btnExportCodeGC
            // 
            this.btnExportCodeGC.Location = new System.Drawing.Point(157, 355);
            this.btnExportCodeGC.Name = "btnExportCodeGC";
            this.btnExportCodeGC.Size = new System.Drawing.Size(122, 23);
            this.btnExportCodeGC.TabIndex = 32;
            this.btnExportCodeGC.Text = "Export to File";
            this.btnExportCodeGC.UseVisualStyleBackColor = true;
            this.btnExportCodeGC.Click += new System.EventHandler(this.btnExportCodeGC_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdoGCOrderByName);
            this.groupBox1.Controls.Add(this.rdoGCOrderByLat);
            this.groupBox1.Controls.Add(this.rdoGCOrderByTitle);
            this.groupBox1.Controls.Add(this.rdoGCOrderByLon);
            this.groupBox1.Location = new System.Drawing.Point(366, 16);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(112, 206);
            this.groupBox1.TabIndex = 31;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sort Key";
            // 
            // grpSourceGC
            // 
            this.grpSourceGC.Controls.Add(this.btnExportSourceGC);
            this.grpSourceGC.Controls.Add(this.btnClearSourceGC);
            this.grpSourceGC.Controls.Add(this.btmImportSourceGC);
            this.grpSourceGC.Controls.Add(this.lstGC);
            this.grpSourceGC.Controls.Add(this.btnGCUpdate);
            this.grpSourceGC.Controls.Add(this.btnGCAdd);
            this.grpSourceGC.Controls.Add(this.txtGCName);
            this.grpSourceGC.Controls.Add(this.btnGCRemove);
            this.grpSourceGC.Controls.Add(this.label5);
            this.grpSourceGC.Controls.Add(this.label2);
            this.grpSourceGC.Controls.Add(this.txtGCLat);
            this.grpSourceGC.Controls.Add(this.label4);
            this.grpSourceGC.Controls.Add(this.txtGCTitle);
            this.grpSourceGC.Controls.Add(this.txtGCLon);
            this.grpSourceGC.Controls.Add(this.label3);
            this.grpSourceGC.Location = new System.Drawing.Point(19, 16);
            this.grpSourceGC.Name = "grpSourceGC";
            this.grpSourceGC.Size = new System.Drawing.Size(330, 206);
            this.grpSourceGC.TabIndex = 30;
            this.grpSourceGC.TabStop = false;
            this.grpSourceGC.Text = "Source List";
            // 
            // btnExportSourceGC
            // 
            this.btnExportSourceGC.Location = new System.Drawing.Point(138, 22);
            this.btnExportSourceGC.Name = "btnExportSourceGC";
            this.btnExportSourceGC.Size = new System.Drawing.Size(122, 23);
            this.btnExportSourceGC.TabIndex = 25;
            this.btnExportSourceGC.Text = "Export to File";
            this.btnExportSourceGC.UseVisualStyleBackColor = true;
            this.btnExportSourceGC.Click += new System.EventHandler(this.btnExportSourceGC_Click);
            // 
            // btnClearSourceGC
            // 
            this.btnClearSourceGC.Location = new System.Drawing.Point(261, 22);
            this.btnClearSourceGC.Name = "btnClearSourceGC";
            this.btnClearSourceGC.Size = new System.Drawing.Size(43, 23);
            this.btnClearSourceGC.TabIndex = 24;
            this.btnClearSourceGC.Text = "Clear";
            this.btnClearSourceGC.UseVisualStyleBackColor = true;
            this.btnClearSourceGC.Click += new System.EventHandler(this.btnClearSourceGC_Click);
            // 
            // btmImportSourceGC
            // 
            this.btmImportSourceGC.Location = new System.Drawing.Point(15, 22);
            this.btmImportSourceGC.Name = "btmImportSourceGC";
            this.btmImportSourceGC.Size = new System.Drawing.Size(122, 23);
            this.btmImportSourceGC.TabIndex = 23;
            this.btmImportSourceGC.Text = "Import from File";
            this.btmImportSourceGC.UseVisualStyleBackColor = true;
            this.btmImportSourceGC.Click += new System.EventHandler(this.btmImportSourceGC_Click);
            // 
            // btnDecodeGC
            // 
            this.btnDecodeGC.Image = global::SteganoOrder.Properties.Resources.sortUp;
            this.btnDecodeGC.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDecodeGC.Location = new System.Drawing.Point(193, 304);
            this.btnDecodeGC.Name = "btnDecodeGC";
            this.btnDecodeGC.Size = new System.Drawing.Size(96, 42);
            this.btnDecodeGC.TabIndex = 28;
            this.btnDecodeGC.Text = "Decode";
            this.btnDecodeGC.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDecodeGC.UseVisualStyleBackColor = true;
            this.btnDecodeGC.Click += new System.EventHandler(this.btnDecodeGC_Click);
            // 
            // btnEncodeGC
            // 
            this.btnEncodeGC.Image = global::SteganoOrder.Properties.Resources.sortDown;
            this.btnEncodeGC.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEncodeGC.Location = new System.Drawing.Point(60, 304);
            this.btnEncodeGC.Name = "btnEncodeGC";
            this.btnEncodeGC.Size = new System.Drawing.Size(96, 42);
            this.btnEncodeGC.TabIndex = 27;
            this.btnEncodeGC.Text = "Encode";
            this.btnEncodeGC.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEncodeGC.UseVisualStyleBackColor = true;
            this.btnEncodeGC.Click += new System.EventHandler(this.btnEncodeGC_Click);
            // 
            // tabAddrBook
            // 
            this.tabAddrBook.Controls.Add(this.label6);
            this.tabAddrBook.Controls.Add(this.lblRemainingCharsAddrBook);
            this.tabAddrBook.Controls.Add(this.txtSourceAddrBook);
            this.tabAddrBook.Controls.Add(this.txtMessageAddrBook);
            this.tabAddrBook.Controls.Add(this.txtCodeAddrBook);
            this.tabAddrBook.Controls.Add(this.label1);
            this.tabAddrBook.Controls.Add(this.btEncodeAddrBook);
            this.tabAddrBook.Controls.Add(this.btnDecodeAddrBook);
            this.tabAddrBook.Location = new System.Drawing.Point(4, 22);
            this.tabAddrBook.Name = "tabAddrBook";
            this.tabAddrBook.Padding = new System.Windows.Forms.Padding(3);
            this.tabAddrBook.Size = new System.Drawing.Size(498, 461);
            this.tabAddrBook.TabIndex = 1;
            this.tabAddrBook.Text = "Lists of Words";
            this.tabAddrBook.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(42, 257);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(106, 13);
            this.label6.TabIndex = 37;
            this.label6.Text = "Characters remaining";
            // 
            // lblRemainingCharsAddrBook
            // 
            this.lblRemainingCharsAddrBook.AutoSize = true;
            this.lblRemainingCharsAddrBook.Location = new System.Drawing.Point(14, 257);
            this.lblRemainingCharsAddrBook.Name = "lblRemainingCharsAddrBook";
            this.lblRemainingCharsAddrBook.Size = new System.Drawing.Size(31, 13);
            this.lblRemainingCharsAddrBook.TabIndex = 36;
            this.lblRemainingCharsAddrBook.Text = "????";
            // 
            // tabPlainNumbers
            // 
            this.tabPlainNumbers.Controls.Add(this.label7);
            this.tabPlainNumbers.Controls.Add(this.lblRemainingCharsPlainNumbers);
            this.tabPlainNumbers.Controls.Add(this.txtMessagePlainNumbers);
            this.tabPlainNumbers.Controls.Add(this.btnDecodePlainNumbers);
            this.tabPlainNumbers.Controls.Add(this.btnEncodePlainNumbers);
            this.tabPlainNumbers.Controls.Add(this.txtCodePlainNumbers);
            this.tabPlainNumbers.Location = new System.Drawing.Point(4, 22);
            this.tabPlainNumbers.Name = "tabPlainNumbers";
            this.tabPlainNumbers.Size = new System.Drawing.Size(498, 461);
            this.tabPlainNumbers.TabIndex = 2;
            this.tabPlainNumbers.Text = "Plain Numbers";
            this.tabPlainNumbers.UseVisualStyleBackColor = true;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Coordinates";
            this.columnHeader4.Width = 190;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(43, 258);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(106, 13);
            this.label7.TabIndex = 39;
            this.label7.Text = "Characters remaining";
            // 
            // lblRemainingCharsPlainNumbers
            // 
            this.lblRemainingCharsPlainNumbers.AutoSize = true;
            this.lblRemainingCharsPlainNumbers.Location = new System.Drawing.Point(15, 258);
            this.lblRemainingCharsPlainNumbers.Name = "lblRemainingCharsPlainNumbers";
            this.lblRemainingCharsPlainNumbers.Size = new System.Drawing.Size(31, 13);
            this.lblRemainingCharsPlainNumbers.TabIndex = 38;
            this.lblRemainingCharsPlainNumbers.Text = "????";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(533, 511);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.Text = "GeoText - More Meaning to your Waypoints";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabGC.ResumeLayout(false);
            this.tabGC.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.grpSourceGC.ResumeLayout(false);
            this.grpSourceGC.PerformLayout();
            this.tabAddrBook.ResumeLayout(false);
            this.tabAddrBook.PerformLayout();
            this.tabPlainNumbers.ResumeLayout(false);
            this.tabPlainNumbers.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtCodePlainNumbers;
        private System.Windows.Forms.TextBox txtMessagePlainNumbers;
        private System.Windows.Forms.Button btnEncodePlainNumbers;
        private System.Windows.Forms.Button btnDecodePlainNumbers;
        private System.Windows.Forms.TextBox txtSourceAddrBook;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtMessageAddrBook;
        private System.Windows.Forms.Button btnDecodeAddrBook;
        private System.Windows.Forms.TextBox txtCodeAddrBook;
        private System.Windows.Forms.Button btEncodeAddrBook;
        private System.Windows.Forms.TextBox txtGCName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtGCTitle;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtGCLon;
        private System.Windows.Forms.TextBox txtGCLat;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListView lstGC;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.Button btnGCAdd;
        private System.Windows.Forms.Button btnGCUpdate;
        private System.Windows.Forms.Button btnGCRemove;
        private System.Windows.Forms.RadioButton rdoGCOrderByName;
        private System.Windows.Forms.RadioButton rdoGCOrderByTitle;
        private System.Windows.Forms.RadioButton rdoGCOrderByLat;
        private System.Windows.Forms.RadioButton rdoGCOrderByLon;
        private System.Windows.Forms.TextBox txtMessageGC;
        private System.Windows.Forms.Button btnDecodeGC;
        private System.Windows.Forms.Button btnEncodeGC;
        private System.Windows.Forms.ListView lstResultGC;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabGC;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox grpSourceGC;
        private System.Windows.Forms.TabPage tabAddrBook;
        private System.Windows.Forms.TabPage tabPlainNumbers;
        private System.Windows.Forms.Button btmImportSourceGC;
        private System.Windows.Forms.Button btnExportCodeGC;
        private System.Windows.Forms.Button btnExportSourceGC;
        private System.Windows.Forms.Button btnClearSourceGC;
        private System.Windows.Forms.Button btnClearCodeGC;
        private System.Windows.Forms.Button btmImportCodeGC;
        private System.Windows.Forms.Label lblRemainingCharsGC;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblRemainingCharsAddrBook;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblRemainingCharsPlainNumbers;
    }
}

