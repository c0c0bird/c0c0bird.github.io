using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace SteganoOrder
{
    public class FlexibleComparable : IComparable
    {
        private object comparableValue;

        internal void UpdateComparableValue(PropertyInfo comparableProperty)
        {
            this.comparableValue = comparableProperty.GetValue(this, null);
        }

        #region IComparable Member

        public int CompareTo(object obj)
        {
            IComparable thisValue = this.comparableValue as IComparable;
            if (thisValue == null)
            {
                return -1;
            }
            
            IComparable otherValue;
            FlexibleComparable other = obj as FlexibleComparable;
            if (other == null)
            {
                otherValue = other as IComparable;
            }
            else
            {
                otherValue = other.comparableValue as IComparable;
            }

            if (otherValue == null)
            {
                return 1;
            }
            else
            {
                return thisValue.CompareTo(otherValue);
            }
        }

        #endregion
    }
}
