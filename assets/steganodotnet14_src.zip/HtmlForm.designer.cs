﻿namespace SteganoList {
    partial class HtmlForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.btnCleanFileName = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.btnAlphabetFileName = new System.Windows.Forms.Button();
            this.txtAlphabetFileName = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnCarrierFileName = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtMessage = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.lblCapacity = new System.Windows.Forms.Label();
            this.btnExtract = new System.Windows.Forms.Button();
            this.btnHide = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
// 
// btnCleanFileName
// 
            this.btnCleanFileName.Location = new System.Drawing.Point(16, 27);
            this.btnCleanFileName.Name = "btnCleanFileName";
            this.btnCleanFileName.Size = new System.Drawing.Size(201, 21);
            this.btnCleanFileName.TabIndex = 8;
            this.btnCleanFileName.Text = "Load HTML File...";
            this.btnCleanFileName.Click += new System.EventHandler(this.btnCleanFileName_Click);
// 
// label6
// 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 19);
            this.label6.Margin = new System.Windows.Forms.Padding(3, 3, 3, 1);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(217, 14);
            this.label6.TabIndex = 22;
            this.label6.Text = "Alphabet File (Empty for Normal Alphabet)";
// 
// btnAlphabetFileName
// 
            this.btnAlphabetFileName.Location = new System.Drawing.Point(494, 33);
            this.btnAlphabetFileName.Name = "btnAlphabetFileName";
            this.btnAlphabetFileName.TabIndex = 21;
            this.btnAlphabetFileName.Text = "Browse...";
            this.btnAlphabetFileName.Click += new System.EventHandler(this.btnAlphabetFileName_Click);
// 
// txtAlphabetFileName
// 
            this.txtAlphabetFileName.Location = new System.Drawing.Point(13, 35);
            this.txtAlphabetFileName.Margin = new System.Windows.Forms.Padding(3, 1, 3, 3);
            this.txtAlphabetFileName.Name = "txtAlphabetFileName";
            this.txtAlphabetFileName.Size = new System.Drawing.Size(474, 20);
            this.txtAlphabetFileName.TabIndex = 20;
// 
// groupBox2
// 
            this.groupBox2.Controls.Add(this.btnCarrierFileName);
            this.groupBox2.Location = new System.Drawing.Point(333, 80);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(236, 171);
            this.groupBox2.TabIndex = 19;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Carrier with Hidden Message";
// 
// btnCarrierFileName
// 
            this.btnCarrierFileName.Location = new System.Drawing.Point(19, 27);
            this.btnCarrierFileName.Name = "btnCarrierFileName";
            this.btnCarrierFileName.Size = new System.Drawing.Size(201, 21);
            this.btnCarrierFileName.TabIndex = 9;
            this.btnCarrierFileName.Text = "Load HTML File...";
            this.btnCarrierFileName.Click += new System.EventHandler(this.btnCarrierFileName_Click);
// 
// groupBox1
// 
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txtMessage);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.lblCapacity);
            this.groupBox1.Controls.Add(this.btnCleanFileName);
            this.groupBox1.Location = new System.Drawing.Point(13, 80);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(240, 171);
            this.groupBox1.TabIndex = 18;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Carrier and Secret Message";
// 
// label7
// 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 110);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 14);
            this.label7.TabIndex = 7;
            this.label7.Text = "Message";
// 
// txtMessage
// 
            this.txtMessage.AutoSize = false;
            this.txtMessage.Location = new System.Drawing.Point(66, 107);
            this.txtMessage.Multiline = true;
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.Size = new System.Drawing.Size(151, 45);
            this.txtMessage.TabIndex = 6;
// 
// label8
// 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(16, 74);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(95, 14);
            this.label8.TabIndex = 5;
            this.label8.Text = "Capacity in Bytes:";
// 
// lblCapacity
// 
            this.lblCapacity.AutoSize = true;
            this.lblCapacity.Location = new System.Drawing.Point(207, 74);
            this.lblCapacity.Name = "lblCapacity";
            this.lblCapacity.Size = new System.Drawing.Size(10, 14);
            this.lblCapacity.TabIndex = 4;
            this.lblCapacity.Text = "0";
// 
// btnExtract
// 
            this.btnExtract.Location = new System.Drawing.Point(260, 170);
            this.btnExtract.Name = "btnExtract";
            this.btnExtract.Size = new System.Drawing.Size(66, 50);
            this.btnExtract.TabIndex = 17;
            this.btnExtract.Text = "<< Extract";
            this.btnExtract.Click += new System.EventHandler(this.btnExtract_Click);
// 
// btnHide
// 
            this.btnHide.Location = new System.Drawing.Point(260, 113);
            this.btnHide.Name = "btnHide";
            this.btnHide.Size = new System.Drawing.Size(66, 50);
            this.btnHide.TabIndex = 16;
            this.btnHide.Text = "Hide >>";
            this.btnHide.Click += new System.EventHandler(this.btnHide_Click);
// 
// HtmlForm
// 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(584, 262);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btnAlphabetFileName);
            this.Controls.Add(this.txtAlphabetFileName);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnExtract);
            this.Controls.Add(this.btnHide);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "HtmlForm";
            this.Text = "Open an HTML File and  Enter a Message, or Open an HTML File with an Embedded Mes" +
                "sage";
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCleanFileName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnAlphabetFileName;
        private System.Windows.Forms.TextBox txtAlphabetFileName;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtMessage;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblCapacity;
        private System.Windows.Forms.Button btnExtract;
        private System.Windows.Forms.Button btnHide;
        private System.Windows.Forms.Button btnCarrierFileName;
    }
}