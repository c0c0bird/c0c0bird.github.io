﻿namespace SteganoList {
    partial class PaletteForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picCleanImage = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtMessage = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblCapacity = new System.Windows.Forms.Label();
            this.btnLoadCleanImage = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnSaveCleanImage = new System.Windows.Forms.Button();
            this.btnExtract = new System.Windows.Forms.Button();
            this.btnHide = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnSaveCarrierImage = new System.Windows.Forms.Button();
            this.picCarrierImage = new System.Windows.Forms.PictureBox();
            this.btnLoadCarrierImage = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picCleanImage)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picCarrierImage)).BeginInit();
            this.SuspendLayout();
// 
// picCleanImage
// 
            this.picCleanImage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picCleanImage.Location = new System.Drawing.Point(17, 29);
            this.picCleanImage.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.picCleanImage.Name = "picCleanImage";
            this.picCleanImage.Size = new System.Drawing.Size(215, 158);
            this.picCleanImage.TabIndex = 0;
            this.picCleanImage.TabStop = false;
// 
// label2
// 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 305);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 14);
            this.label2.TabIndex = 11;
            this.label2.Text = "Message";
// 
// txtMessage
// 
            this.txtMessage.AutoSize = false;
            this.txtMessage.Location = new System.Drawing.Point(81, 302);
            this.txtMessage.Multiline = true;
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.Size = new System.Drawing.Size(151, 45);
            this.txtMessage.TabIndex = 10;
// 
// label1
// 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 267);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 14);
            this.label1.TabIndex = 9;
            this.label1.Text = "Capacity in Bytes:";
// 
// lblCapacity
// 
            this.lblCapacity.AutoSize = true;
            this.lblCapacity.Location = new System.Drawing.Point(222, 267);
            this.lblCapacity.Name = "lblCapacity";
            this.lblCapacity.Size = new System.Drawing.Size(10, 14);
            this.lblCapacity.TabIndex = 8;
            this.lblCapacity.Text = "0";
// 
// btnLoadCleanImage
// 
            this.btnLoadCleanImage.Location = new System.Drawing.Point(17, 188);
            this.btnLoadCleanImage.Margin = new System.Windows.Forms.Padding(3, 1, 3, 3);
            this.btnLoadCleanImage.Name = "btnLoadCleanImage";
            this.btnLoadCleanImage.Size = new System.Drawing.Size(215, 23);
            this.btnLoadCleanImage.TabIndex = 12;
            this.btnLoadCleanImage.Text = "Load Image...";
            this.btnLoadCleanImage.Click += new System.EventHandler(this.btnLoadCleanImage_Click);
// 
// groupBox1
// 
            this.groupBox1.Controls.Add(this.btnSaveCleanImage);
            this.groupBox1.Controls.Add(this.picCleanImage);
            this.groupBox1.Controls.Add(this.btnLoadCleanImage);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtMessage);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.lblCapacity);
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(248, 363);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Carrier and Secret Message";
// 
// btnSaveCleanImage
// 
            this.btnSaveCleanImage.Location = new System.Drawing.Point(17, 216);
            this.btnSaveCleanImage.Margin = new System.Windows.Forms.Padding(3, 1, 3, 3);
            this.btnSaveCleanImage.Name = "btnSaveCleanImage";
            this.btnSaveCleanImage.Size = new System.Drawing.Size(215, 23);
            this.btnSaveCleanImage.TabIndex = 16;
            this.btnSaveCleanImage.Text = "Save Image...";
            this.btnSaveCleanImage.Click += new System.EventHandler(this.btnSaveCleanImage_Click);
// 
// btnExtract
// 
            this.btnExtract.Location = new System.Drawing.Point(269, 191);
            this.btnExtract.Name = "btnExtract";
            this.btnExtract.Size = new System.Drawing.Size(66, 50);
            this.btnExtract.TabIndex = 15;
            this.btnExtract.Text = "<< Extract";
            this.btnExtract.Click += new System.EventHandler(this.btnExtract_Click);
// 
// btnHide
// 
            this.btnHide.Location = new System.Drawing.Point(269, 134);
            this.btnHide.Name = "btnHide";
            this.btnHide.Size = new System.Drawing.Size(66, 50);
            this.btnHide.TabIndex = 14;
            this.btnHide.Text = "Hide >>";
            this.btnHide.Click += new System.EventHandler(this.btnHide_Click);
// 
// groupBox2
// 
            this.groupBox2.Controls.Add(this.btnSaveCarrierImage);
            this.groupBox2.Controls.Add(this.picCarrierImage);
            this.groupBox2.Controls.Add(this.btnLoadCarrierImage);
            this.groupBox2.Location = new System.Drawing.Point(342, 13);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(248, 363);
            this.groupBox2.TabIndex = 16;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Carrier with Hidden Message";
// 
// btnSaveCarrierImage
// 
            this.btnSaveCarrierImage.Location = new System.Drawing.Point(16, 217);
            this.btnSaveCarrierImage.Margin = new System.Windows.Forms.Padding(3, 1, 3, 3);
            this.btnSaveCarrierImage.Name = "btnSaveCarrierImage";
            this.btnSaveCarrierImage.Size = new System.Drawing.Size(215, 23);
            this.btnSaveCarrierImage.TabIndex = 15;
            this.btnSaveCarrierImage.Text = "Save Image...";
            this.btnSaveCarrierImage.Click += new System.EventHandler(this.btnSaveCarrierImage_Click);
// 
// picCarrierImage
// 
            this.picCarrierImage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picCarrierImage.Location = new System.Drawing.Point(16, 30);
            this.picCarrierImage.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.picCarrierImage.Name = "picCarrierImage";
            this.picCarrierImage.Size = new System.Drawing.Size(215, 158);
            this.picCarrierImage.TabIndex = 13;
            this.picCarrierImage.TabStop = false;
// 
// btnLoadCarrierImage
// 
            this.btnLoadCarrierImage.Location = new System.Drawing.Point(16, 189);
            this.btnLoadCarrierImage.Margin = new System.Windows.Forms.Padding(3, 1, 3, 3);
            this.btnLoadCarrierImage.Name = "btnLoadCarrierImage";
            this.btnLoadCarrierImage.Size = new System.Drawing.Size(215, 23);
            this.btnLoadCarrierImage.TabIndex = 14;
            this.btnLoadCarrierImage.Text = "Load Image...";
            this.btnLoadCarrierImage.Click += new System.EventHandler(this.btnLoadCarrierImage_Click);
// 
// PaletteForm
// 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(604, 389);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnExtract);
            this.Controls.Add(this.btnHide);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "PaletteForm";
            this.Text = "Open an Image and  Enter a Message, or Open an Image with an Embedded Message";
            ((System.ComponentModel.ISupportInitialize)(this.picCleanImage)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picCarrierImage)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox picCleanImage;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtMessage;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblCapacity;
        private System.Windows.Forms.Button btnLoadCleanImage;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnExtract;
        private System.Windows.Forms.Button btnHide;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.PictureBox picCarrierImage;
        private System.Windows.Forms.Button btnLoadCarrierImage;
        private System.Windows.Forms.Button btnSaveCarrierImage;
        private System.Windows.Forms.Button btnSaveCleanImage;
    }
}