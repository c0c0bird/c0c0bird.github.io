﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

#endregion

namespace SteganoList {
    partial class StartForm : Form {

        private Form nextForm;

        public Form NextForm
        {
            get { return nextForm; }
        }

        public StartForm()
        {
            InitializeComponent();
            this.DialogResult = DialogResult.Cancel;
        }

        private void btnPalette_Click(object sender, EventArgs e)
        {
            nextForm = new PaletteForm();
            this.DialogResult = DialogResult.OK;
            Close();
        }

        private void btnList_Click(object sender, EventArgs e)
        {
            nextForm = new ListForm();
            this.DialogResult = DialogResult.OK;
            Close();
        }

        private void btnHtml_Click(object sender, EventArgs e)
        {
            nextForm = new HtmlForm();
            this.DialogResult = DialogResult.OK;
            Close();
        }
    }
}