﻿/* This class has been written by
 * Corinna John (Hannover, Germany)
 * cj@binary-universe.net
 * 
 * You may do with this code whatever you like,
 * except selling it or claiming any rights/ownership.
 * 
 * Please send me a little feedback about what you're
 * using this code for and what changes you'd like to
 * see in later versions. (And please excuse my bad english.)
 * 
 * WARNING: This is experimental code.
 * Exception handling has been omitted,
 * to keep the code readable to people who want
 * to understand the algorithm.
 * Please do not expect "Release Quality".
 * */

#region Using directives

using System;
using System.Collections.Specialized;
using System.Text;

#endregion

namespace SteganoList {
    public class HtmlTag {

        private enum PostionInTag {
            AttributeName,
            AttributeValue,
            Space
        }

        public int beginPosition;
        public int endPosition;
        private String name;

        public int BeginPosition {
            get { return beginPosition; }
            set { beginPosition = value; }
        }

        public int EndPosition {
            get { return endPosition; }
            set { endPosition = value; }
        }

        public String Name {
            get { return name; }
        }

        private HtmlAttributeCollection attributes;
        public HtmlAttributeCollection Attributes {
            get { return attributes; }
        }

        public HtmlTag(String text, int beginPosition, int endPosition) {
            this.beginPosition = beginPosition;
            this.endPosition = endPosition;
            this.attributes = new HtmlAttributeCollection();

            //separate tag name and attributes
            int index = text.IndexOf(' ');
            if (index < 0) {
                //this is a tag without any attributes
                name = text.Substring(1, text.Length - 1);
            } else {
                name = text.Substring(1, index - 1);
            }

            if (index > 0) {
                text = text.Substring(index);

                //find and list all attributes in this tag
                
                PostionInTag status = PostionInTag.Space;
                int startIndex = 0;
                String attributeName;
                String attributeValue;
                char attributeValueQuotation = '\'';
                HtmlAttribute attribute = null;
                for (int n = 1; n < text.Length; n++) {

                    if ((status == PostionInTag.Space) && ((text[n] == '\'') || (text[n] == '\"'))) {
                        //begin value
                        startIndex = n;
                        attributeValueQuotation = text[n];
                        status = PostionInTag.AttributeValue;
                    }
                    
                    else if ((status == PostionInTag.AttributeValue) && (text[n] == attributeValueQuotation)) {
                        //end value

                        if (attribute != null) {
                            attributeValue = text.Substring(startIndex, n + 1 - startIndex);
                            attribute.Value = attributeValue;
                            attribute = null;
                        }

                        status = PostionInTag.Space;
                    }
                    
                    else if ((status == PostionInTag.Space) && (text[n] != ' ')) {
                        //begin attribute
                        status = PostionInTag.AttributeName;
                        startIndex = n;
                    }
                    
                    else if ((status == PostionInTag.AttributeName) && ((text[n] == '=') || Char.IsWhiteSpace(text[n]) || (n == text.Length-1))) {
                        //end name
                        if (n == text.Length - 1) {
                            //Correct string cursor position.
                            //This is the last character of the tag.
                            //The last attribute does not have a value.
                            n++;
                        }
                        attributeName = text.Substring(startIndex, n - startIndex);
                        
                        attribute = new HtmlAttribute(attributeName);
                        attributes.Add(attribute);

                        status = PostionInTag.Space;
                    }
                    
                    else if ((status != PostionInTag.AttributeValue) && (text[n] == ' ')) {
                        status = PostionInTag.Space;
                    }

                }
            }
        }

        #region Inner Class HtmlAttribute

        public class HtmlAttribute {
            private String name;
            private String value;
            private bool handled;

            public String Name
            {
                get { return name; }
            }

            public String Value
            {
                get { return this.value; }
                set { this.value = value; }
            }

            public bool Handled
            {
                get { return handled; }
                set { this.handled = value; }
            }

            public HtmlAttribute(String name)
            {
                this.name = name.ToLower();
                this.value = String.Empty;
                handled = false;
            }
        }

        #endregion Inner Class HtmlAttribute
    }
}
