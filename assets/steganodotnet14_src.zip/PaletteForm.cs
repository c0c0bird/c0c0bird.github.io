﻿#region Using directives

using System;
using System.IO;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Text;
using System.Windows.Forms;

#endregion

namespace SteganoList {
    partial class PaletteForm : Form {

        public PaletteForm()
        {
            InitializeComponent();
        }


        private void btnHide_Click(object sender, EventArgs e)
        {
            if (picCleanImage.Image == null) {
                MessageBox.Show("Please open the carrier image first.");
            }else if(txtMessage.Text.Length == 0){
                MessageBox.Show("Please enter the message first.");
            } else {
                Stream message = Utilities.ToStream(txtMessage.Text, true);
                Image result = PaletteUtility.Hide((Bitmap)picCleanImage.Image, message);
                picCarrierImage.Image = result;
            }
        }

        private void btnExtract_Click(object sender, EventArgs e)
        {
            if (picCarrierImage.Image == null) {
                MessageBox.Show("Please open the carrier image first.");
            } else {
                Bitmap bitmap = (Bitmap)picCarrierImage.Image;

                //extract message
                Stream messageStream = PaletteUtility.Extract(ref bitmap);

                //display results
                StreamReader messageReader = new StreamReader(messageStream, Encoding.Default);
                txtMessage.Text = messageReader.ReadToEnd();
                picCleanImage.Image = bitmap;
            }
        }

        private Image LoadImage()
        {
            Image image = null;
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "Palette Images (*.gif, *.png)|*.gif;*.png";
            if (dlg.ShowDialog() != DialogResult.Cancel) {
                image = Image.FromFile(dlg.FileName);
                if (image.Palette.Entries.Length == 0) {
                    image.Dispose();
                    image = null;
                    MessageBox.Show("Cannot open file: No palette found.");
                }
            }
            return image;
        }

        private void SaveImage(Image image)
        {
            if (image == null) {
                MessageBox.Show("There is no picture to save.");
            } else {
                SaveFileDialog dlg = new SaveFileDialog();
                dlg.Filter = "Palette Images (*.gif, *.png)|*.gif;*.png";
                if (dlg.ShowDialog() != DialogResult.Cancel) {
                    image.Save(dlg.FileName);
                }
            }
        }

        private void btnLoadCleanImage_Click(object sender, EventArgs e)
        {
            Image image = LoadImage();
            if (image != null) {
                picCleanImage.Image = image;

                decimal countBytes = ((image.Palette.Entries.Length - 1) / 8);
                int capacity = (int)Math.Floor(countBytes);
                lblCapacity.Text = capacity.ToString();
                txtMessage.MaxLength = capacity;
            }
        }

        private void btnLoadCarrierImage_Click(object sender, EventArgs e)
        {
            Image image = LoadImage();
            if (image != null) {
                picCarrierImage.Image = image;
            }
        }

        private void btnSaveCarrierImage_Click(object sender, EventArgs e)
        {
            SaveImage(picCarrierImage.Image);
        }

        private void btnSaveCleanImage_Click(object sender, EventArgs e)
        {
            SaveImage(picCleanImage.Image);
        }

    }
}