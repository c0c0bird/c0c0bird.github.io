﻿#region Using directives

using System;
using System.IO;
using System.Text;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

#endregion

namespace SteganoList
{
    partial class ListForm : Form {
        public ListForm()
        {
            InitializeComponent();
        }

        private void btnHide_Click(object sender, EventArgs e)
        {
            Stream message = Utilities.ToStream(txtMessage.Text, false);
            txtOriginalList.Text = txtOriginalList.Text.TrimEnd(new char[] { '\r', '\n' });

            StringCollection resultList = ListUtility.Hide(txtOriginalList.Lines, message, txtAlphabetFileName.Text);

            DisplayStringList(resultList, txtResultList);
        }

        private void btnExtract_Click(object sender, EventArgs e)
        {
            txtResultList.Text = txtResultList.Text.TrimEnd(new char[] { '\r', '\n' });
            String[] lines = txtResultList.Lines;

            Stream messageStream = ListUtility.Extract(lines, txtAlphabetFileName.Text);
            StreamReader messageReader = new StreamReader(messageStream, Encoding.Default);

            //display original list
            DisplayStringList(lines, txtOriginalList);

            txtMessage.Text = messageReader.ReadToEnd();
        }

        private void DisplayStringList(IList lines, TextBox textBox)
        {
            StringBuilder listBuilder = new StringBuilder();
            foreach (String s in lines) {
                listBuilder.AppendLine(s);
            }
            textBox.Text = listBuilder.ToString();
        }

        private void txtOriginalList_TextChanged(object sender, EventArgs e)
        {
            decimal countBytes = (txtOriginalList.Lines.Length-1) / 8;
            int capacity = (int)Math.Floor(countBytes);
            lblCapacity.Text = capacity.ToString();
            txtMessage.MaxLength = capacity;
        }

        private void btnAlphabetFileName_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            if (dlg.ShowDialog() != DialogResult.Cancel) {
                txtAlphabetFileName.Text = dlg.FileName;
            }
        }
 }
}