﻿namespace SteganoList {
    partial class StartForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPalette = new System.Windows.Forms.Button();
            this.btnList = new System.Windows.Forms.Button();
            this.btnHtml = new System.Windows.Forms.Button();
            this.SuspendLayout();
// 
// btnPalette
// 
            this.btnPalette.Location = new System.Drawing.Point(44, 26);
            this.btnPalette.Name = "btnPalette";
            this.btnPalette.Size = new System.Drawing.Size(199, 23);
            this.btnPalette.TabIndex = 0;
            this.btnPalette.Text = "GIF / PNG Steganography Demo";
            this.btnPalette.Click += new System.EventHandler(this.btnPalette_Click);
// 
// btnList
// 
            this.btnList.Location = new System.Drawing.Point(44, 72);
            this.btnList.Name = "btnList";
            this.btnList.Size = new System.Drawing.Size(199, 23);
            this.btnList.TabIndex = 1;
            this.btnList.Text = "Text List Steganography Demo";
            this.btnList.Click += new System.EventHandler(this.btnList_Click);
// 
// btnHtml
// 
            this.btnHtml.Location = new System.Drawing.Point(44, 116);
            this.btnHtml.Name = "btnHtml";
            this.btnHtml.Size = new System.Drawing.Size(199, 23);
            this.btnHtml.TabIndex = 2;
            this.btnHtml.Text = "HTML Steganography Demo";
            this.btnHtml.Click += new System.EventHandler(this.btnHtml_Click);
// 
// StartForm
// 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(292, 165);
            this.Controls.Add(this.btnHtml);
            this.Controls.Add(this.btnList);
            this.Controls.Add(this.btnPalette);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "StartForm";
            this.Text = "Please Choose a Demo";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnPalette;
        private System.Windows.Forms.Button btnList;
        private System.Windows.Forms.Button btnHtml;
    }
}