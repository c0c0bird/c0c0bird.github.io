﻿namespace SteganoList
{
    partial class ListForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtOriginalList = new System.Windows.Forms.TextBox();
            this.txtResultList = new System.Windows.Forms.TextBox();
            this.btnHide = new System.Windows.Forms.Button();
            this.btnExtract = new System.Windows.Forms.Button();
            this.lblCapacity = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtMessage = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtAlphabetFileName = new System.Windows.Forms.TextBox();
            this.btnAlphabetFileName = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
// 
// txtOriginalList
// 
            this.txtOriginalList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtOriginalList.AutoSize = false;
            this.txtOriginalList.Location = new System.Drawing.Point(16, 20);
            this.txtOriginalList.Multiline = true;
            this.txtOriginalList.Name = "txtOriginalList";
            this.txtOriginalList.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtOriginalList.Size = new System.Drawing.Size(208, 287);
            this.txtOriginalList.TabIndex = 0;
            this.txtOriginalList.Text = "cat food\r\ndog food\r\ngrains for the birds\r\napples\r\nbread\r\nbanana juice\r\nmemory (25" +
                "6 MB)\r\nlemons\r\noranges\r\npizza\r\nsoap\r\npaper (white)\r\npotatos\r\nchips\r\nonions\r\nfroz" +
                "en hamburgers\r\nblack socks";
            this.txtOriginalList.TextChanged += new System.EventHandler(this.txtOriginalList_TextChanged);
// 
// txtResultList
// 
            this.txtResultList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtResultList.AutoSize = false;
            this.txtResultList.Location = new System.Drawing.Point(15, 20);
            this.txtResultList.Multiline = true;
            this.txtResultList.Name = "txtResultList";
            this.txtResultList.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtResultList.Size = new System.Drawing.Size(208, 287);
            this.txtResultList.TabIndex = 1;
// 
// btnHide
// 
            this.btnHide.Location = new System.Drawing.Point(269, 238);
            this.btnHide.Name = "btnHide";
            this.btnHide.Size = new System.Drawing.Size(66, 50);
            this.btnHide.TabIndex = 2;
            this.btnHide.Text = "Hide >>";
            this.btnHide.Click += new System.EventHandler(this.btnHide_Click);
// 
// btnExtract
// 
            this.btnExtract.Location = new System.Drawing.Point(269, 295);
            this.btnExtract.Name = "btnExtract";
            this.btnExtract.Size = new System.Drawing.Size(66, 50);
            this.btnExtract.TabIndex = 3;
            this.btnExtract.Text = "<< Extract";
            this.btnExtract.Click += new System.EventHandler(this.btnExtract_Click);
// 
// lblCapacity
// 
            this.lblCapacity.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblCapacity.AutoSize = true;
            this.lblCapacity.Location = new System.Drawing.Point(214, 336);
            this.lblCapacity.Name = "lblCapacity";
            this.lblCapacity.Size = new System.Drawing.Size(10, 14);
            this.lblCapacity.TabIndex = 4;
            this.lblCapacity.Text = "2";
// 
// label1
// 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 336);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 14);
            this.label1.TabIndex = 5;
            this.label1.Text = "Capacity in Bytes:";
// 
// txtMessage
// 
            this.txtMessage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtMessage.AutoSize = false;
            this.txtMessage.Location = new System.Drawing.Point(73, 369);
            this.txtMessage.MaxLength = 2;
            this.txtMessage.Multiline = true;
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.Size = new System.Drawing.Size(151, 45);
            this.txtMessage.TabIndex = 6;
// 
// label2
// 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 372);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 14);
            this.label2.TabIndex = 7;
            this.label2.Text = "Message";
// 
// groupBox1
// 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox1.Controls.Add(this.txtOriginalList);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtMessage);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.lblCapacity);
            this.groupBox1.Location = new System.Drawing.Point(22, 85);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(240, 432);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Carrier and Secret Message";
// 
// groupBox2
// 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox2.Controls.Add(this.txtResultList);
            this.groupBox2.Location = new System.Drawing.Point(342, 85);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(236, 432);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Carrier with Hidden Message";
// 
// txtAlphabetFileName
// 
            this.txtAlphabetFileName.Location = new System.Drawing.Point(22, 40);
            this.txtAlphabetFileName.Margin = new System.Windows.Forms.Padding(3, 1, 3, 3);
            this.txtAlphabetFileName.Name = "txtAlphabetFileName";
            this.txtAlphabetFileName.Size = new System.Drawing.Size(474, 20);
            this.txtAlphabetFileName.TabIndex = 13;
// 
// btnAlphabetFileName
// 
            this.btnAlphabetFileName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.btnAlphabetFileName.Location = new System.Drawing.Point(503, 38);
            this.btnAlphabetFileName.Name = "btnAlphabetFileName";
            this.btnAlphabetFileName.TabIndex = 14;
            this.btnAlphabetFileName.Text = "Browse...";
            this.btnAlphabetFileName.Click += new System.EventHandler(this.btnAlphabetFileName_Click);
// 
// label4
// 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 24);
            this.label4.Margin = new System.Windows.Forms.Padding(3, 3, 3, 1);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(217, 14);
            this.label4.TabIndex = 15;
            this.label4.Text = "Alphabet File (Empty for Normal Alphabet)";
// 
// ListForm
// 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(606, 529);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnAlphabetFileName);
            this.Controls.Add(this.txtAlphabetFileName);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnExtract);
            this.Controls.Add(this.btnHide);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "ListForm";
            this.Text = "Enter a List and  Message, or a List with an Embedded Message";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtMessage;
        private System.Windows.Forms.TextBox txtOriginalList;
        private System.Windows.Forms.TextBox txtResultList;
        private System.Windows.Forms.Button btnHide;
        private System.Windows.Forms.Button btnExtract;
        private System.Windows.Forms.Label lblCapacity;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtAlphabetFileName;
        private System.Windows.Forms.Button btnAlphabetFileName;
        private System.Windows.Forms.Label label4;
    }
}

