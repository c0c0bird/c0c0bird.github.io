﻿#region Using directives

using System;
using System.Collections;
using System.Text;

#endregion

namespace SteganoList {
    /// <summary>
    ///     <para>
    ///       A collection that stores <see cref='.HtmlAttribute'/> objects.
    ///    </para>
    /// </summary>
    /// <seealso cref='.HtmlAttributeCollection'/>
    [Serializable()]
    public class HtmlAttributeCollection : CollectionBase {

        /// <summary>
        ///     <para>
        ///       Initializes a new instance of <see cref='.HtmlAttributeCollection'/>.
        ///    </para>
        /// </summary>
        public HtmlAttributeCollection() {
        }

        /// <summary>Searches the Collection for an element with a specific Name value</summary>
        /// <param name="attributeName">Name of the attribute</param>
        /// <returns>Attribute, or null if the name was not found</returns>
        public HtmlTag.HtmlAttribute GetByName(String attributeName)
        {
            HtmlTag.HtmlAttribute foundAttribute = null;
            foreach (HtmlTag.HtmlAttribute attribute in this) {
                if (attribute.Name == attributeName) {
                    foundAttribute = attribute;
                    break;
                }
            }
            return foundAttribute;
        }

        /// <summary>
        ///     <para>
        ///       Initializes a new instance of <see cref='.HtmlAttributeCollection'/> based on another <see cref='.HtmlAttributeCollection'/>.
        ///    </para>
        /// </summary>
        /// <param name='value'>
        ///       A <see cref='.HtmlAttributeCollection'/> from which the contents are copied
        /// </param>
        public HtmlAttributeCollection(HtmlAttributeCollection val) {
            this.AddRange(val);
        }

        /// <summary>
        ///     <para>
        ///       Initializes a new instance of <see cref='.HtmlAttributeCollection'/> containing any array of <see cref='.HtmlAttribute'/> objects.
        ///    </para>
        /// </summary>
        /// <param name='value'>
        ///       A array of <see cref='.HtmlAttribute'/> objects with which to intialize the collection
        /// </param>
        public HtmlAttributeCollection(HtmlTag.HtmlAttribute[] val)
        {
            this.AddRange(val);
        }

        /// <summary>
        /// <para>Represents the entry at the specified index of the <see cref='.HtmlAttribute'/>.</para>
        /// </summary>
        /// <param name='index'><para>The zero-based index of the entry to locate in the collection.</para></param>
        /// <value>
        ///    <para> The entry at the specified index of the collection.</para>
        /// </value>
        /// <exception cref='System.ArgumentOutOfRangeException'><paramref name='index'/> is outside the valid range of indexes for the collection.</exception>
        public HtmlTag.HtmlAttribute this[int index] {
            get {
                return ((HtmlTag.HtmlAttribute)(List[index]));
            }
            set {
                List[index] = value;
            }
        }

        /// <summary>
        ///    <para>Adds a <see cref='.HtmlAttribute'/> with the specified value to the 
        ///    <see cref='.HtmlAttributeCollection'/> .</para>
        /// </summary>
        /// <param name='value'>The <see cref='.HtmlAttribute'/> to add.</param>
        /// <returns>
        ///    <para>The index at which the new element was inserted.</para>
        /// </returns>
        /// <seealso cref='.HtmlAttributeCollection.AddRange'/>
        public int Add(HtmlTag.HtmlAttribute val) {
            return List.Add(val);
        }

        /// <summary>
        /// <para>Copies the elements of an array to the end of the <see cref='.HtmlAttributeCollection'/>.</para>
        /// </summary>
        /// <param name='value'>
        ///    An array of type <see cref='.HtmlAttribute'/> containing the objects to add to the collection.
        /// </param>
        /// <returns>
        ///   <para>None.</para>
        /// </returns>
        /// <seealso cref='.HtmlAttributeCollection.Add'/>
        public void AddRange(HtmlTag.HtmlAttribute[] val) {
            for (int i = 0; i < val.Length; i++) {
                this.Add(val[i]);
            }
        }

        /// <summary>
        ///     <para>
        ///       Adds the contents of another <see cref='.HtmlAttributeCollection'/> to the end of the collection.
        ///    </para>
        /// </summary>
        /// <param name='value'>
        ///    A <see cref='.HtmlAttributeCollection'/> containing the objects to add to the collection.
        /// </param>
        /// <returns>
        ///   <para>None.</para>
        /// </returns>
        /// <seealso cref='.HtmlAttributeCollection.Add'/>
        public void AddRange(HtmlAttributeCollection val) {
            for (int i = 0; i < val.Count; i++) {
                this.Add(val[i]);
            }
        }

        /// <summary>
        /// <para>Gets a value indicating whether the 
        ///    <see cref='.HtmlAttributeCollection'/> contains the specified <see cref='.HtmlAttribute'/>.</para>
        /// </summary>
        /// <param name='value'>The <see cref='.HtmlAttribute'/> to locate.</param>
        /// <returns>
        /// <para><see langword='true'/> if the <see cref='.HtmlAttribute'/> is contained in the collection; 
        ///   otherwise, <see langword='false'/>.</para>
        /// </returns>
        /// <seealso cref='.HtmlAttributeCollection.IndexOf'/>
        public bool Contains(HtmlTag.HtmlAttribute val) {
            return List.Contains(val);
        }

        /// <summary>
        /// <para>Copies the <see cref='.HtmlAttributeCollection'/> values to a one-dimensional <see cref='System.Array'/> instance at the 
        ///    specified index.</para>
        /// </summary>
        /// <param name='array'><para>The one-dimensional <see cref='System.Array'/> that is the destination of the values copied from <see cref='.HtmlAttributeCollection'/> .</para></param>
        /// <param name='index'>The index in <paramref name='array'/> where copying begins.</param>
        /// <returns>
        ///   <para>None.</para>
        /// </returns>
        /// <exception cref='System.ArgumentException'><para><paramref name='array'/> is multidimensional.</para> <para>-or-</para> <para>The number of elements in the <see cref='.HtmlAttributeCollection'/> is greater than the available space between <paramref name='arrayIndex'/> and the end of <paramref name='array'/>.</para></exception>
        /// <exception cref='System.ArgumentNullException'><paramref name='array'/> is <see langword='null'/>. </exception>
        /// <exception cref='System.ArgumentOutOfRangeException'><paramref name='arrayIndex'/> is less than <paramref name='array'/>'s lowbound. </exception>
        /// <seealso cref='System.Array'/>
        public void CopyTo(HtmlTag.HtmlAttribute[] array, int index) {
            List.CopyTo(array, index);
        }

        /// <summary>
        ///    <para>Returns the index of a <see cref='.HtmlAttribute'/> in 
        ///       the <see cref='.HtmlAttributeCollection'/> .</para>
        /// </summary>
        /// <param name='value'>The <see cref='.HtmlAttribute'/> to locate.</param>
        /// <returns>
        /// <para>The index of the <see cref='.HtmlAttribute'/> of <paramref name='value'/> in the 
        /// <see cref='.HtmlAttributeCollection'/>, if found; otherwise, -1.</para>
        /// </returns>
        /// <seealso cref='.HtmlAttributeCollection.Contains'/>
        public int IndexOf(HtmlTag.HtmlAttribute val) {
            return List.IndexOf(val);
        }

        /// <summary>
        /// <para>Inserts a <see cref='.HtmlAttribute'/> into the <see cref='.HtmlAttributeCollection'/> at the specified index.</para>
        /// </summary>
        /// <param name='index'>The zero-based index where <paramref name='value'/> should be inserted.</param>
        /// <param name=' value'>The <see cref='.HtmlAttribute'/> to insert.</param>
        /// <returns><para>None.</para></returns>
        /// <seealso cref='.HtmlAttributeCollection.Add'/>
        public void Insert(int index, HtmlTag.HtmlAttribute val) {
            List.Insert(index, val);
        }

        /// <summary>
        ///    <para>Returns an enumerator that can iterate through 
        ///       the <see cref='.HtmlAttributeCollection'/> .</para>
        /// </summary>
        /// <returns><para>None.</para></returns>
        /// <seealso cref='System.Collections.IEnumerator'/>
        public new HtmlAttributeEnumerator GetEnumerator() {
            return new HtmlAttributeEnumerator(this);
        }

        /// <summary>
        ///    <para> Removes a specific <see cref='.HtmlAttribute'/> from the 
        ///    <see cref='.HtmlAttributeCollection'/> .</para>
        /// </summary>
        /// <param name='value'>The <see cref='.HtmlAttribute'/> to remove from the <see cref='.HtmlAttributeCollection'/> .</param>
        /// <returns><para>None.</para></returns>
        /// <exception cref='System.ArgumentException'><paramref name='value'/> is not found in the Collection. </exception>
        public void Remove(HtmlTag.HtmlAttribute val) {
            List.Remove(val);
        }

        public class HtmlAttributeEnumerator : IEnumerator {
            IEnumerator baseEnumerator;
            IEnumerable temp;

            public HtmlAttributeEnumerator(HtmlAttributeCollection mappings) {
                this.temp = ((IEnumerable)(mappings));
                this.baseEnumerator = temp.GetEnumerator();
            }

            public HtmlTag.HtmlAttribute Current {
                get {
                    return ((HtmlTag.HtmlAttribute)(baseEnumerator.Current));
                }
            }

            object IEnumerator.Current {
                get {
                    return baseEnumerator.Current;
                }
            }

            public bool MoveNext() {
                return baseEnumerator.MoveNext();
            }

            bool IEnumerator.MoveNext() {
                return baseEnumerator.MoveNext();
            }

            public void Reset() {
                baseEnumerator.Reset();
            }

            void IEnumerator.Reset() {
                baseEnumerator.Reset();
            }
        }
    }
}

