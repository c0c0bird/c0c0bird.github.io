﻿/* This class has been written by
 * Corinna John (Hannover, Germany)
 * cj@binary-universe.net
 * 
 * You may do with this code whatever you like,
 * except selling it or claiming any rights/ownership.
 * 
 * Please send me a little feedback about what you're
 * using this code for and what changes you'd like to
 * see in later versions. (And please excuse my bad english.)
 * 
 * WARNING: This is experimental code.
 * Exception handling has been omitted,
 * to keep the code readable to people who want
 * to understand the algorithm.
 * Please do not expect "Release Quality".
 * */

#region Using directives

using System;
using System.IO;
using System.Collections.Specialized;
using System.Text;

#endregion

namespace SteganoList {
    public class ListUtility {
        private ListUtility(){}

        internal static StringCollection Hide(String[] lines, Stream message, String alphabetFileName)
        {
            StringCollection resultList = new StringCollection();
            StringCollection originalList = Utilities.SortLines(lines, Utilities.GetTextFromFile(alphabetFileName));

            bool messageBit = false;
            int messageByte = message.ReadByte();
            int listElementIndex = 0;
            Random random = new Random();

            //for each byte of the message
            while (messageByte > -1) {
                //for each bit
                for (int bitIndex = 0; bitIndex < 8; bitIndex++) {

                    //decide which line is going to be the next one in the new list
                    
                    messageBit = ((messageByte & (1 << bitIndex)) > 0) ? true : false;

                    if (messageBit) {
                        listElementIndex = 0;
                    } else {
                        listElementIndex = random.Next(1, originalList.Count);
                    }

                    //move the line from old list to new list

                    resultList.Add(originalList[listElementIndex]);
                    originalList.RemoveAt(listElementIndex);
                }

                //repeat this with the next byte of the message
                messageByte = message.ReadByte();
            }

            //copy unused list elements
            foreach (String s in originalList) {
                resultList.Add(s);
            }

            return resultList;
        }

        /// <summary>Extract a message from the order of lines in a text</summary>
        /// <param name="lines">Carrier list - the message will be removed from it</param>
        /// <param name="alphabetFileName">Name of a file to load the custom alphabet from</param>
        /// <returns>Message</returns>
        internal static Stream Extract(String[] lines, String alphabetFileName)
        {
            //initialize empty writer for the message
            BinaryWriter messageWriter = new BinaryWriter(new MemoryStream());

            StringCollection carrierList = new StringCollection();
            carrierList.AddRange(lines);
            carrierList.RemoveAt(carrierList.Count - 1);

            //sort -> get original list
            StringCollection originalList = Utilities.SortLines(lines, Utilities.GetTextFromFile(alphabetFileName));
            String[] unchangeableOriginalList = new String[originalList.Count];
            originalList.CopyTo(unchangeableOriginalList, 0);

            int messageBit = 0;
            int messageBitIndex = 0;
            int messageByte = 0;

            foreach (String s in carrierList) {
                
                //decide which bit the entry's position hides

                if (s == originalList[0]) {
                    messageBit = 1;
                } else {
                    messageBit = 0;
                }

                //remove the item from the sorted list
                originalList.Remove(s);

                //add the bit to the message
                messageByte += (byte)(messageBit << messageBitIndex);

                messageBitIndex++;
                if (messageBitIndex > 7) {
                    //append the byte to the message
                    messageWriter.Write((byte)messageByte);
                    messageByte = 0;
                    messageBitIndex = 0;
                }
            }

            //return original list
            for (int n = 0; n < lines.Length; n++) {
                lines[n] = unchangeableOriginalList[n];
            }

            //return message stream
            messageWriter.Seek(0, SeekOrigin.Begin);
            return messageWriter.BaseStream;
        }

    }
}
