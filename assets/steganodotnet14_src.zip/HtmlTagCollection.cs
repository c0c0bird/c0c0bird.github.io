﻿using System;
using System.Collections;

namespace SteganoList {

    /// <summary>
    ///     <para>
    ///       A collection that stores <see cref='.HtmlTag'/> objects.
    ///    </para>
    /// </summary>
    /// <seealso cref='.HtmlTagCollection'/>
    [Serializable()]
    public class HtmlTagCollection : CollectionBase {

        /// <summary>
        ///     <para>
        ///       Initializes a new instance of <see cref='.HtmlTagCollection'/>.
        ///    </para>
        /// </summary>
        public HtmlTagCollection() {
        }

        /// <summary>
        ///     <para>
        ///       Initializes a new instance of <see cref='.HtmlTagCollection'/> based on another <see cref='.HtmlTagCollection'/>.
        ///    </para>
        /// </summary>
        /// <param name='value'>
        ///       A <see cref='.HtmlTagCollection'/> from which the contents are copied
        /// </param>
        public HtmlTagCollection(HtmlTagCollection val) {
            this.AddRange(val);
        }

        /// <summary>
        ///     <para>
        ///       Initializes a new instance of <see cref='.HtmlTagCollection'/> containing any array of <see cref='.HtmlTag'/> objects.
        ///    </para>
        /// </summary>
        /// <param name='value'>
        ///       A array of <see cref='.HtmlTag'/> objects with which to intialize the collection
        /// </param>
        public HtmlTagCollection(HtmlTag[] val) {
            this.AddRange(val);
        }

        /// <summary>
        /// <para>Represents the entry at the specified index of the <see cref='.HtmlTag'/>.</para>
        /// </summary>
        /// <param name='index'><para>The zero-based index of the entry to locate in the collection.</para></param>
        /// <value>
        ///    <para> The entry at the specified index of the collection.</para>
        /// </value>
        /// <exception cref='System.ArgumentOutOfRangeException'><paramref name='index'/> is outside the valid range of indexes for the collection.</exception>
        public HtmlTag this[int index] {
            get {
                return ((HtmlTag)(List[index]));
            }
            set {
                List[index] = value;
            }
        }

        /// <summary>
        ///    <para>Adds a <see cref='.HtmlTag'/> with the specified value to the 
        ///    <see cref='.HtmlTagCollection'/> .</para>
        /// </summary>
        /// <param name='value'>The <see cref='.HtmlTag'/> to add.</param>
        /// <returns>
        ///    <para>The index at which the new element was inserted.</para>
        /// </returns>
        /// <seealso cref='.HtmlTagCollection.AddRange'/>
        public int Add(HtmlTag val) {
            return List.Add(val);
        }

        /// <summary>
        /// <para>Copies the elements of an array to the end of the <see cref='.HtmlTagCollection'/>.</para>
        /// </summary>
        /// <param name='value'>
        ///    An array of type <see cref='.HtmlTag'/> containing the objects to add to the collection.
        /// </param>
        /// <returns>
        ///   <para>None.</para>
        /// </returns>
        /// <seealso cref='.HtmlTagCollection.Add'/>
        public void AddRange(HtmlTag[] val) {
            for (int i = 0; i < val.Length; i++) {
                this.Add(val[i]);
            }
        }

        /// <summary>
        ///     <para>
        ///       Adds the contents of another <see cref='.HtmlTagCollection'/> to the end of the collection.
        ///    </para>
        /// </summary>
        /// <param name='value'>
        ///    A <see cref='.HtmlTagCollection'/> containing the objects to add to the collection.
        /// </param>
        /// <returns>
        ///   <para>None.</para>
        /// </returns>
        /// <seealso cref='.HtmlTagCollection.Add'/>
        public void AddRange(HtmlTagCollection val) {
            for (int i = 0; i < val.Count; i++) {
                this.Add(val[i]);
            }
        }

        /// <summary>
        /// <para>Gets a value indicating whether the 
        ///    <see cref='.HtmlTagCollection'/> contains the specified <see cref='.HtmlTag'/>.</para>
        /// </summary>
        /// <param name='value'>The <see cref='.HtmlTag'/> to locate.</param>
        /// <returns>
        /// <para><see langword='true'/> if the <see cref='.HtmlTag'/> is contained in the collection; 
        ///   otherwise, <see langword='false'/>.</para>
        /// </returns>
        /// <seealso cref='.HtmlTagCollection.IndexOf'/>
        public bool Contains(HtmlTag val) {
            return List.Contains(val);
        }

        /// <summary>
        /// <para>Copies the <see cref='.HtmlTagCollection'/> values to a one-dimensional <see cref='System.Array'/> instance at the 
        ///    specified index.</para>
        /// </summary>
        /// <param name='array'><para>The one-dimensional <see cref='System.Array'/> that is the destination of the values copied from <see cref='.HtmlTagCollection'/> .</para></param>
        /// <param name='index'>The index in <paramref name='array'/> where copying begins.</param>
        /// <returns>
        ///   <para>None.</para>
        /// </returns>
        /// <exception cref='System.ArgumentException'><para><paramref name='array'/> is multidimensional.</para> <para>-or-</para> <para>The number of elements in the <see cref='.HtmlTagCollection'/> is greater than the available space between <paramref name='arrayIndex'/> and the end of <paramref name='array'/>.</para></exception>
        /// <exception cref='System.ArgumentNullException'><paramref name='array'/> is <see langword='null'/>. </exception>
        /// <exception cref='System.ArgumentOutOfRangeException'><paramref name='arrayIndex'/> is less than <paramref name='array'/>'s lowbound. </exception>
        /// <seealso cref='System.Array'/>
        public void CopyTo(HtmlTag[] array, int index) {
            List.CopyTo(array, index);
        }

        /// <summary>
        ///    <para>Returns the index of a <see cref='.HtmlTag'/> in 
        ///       the <see cref='.HtmlTagCollection'/> .</para>
        /// </summary>
        /// <param name='value'>The <see cref='.HtmlTag'/> to locate.</param>
        /// <returns>
        /// <para>The index of the <see cref='.HtmlTag'/> of <paramref name='value'/> in the 
        /// <see cref='.HtmlTagCollection'/>, if found; otherwise, -1.</para>
        /// </returns>
        /// <seealso cref='.HtmlTagCollection.Contains'/>
        public int IndexOf(HtmlTag val) {
            return List.IndexOf(val);
        }

        /// <summary>
        /// <para>Inserts a <see cref='.HtmlTag'/> into the <see cref='.HtmlTagCollection'/> at the specified index.</para>
        /// </summary>
        /// <param name='index'>The zero-based index where <paramref name='value'/> should be inserted.</param>
        /// <param name=' value'>The <see cref='.HtmlTag'/> to insert.</param>
        /// <returns><para>None.</para></returns>
        /// <seealso cref='.HtmlTagCollection.Add'/>
        public void Insert(int index, HtmlTag val) {
            List.Insert(index, val);
        }

        /// <summary>
        ///    <para>Returns an enumerator that can iterate through 
        ///       the <see cref='.HtmlTagCollection'/> .</para>
        /// </summary>
        /// <returns><para>None.</para></returns>
        /// <seealso cref='System.Collections.IEnumerator'/>
        public new HtmlTagEnumerator GetEnumerator() {
            return new HtmlTagEnumerator(this);
        }

        /// <summary>
        ///    <para> Removes a specific <see cref='.HtmlTag'/> from the 
        ///    <see cref='.HtmlTagCollection'/> .</para>
        /// </summary>
        /// <param name='value'>The <see cref='.HtmlTag'/> to remove from the <see cref='.HtmlTagCollection'/> .</param>
        /// <returns><para>None.</para></returns>
        /// <exception cref='System.ArgumentException'><paramref name='value'/> is not found in the Collection. </exception>
        public void Remove(HtmlTag val) {
            List.Remove(val);
        }

        public class HtmlTagEnumerator : IEnumerator {
            IEnumerator baseEnumerator;
            IEnumerable temp;

            public HtmlTagEnumerator(HtmlTagCollection mappings) {
                this.temp = ((IEnumerable)(mappings));
                this.baseEnumerator = temp.GetEnumerator();
            }

            public HtmlTag Current {
                get {
                    return ((HtmlTag)(baseEnumerator.Current));
                }
            }

            object IEnumerator.Current {
                get {
                    return baseEnumerator.Current;
                }
            }

            public bool MoveNext() {
                return baseEnumerator.MoveNext();
            }

            bool IEnumerator.MoveNext() {
                return baseEnumerator.MoveNext();
            }

            public void Reset() {
                baseEnumerator.Reset();
            }

            void IEnumerator.Reset() {
                baseEnumerator.Reset();
            }
        }
    }
}