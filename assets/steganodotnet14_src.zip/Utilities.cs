﻿#region Using directives

using System;
using System.Collections.Specialized;
using System.Text;
using System.IO;

#endregion

namespace SteganoList {
    public class Utilities {
        private Utilities(){}

        internal static Stream ToStream(String text, bool prependLength)
        {
            BinaryWriter messageWriter = new BinaryWriter(new MemoryStream());
            if (prependLength) {
                messageWriter.Write((byte)text.Length);
            }
            messageWriter.Write(Encoding.Default.GetBytes(text));
            messageWriter.Seek(0, SeekOrigin.Begin);
            return messageWriter.BaseStream;
        }

        internal static String GetTextFromFile(String fileName){
            String fileContent = String.Empty;
            if (fileName.Length > 0) {
                StreamReader reader = new StreamReader(fileName, Encoding.Default);
                fileContent = reader.ReadToEnd();
                reader.Close();
            }
            return fileContent;
        }

        internal static StringCollection SortLines(String[] lines, String alphabet)
        {
            String[] sortedLines = new String[lines.Length];
            Array.Copy(lines, sortedLines, lines.Length);

            if ((alphabet == null)||(alphabet.Length == 0)) {
                //use alphabet
                Array.Sort(sortedLines);
            } else {
                //user custom character order
                StringComparer comparer = new StringComparer(alphabet);
                Array.Sort(sortedLines, comparer);
            }

            StringCollection sortedList = new StringCollection();
            sortedList.AddRange(sortedLines);
            return sortedList;
        }

        internal static StringComparer GetStringComparer(String alphabetFileName)
        {
            StringComparer comparer = null;
            if (alphabetFileName.Length > 0) {
                StreamReader reader = new StreamReader(alphabetFileName, Encoding.Default);
                String fileContent = reader.ReadToEnd();
                reader.Close();
                comparer = new StringComparer(fileContent);
            }
            return comparer;
        }

    }
}
