﻿#region Using directives

using System;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

#endregion

namespace SteganoList {

    partial class HtmlForm : Form {

        public HtmlForm() {
            InitializeComponent();
        }

        private void btnHide_Click(object sender, EventArgs e)
        {
            
            if (btnCleanFileName.Tag == null) {
                MessageBox.Show("Please open the carrier document first.");
            } else if (txtMessage.Text.Length == 0) {
                MessageBox.Show("Please enter the message first.");
            } else {
                SaveFileDialog dlg = new SaveFileDialog();
                dlg.Filter = "HTML Documents (*.html, *.html)|*.html;*.htm";
                if (dlg.ShowDialog() != DialogResult.Cancel) {

                    HtmlUtility utility = new HtmlUtility();

                    Stream message = Utilities.ToStream(txtMessage.Text, true);
                    this.Cursor = Cursors.WaitCursor;
                    utility.Hide(((String)btnCleanFileName.Tag), dlg.FileName, message, Utilities.GetTextFromFile(txtAlphabetFileName.Text));
                    this.Cursor = Cursors.Default;
                }
            }
        }

        private void btnExtract_Click(object sender, EventArgs e)
        {
            if (btnCarrierFileName.Tag == null) {
                MessageBox.Show("Please open the carrier document first.");
            } else {
                HtmlUtility utility = new HtmlUtility();

                this.Cursor = Cursors.WaitCursor;
                Stream message = utility.Extract(btnCarrierFileName.Text, Utilities.GetTextFromFile(txtAlphabetFileName.Text));
                this.Cursor = Cursors.Default;

                message.Position = 0;
                StreamReader reader = new StreamReader(message, Encoding.Default);
                String messageText = reader.ReadToEnd();
                txtMessage.Text = messageText;

                reader.Close();
            }
        }

        private String GetSourceFileName(String filter) {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = filter;
            if (dlg.ShowDialog(this) == DialogResult.OK) {
                return dlg.FileName;
            } else {
                return null;
            }
        }

        private String GetDestinationFileName(String filter) {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Filter = filter;
            if (dlg.ShowDialog(this) == DialogResult.OK) {
                return dlg.FileName;
            } else {
                return null;
            }
        }


        private void btnCleanFileName_Click(object sender, EventArgs e)
        {
            String fileName = GetSourceFileName("HTML Documents (*.html, *.html)|*.html;*.htm");

            if (fileName != null) {
                btnCleanFileName.Tag = fileName;
                btnCleanFileName.Text = Path.GetFileName(fileName);

                HtmlUtility utility = new HtmlUtility();
                decimal countBytes = utility.GetCapacity(fileName) / 8;
                int capacity = (int)Math.Floor(countBytes);
                lblCapacity.Text = capacity.ToString();
                txtMessage.MaxLength = capacity;
            }
        }

        private void btnCarrierFileName_Click(object sender, EventArgs e)
        {
            String fileName = GetSourceFileName("HTML Documents (*.html, *.html)|*.html;*.htm");

            if (fileName != null) {
                btnCarrierFileName.Tag = fileName;
                btnCarrierFileName.Text = Path.GetFileName(fileName);
            }
        }

        private void btnAlphabetFileName_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            if (dlg.ShowDialog() != DialogResult.Cancel) {
                txtAlphabetFileName.Text = dlg.FileName;
            }
        }

    }
}