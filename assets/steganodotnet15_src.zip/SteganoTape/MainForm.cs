using System;
using System.IO;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Text;
using System.Globalization;
using System.Windows.Forms;

namespace SteganoTape {
    public partial class MainForm : Form {
        public MainForm()
        {
            InitializeComponent();
        }

		private WaveUtility waveUtility;
		private String soxPath;

		private String FindSoxInDirectory(String parentDirectory)
		{
			String result = String.Empty;
			String[] subDirectories = Directory.GetDirectories(parentDirectory, "sox*");
			if (subDirectories.Length > 0) {
				//SoX found in a subdirectory
				String[] files;
				for (int n = 0; n < subDirectories.Length; n++) {
					files = Directory.GetFiles(subDirectories[n], "sox.exe", SearchOption.AllDirectories);
					if (files.Length == 1) {
						result = files[0];
						break;
					}
				}
			}
			return result;
		}

		private void MainForm_Load(object sender, EventArgs e)
		{
			//find SoX

			soxPath = String.Empty;
			String executablePath = Path.GetDirectoryName(Application.ExecutablePath);
			
			//search for SoX in current directory and all parent directories
			DirectoryInfo info = new DirectoryInfo(executablePath);
			while ((soxPath.Length == 0) && (info != null)) {
				soxPath = FindSoxInDirectory(info.FullName);
				info = Directory.GetParent(info.FullName);
			}

			if (soxPath.Length == 0) {
				//search for SoX in "Program Files"
				soxPath = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
				soxPath = FindSoxInDirectory(soxPath);
			}

			if (soxPath.Length == 0) {
				//ask user for SoX path
				FindSoxForm dlg = new FindSoxForm();
				if (dlg.ShowDialog() == DialogResult.OK) {
					soxPath = dlg.SoxPath;
				}
			}

			if (soxPath.Length == 0) {
				Application.Exit();
			} else {
				waveControl.SoxPath = soxPath;
				waveControl.ZoomPercent = 0.1f;
			}
		}

		private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			waveControl.Close();
		}

		private void btnFind_Click(object sender, EventArgs e)
		{
			waveControl.ClearBeeps();

			//amplitudes lower than numExtractVolume.Value are treated as silence
			waveUtility.FindAnything((short)numExtractVolume.Value);
		}

		private void btnExtract_Click(object sender, EventArgs e)
		{
			//list the beginning seconds of the selected beeps
			Collection<Beep> selectedItems = waveControl.SelectedItems;
			Collection<float> startSeconds = new Collection<float>();
			foreach (Beep beep in selectedItems) {
				startSeconds.Add(beep.StartSecond);
			}

			//read the hidden message from the seconds
			Stream messageStream = waveUtility.Extract(startSeconds);
			StreamReader messageReader = new StreamReader(messageStream, Encoding.Default);
			String message = messageReader.ReadToEnd();
			messageReader.Close();

			txtExtractMessage.Text = message;
		}

		private MemoryStream GetMessage()
		{
			MemoryStream message = new MemoryStream();
			StreamWriter writer = new StreamWriter(message, Encoding.Default);
			writer.Write(txtHideMessage.Text);
			writer.Flush();
			message.Position = 0;
			return message;
		}

		/// <summary>
		/// Check the sound's duration, and display a warning, if it is too short for the message to hide
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnCheckLength_Click(object sender, EventArgs e)
		{
			MemoryStream message = GetMessage();
			long requiredSeconds = waveUtility.CountRequiredSeconds(message);
			message.Close();

			lblRequiredSeconds.Text = requiredSeconds.ToString(CultureInfo.CurrentCulture);

			if (Math.Floor(waveControl.Duration) < requiredSeconds) {
				errorProvider.SetError(txtHideMessage, "Sortry, but this message is too long.");
				panelStep3.Enabled = false;
				btnHide.Enabled = false;
			} else {
				errorProvider.SetError(txtHideMessage, String.Empty);
				panelStep3.Enabled = true;
			}

		}

		/// <summary>Write the message into the sound</summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnHide_Click(object sender, EventArgs e)
		{
			this.Cursor = Cursors.WaitCursor;
			try {
				MemoryStream message = GetMessage();
				waveUtility.Hide(message, (int)numExtractFrequency.Value, (int)numExtractVolume.Value);
				message.Close();
			} finally {
				this.Cursor = Cursors.Default;
			}
		}

		/// <summary>
		/// Remove all samples from the wave, that are less than numExtractVolume.Value
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnExtractFilterVolume_Click(object sender, EventArgs e)
		{
			this.Cursor = Cursors.WaitCursor;
			try {
				short minVolumne = (short)numExtractVolume.Value;
				WaveSound waveSound = waveControl.WaveSound;
				short[] samples = waveSound.Samples;
				for (int n = 0; n < samples.Length; n++) {
					if (Math.Abs(samples[n]) < minVolumne) {
						samples[n] = 0;
					}
				}
				waveControl.WaveSound = waveSound;
			} finally {
				this.Cursor = Cursors.Default;
			}
		}

		/// <summary>Get a new WaveUtility, after a new file has been opened in the WaveDisplayControl</summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void waveControl_Open(object sender, EventArgs e)
		{
			numExtractVolume.Value = waveControl.MaxSampleValue / 2;
			this.waveUtility = waveControl.CreateWaveUtility();

			SetStep2Enabled();
			panelFind.Enabled = true;
		}

		/// <summary>Perform a band pass filter on the wave sound</summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnExtractBandPass_Click(object sender, EventArgs e)
		{
			String outFileName = waveUtility.FindFrequency(
				Path.GetTempPath(),
				soxPath,
				(int)numExtractFrequency.Value);

			waveControl.OpenFromFile(outFileName);
		}

		/// <summary>Show a warning, if the settings are not good for hiding something in the wave sound</summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnCheckHideSettings_Click(object sender, EventArgs e)
		{
			//filter for frequency

			String outFileName = waveUtility.FindFrequency(
				Path.GetTempPath(),
				soxPath,
				(int)numHideFrequency.Value);

			WaveUtility filterUtility = new WaveUtility(outFileName);
			WaveSound waveSound = filterUtility.WaveSound;
			
			//filter for volume, check what is left of the sound

			long countLoudSamples = 0;
			short minVolumne = (short)(numHideVolume.Value - 100);
			short[] samples = waveSound.Samples;
			for (int n = 0; n < samples.Length; n++) {
				if (Math.Abs(samples[n]) > minVolumne) {
					countLoudSamples++;
				}
			}

			if (countLoudSamples > 0) {
				MessageBox.Show(String.Format("The Frequency might be a bad choice, because there are already {0} too loud samples in the sound.", countLoudSamples));
				errorProvider.SetError(numHideFrequency, "Frequency not fitting, oder selected volume too low.");
			} else {
				errorProvider.SetError(numHideFrequency, String.Empty);
			}
			btnHide.Enabled = true;
		}

		private void txtMessage_TextChanged(object sender, EventArgs e)
		{
			SetStep2Enabled();
		}

		private void SetStep2Enabled(){
			panelStep2.Enabled = (txtHideMessage.Text.Length > 0) && (waveControl.WaveSound != null);
		}
	}
}