using System;
using System.IO;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace SteganoTape {
	class FifoInt16Collection {
		private int maxLength;
		private Collection<short> content;

		public bool IsFilled
		{
			get { return content.Count >= maxLength; }
		}

		public FifoInt16Collection(int maxLength)
		{
			this.maxLength = maxLength;
			this.content = new Collection<short>();
		}

		public void Clear()
		{
			content.Clear();
		}

		public void Add(short value)
		{
			content.Add(value);
			if (content.Count > maxLength) {
				content.RemoveAt(0);
			}
		}

		public short Get(int index)
		{
			if (content.Count > index) {
				return content[index];
			} else {
				return 0;
			}
		}

		public short[] GetMinMaxValues()
		{
			short minimum = 0;
			short maximum = 0;
			foreach (short value in content) {
				if (value > maximum) {
					maximum = value;
				} else if (value < minimum) {
					minimum = value;
				}
			}
			return new short[2] { minimum, maximum };
		}

		public Collection<int> GetLocalPeaks(short tolerance)
		{
			Collection<int> localPeaks = new Collection<int>();
			short[] minmax = GetMinMaxValues();
			int minimum = minmax[0];
			int maximum = minmax[1];
			int minTolerance = -tolerance;
			int maxTolerance = tolerance;

			for (int index = 1; index < content.Count-1; index++) {
				if ((maximum - content[index] <= maxTolerance) && (content[index] > content[index + 1]) && (content[index] >= content[index - 1])) {
					localPeaks.Add(index);
				} else if ((minimum - content[index] >= minTolerance) && (content[index] < content[index + 1]) && (content[index] <= content[index - 1])) {
					localPeaks.Add(index);
				}
			}

			return localPeaks;
		}

		public int[] GetLocalPeaksMinMaxDistance(short tolerance)
		{
			Collection<int> localPeaks = GetLocalPeaks(tolerance);
			int distance;
			int minDistance = localPeaks.Count;
			int maxDistance = 0;
			for (int index = 1; index < localPeaks.Count; index++) {
				distance = localPeaks[index] - localPeaks[index - 1];
				if (distance > maxDistance) {
					maxDistance = distance;
				} else if (distance < minDistance) {
					minDistance = distance;
				}
			}
			return new int[2] { minDistance, maxDistance };
		}

	}
}
