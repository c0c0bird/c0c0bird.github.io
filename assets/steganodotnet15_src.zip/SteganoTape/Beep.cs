using System;
using System.Collections.Generic;
using System.Text;

namespace SteganoTape {
	public class Beep {
		private int startSampleIndex;
		private int endSampleIndex;
		private float startSecond;
		private float endSecond;

		public int StartSampleIndex
		{
			get { return startSampleIndex; }
		}

		public int EndSampleIndex
		{
			get { return endSampleIndex; }
		}

		public float StartSecond
		{
			get { return startSecond; }
		}

		public float EndSecond
		{
			get { return endSecond; }
		}

		public Beep(int startSampleIndex, int endSampleIndex, float startSecond, float endSecond)
		{
			this.startSampleIndex = startSampleIndex;
			this.endSampleIndex = endSampleIndex;
			this.startSecond = startSecond;
			this.endSecond = endSecond;
		}
	}
}
