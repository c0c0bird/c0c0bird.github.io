using System;
using System.Collections.Generic;
using System.Text;

namespace SteganoTape {
	public class BeepFoundEventArgs : EventArgs {

		private Beep beep;

		public Beep Beep
		{
			get { return beep; }
		}

		public BeepFoundEventArgs(Beep beep)
		{
			this.beep = beep;
		}
	}

	public delegate void BeepFoundHandler(object sender, BeepFoundEventArgs e);
}
