using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Text;

namespace SteganoMidi
{
	/// <summary>
	/// Zusammendfassende Beschreibung f�r Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txtSrcFile;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox txtDstFile;
		private System.Windows.Forms.Button btnSrc;
		private System.Windows.Forms.Button btnDst;
		private System.Windows.Forms.Button btnHide;
		private System.Windows.Forms.TextBox txtMessage;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TabControl tabCtl;
		private System.Windows.Forms.CheckBox chkClean;
		private System.Windows.Forms.Button btnClean;
		private System.Windows.Forms.Label lblClean;
		private System.Windows.Forms.TextBox txtClean;
		private System.Windows.Forms.Button btnExtract;
		private System.Windows.Forms.TextBox txtExtractedMessage;
		private System.Windows.Forms.Button btnKey;
		private System.Windows.Forms.TextBox txtKeyFile;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox txtReport;
		/// <summary>
		/// Erforderliche Designervariable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Erforderlich f�r die Windows Form-Designerunterst�tzung
			//
			InitializeComponent();

			//
			// TODO: F�gen Sie den Konstruktorcode nach dem Aufruf von InitializeComponent hinzu
			//
		}

		/// <summary>
		/// Die verwendeten Ressourcen bereinigen.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Erforderliche Methode f�r die Designerunterst�tzung. 
		/// Der Inhalt der Methode darf nicht mit dem Code-Editor ge�ndert werden.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.txtSrcFile = new System.Windows.Forms.TextBox();
			this.btnSrc = new System.Windows.Forms.Button();
			this.btnDst = new System.Windows.Forms.Button();
			this.txtDstFile = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.btnHide = new System.Windows.Forms.Button();
			this.txtMessage = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.tabCtl = new System.Windows.Forms.TabControl();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.txtReport = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.chkClean = new System.Windows.Forms.CheckBox();
			this.btnExtract = new System.Windows.Forms.Button();
			this.label4 = new System.Windows.Forms.Label();
			this.txtExtractedMessage = new System.Windows.Forms.TextBox();
			this.btnClean = new System.Windows.Forms.Button();
			this.lblClean = new System.Windows.Forms.Label();
			this.txtClean = new System.Windows.Forms.TextBox();
			this.btnKey = new System.Windows.Forms.Button();
			this.txtKeyFile = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.tabCtl.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.tabPage2.SuspendLayout();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 24);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(112, 23);
			this.label1.TabIndex = 1;
			this.label1.Text = "Carrier MIDI File";
			// 
			// txtSrcFile
			// 
			this.txtSrcFile.Location = new System.Drawing.Point(128, 24);
			this.txtSrcFile.Name = "txtSrcFile";
			this.txtSrcFile.Size = new System.Drawing.Size(368, 22);
			this.txtSrcFile.TabIndex = 0;
			this.txtSrcFile.Text = "";
			this.txtSrcFile.TextChanged += new System.EventHandler(this.textField_TextChanged);
			// 
			// btnSrc
			// 
			this.btnSrc.Location = new System.Drawing.Point(496, 24);
			this.btnSrc.Name = "btnSrc";
			this.btnSrc.TabIndex = 1;
			this.btnSrc.Text = "Browse...";
			this.btnSrc.Click += new System.EventHandler(this.btnCarrier_Click);
			// 
			// btnDst
			// 
			this.btnDst.Location = new System.Drawing.Point(464, 16);
			this.btnDst.Name = "btnDst";
			this.btnDst.TabIndex = 1;
			this.btnDst.Text = "Browse...";
			this.btnDst.Click += new System.EventHandler(this.btnDst_Click);
			// 
			// txtDstFile
			// 
			this.txtDstFile.Location = new System.Drawing.Point(128, 16);
			this.txtDstFile.Name = "txtDstFile";
			this.txtDstFile.Size = new System.Drawing.Size(336, 22);
			this.txtDstFile.TabIndex = 0;
			this.txtDstFile.Text = "";
			this.txtDstFile.TextChanged += new System.EventHandler(this.textField_TextChanged);
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(16, 16);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(112, 23);
			this.label2.TabIndex = 4;
			this.label2.Text = "Save Result As";
			// 
			// btnHide
			// 
			this.btnHide.Enabled = false;
			this.btnHide.Location = new System.Drawing.Point(392, 280);
			this.btnHide.Name = "btnHide";
			this.btnHide.Size = new System.Drawing.Size(144, 23);
			this.btnHide.TabIndex = 3;
			this.btnHide.Text = "Hide Message";
			this.btnHide.Click += new System.EventHandler(this.btnHide_Click);
			// 
			// txtMessage
			// 
			this.txtMessage.Location = new System.Drawing.Point(128, 48);
			this.txtMessage.Multiline = true;
			this.txtMessage.Name = "txtMessage";
			this.txtMessage.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.txtMessage.Size = new System.Drawing.Size(408, 168);
			this.txtMessage.TabIndex = 2;
			this.txtMessage.Text = "";
			this.txtMessage.TextChanged += new System.EventHandler(this.textField_TextChanged);
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(16, 48);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(112, 23);
			this.label3.TabIndex = 4;
			this.label3.Text = "Message";
			// 
			// tabCtl
			// 
			this.tabCtl.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.tabPage1,
																				 this.tabPage2});
			this.tabCtl.Location = new System.Drawing.Point(16, 88);
			this.tabCtl.Name = "tabCtl";
			this.tabCtl.SelectedIndex = 0;
			this.tabCtl.Size = new System.Drawing.Size(560, 344);
			this.tabCtl.TabIndex = 4;
			// 
			// tabPage1
			// 
			this.tabPage1.Controls.AddRange(new System.Windows.Forms.Control[] {
																				   this.btnHide,
																				   this.btnDst,
																				   this.label2,
																				   this.txtDstFile,
																				   this.label3,
																				   this.txtMessage,
																				   this.txtReport,
																				   this.label6});
			this.tabPage1.Location = new System.Drawing.Point(4, 25);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Size = new System.Drawing.Size(552, 315);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "Hide";
			// 
			// txtReport
			// 
			this.txtReport.Location = new System.Drawing.Point(128, 224);
			this.txtReport.Multiline = true;
			this.txtReport.Name = "txtReport";
			this.txtReport.ReadOnly = true;
			this.txtReport.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.txtReport.Size = new System.Drawing.Size(408, 48);
			this.txtReport.TabIndex = 3;
			this.txtReport.Text = "";
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(16, 224);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(112, 23);
			this.label6.TabIndex = 4;
			this.label6.Text = "MIDI Report";
			// 
			// tabPage2
			// 
			this.tabPage2.Controls.AddRange(new System.Windows.Forms.Control[] {
																				   this.chkClean,
																				   this.btnExtract,
																				   this.label4,
																				   this.txtExtractedMessage,
																				   this.btnClean,
																				   this.lblClean,
																				   this.txtClean});
			this.tabPage2.Location = new System.Drawing.Point(4, 25);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Size = new System.Drawing.Size(552, 315);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "Extract";
			// 
			// chkClean
			// 
			this.chkClean.Location = new System.Drawing.Point(16, 16);
			this.chkClean.Name = "chkClean";
			this.chkClean.Size = new System.Drawing.Size(248, 24);
			this.chkClean.TabIndex = 0;
			this.chkClean.Text = "Remove Message from Carrier File";
			this.chkClean.CheckedChanged += new System.EventHandler(this.chkClean_CheckedChanged);
			// 
			// btnExtract
			// 
			this.btnExtract.Enabled = false;
			this.btnExtract.Location = new System.Drawing.Point(392, 280);
			this.btnExtract.Name = "btnExtract";
			this.btnExtract.Size = new System.Drawing.Size(144, 23);
			this.btnExtract.TabIndex = 3;
			this.btnExtract.Text = "Extract Message";
			this.btnExtract.Click += new System.EventHandler(this.btnExtract_Click);
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(16, 96);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(96, 32);
			this.label4.TabIndex = 9;
			this.label4.Text = "Extracted Message";
			// 
			// txtExtractedMessage
			// 
			this.txtExtractedMessage.Location = new System.Drawing.Point(112, 96);
			this.txtExtractedMessage.Multiline = true;
			this.txtExtractedMessage.Name = "txtExtractedMessage";
			this.txtExtractedMessage.ReadOnly = true;
			this.txtExtractedMessage.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.txtExtractedMessage.Size = new System.Drawing.Size(424, 168);
			this.txtExtractedMessage.TabIndex = 4;
			this.txtExtractedMessage.Text = "";
			// 
			// btnClean
			// 
			this.btnClean.Enabled = false;
			this.btnClean.Location = new System.Drawing.Point(464, 48);
			this.btnClean.Name = "btnClean";
			this.btnClean.TabIndex = 2;
			this.btnClean.Text = "Browse...";
			this.btnClean.Click += new System.EventHandler(this.btnClean_Click);
			// 
			// lblClean
			// 
			this.lblClean.Enabled = false;
			this.lblClean.Location = new System.Drawing.Point(16, 48);
			this.lblClean.Name = "lblClean";
			this.lblClean.Size = new System.Drawing.Size(80, 40);
			this.lblClean.TabIndex = 1;
			this.lblClean.Text = "Save Clean File As";
			// 
			// txtClean
			// 
			this.txtClean.Enabled = false;
			this.txtClean.Location = new System.Drawing.Point(112, 48);
			this.txtClean.Name = "txtClean";
			this.txtClean.Size = new System.Drawing.Size(352, 22);
			this.txtClean.TabIndex = 1;
			this.txtClean.Text = "";
			this.txtClean.TextChanged += new System.EventHandler(this.textField_TextChanged);
			// 
			// btnKey
			// 
			this.btnKey.Location = new System.Drawing.Point(496, 56);
			this.btnKey.Name = "btnKey";
			this.btnKey.TabIndex = 3;
			this.btnKey.Text = "Browse...";
			this.btnKey.Click += new System.EventHandler(this.btnKey_Click);
			// 
			// txtKeyFile
			// 
			this.txtKeyFile.Location = new System.Drawing.Point(128, 56);
			this.txtKeyFile.Name = "txtKeyFile";
			this.txtKeyFile.Size = new System.Drawing.Size(368, 22);
			this.txtKeyFile.TabIndex = 2;
			this.txtKeyFile.Text = "";
			this.txtKeyFile.TextChanged += new System.EventHandler(this.textField_TextChanged);
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(16, 56);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(112, 23);
			this.label5.TabIndex = 9;
			this.label5.Text = "Key File";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(6, 15);
			this.ClientSize = new System.Drawing.Size(592, 439);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.btnKey,
																		  this.txtKeyFile,
																		  this.label5,
																		  this.tabCtl,
																		  this.btnSrc,
																		  this.txtSrcFile,
																		  this.label1});
			this.Name = "Form1";
			this.Text = "For help and bug reports contact picturekey@binary-universe.net";
			this.tabCtl.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			this.tabPage2.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// Der Haupteinstiegspunkt f�r die Anwendung.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		/// <summary>Creates a stream to read the message from a string or a file</summary>
		/// <returns>FileStream for a message file, or MemoryStream</returns>
		private Stream GetMessageStream(){			
			byte[] messageBytes = UnicodeEncoding.Unicode.GetBytes( txtMessage.Text );
			byte[] arrMessageLength = MidiUtility.IntToArray((Int64)messageBytes.Length);
			ArrayList bytes = new ArrayList(messageBytes.Length + arrMessageLength.Length);
			bytes.AddRange(arrMessageLength); //Length of the message
			bytes.AddRange(messageBytes); //The message
			MemoryStream s = new MemoryStream((byte[])bytes.ToArray(typeof(byte)));
			return s;
		}

		private Stream GetKeyStream(){
			if(txtKeyFile.Text.Length > 0){
				return new FileStream(txtKeyFile.Text, FileMode.Open);
			}else{
				//No key file specified - hide/extract without any ignore-pattern
				return new MemoryStream(new byte[1]{0});
			}
		}

		private void btnCarrier_Click(object sender, System.EventArgs e) {
			OpenFileDialog dlg = new OpenFileDialog();
			dlg.Multiselect = false;
			dlg.Filter = "Standard MIDI Files (*.mid)|*.mid";
			if( dlg.ShowDialog(this) != DialogResult.Cancel){
				String fn = dlg.FileName;
				txtSrcFile.Text = fn;
				if((txtDstFile.Text.Length==0)&&(tabCtl.SelectedIndex==0)){
					txtDstFile.Text = fn.Remove(fn.Length-4,4)+"_result.mid";
				}
			}
		}

		private void btnDst_Click(object sender, System.EventArgs e) {
			String fileName = SelectFileName();
			if(fileName != null){ txtDstFile.Text = fileName; }
		}

		private void btnClean_Click(object sender, System.EventArgs e) {
			String fileName = SelectFileName();
			if(fileName != null){ txtClean.Text = fileName; }		
		}

		private void btnHide_Click(object sender, System.EventArgs e) {
			Stream message = GetMessageStream();
			Stream key = GetKeyStream();
			String report;
			int countProgramChangeMessages;
			long fileSize;
			
			//Analyse MIDI file
			MidiFileReader reader = new MidiFileReader();
			reader.ReadFile(txtSrcFile.Text, out report, out countProgramChangeMessages, out fileSize);
			
			if(fileSize > 0){ //The file is readable and Standard MIDI
				MidiUtility util = new MidiUtility();
				
				//Count of MIDI messages to add
				long countBlocks = message.Length*2;
				//Estimated bytes added to the file - Time field is mostly between 1 and 2 bytes long
				float bytesToAdd = countBlocks * (float)3.5;
				float increasePercent = (float)countBlocks * 100 / (float)fileSize;
				//Complete report
				report = "File increase: "+ increasePercent.ToString("##0.0#") +"% ("+ bytesToAdd +" Bytes)\r\n" + report;
				txtReport.Text = report;
			
				//Sum up the key bytes
				int keyByte=0, keySum=0;
				while( (keyByte=key.ReadByte()) > 0){ keySum += keyByte; }
				key.Seek(0, SeekOrigin.Begin);
				//[keySum] midi-messages out of [keySum+key.Length] will be ignored
				int countProgramChangeMessages_Key = countProgramChangeMessages;
				if((keySum+key.Length) > 0){
					countProgramChangeMessages_Key = (int)Math.Floor( countProgramChangeMessages * (key.Length / (keySum + key.Length)) );
				}

				//Calculate the count of Program Change message to insert before each "real" message

				//How many half-bytes must be placed before a ProgChg message using the key?
				int countBlocksPerMessage_Key = 15; //max. 15 blocks per message allowed
				if(countProgramChangeMessages_Key != 0){
					countBlocksPerMessage_Key = (int)Math.Ceiling((double)countBlocks / (double)countProgramChangeMessages_Key);
				}
				//How many half-bytes must be placed before a ProgChg message using every message?
				int countBlocksPerMessage_NoKey = 15; //max. 15 blocks per message allowed
				if(countProgramChangeMessages_Key != 0){
					countBlocksPerMessage_NoKey = (int)Math.Ceiling((double)countBlocks / (double)countProgramChangeMessages);
				}
				
				bool canStart = true;
				if(countBlocks > countProgramChangeMessages_Key){
					
					bool canUseKey=true, canUseAll=true;
					String text = "The MIDI file does not contain enough \"Program Change\" messages."
						+ "\r\n\"Program Change\" messages: " + countProgramChangeMessages
						+ "\r\nUsable \"Program Change\" messages with your key: " + countProgramChangeMessages_Key
						+ "\r\n4-bit blocks to hide: " + countBlocks
						+ "\r\nallowed 4-bit blocks per message: 1-15";

					if((countBlocksPerMessage_NoKey >= 15)&&(countBlocksPerMessage_Key >= 15)){
						//The message is too long for this MIDI file
						text += "\r\nThe message is too long for the MIDI file. Please choose another file or shorten the message.";
						canUseKey = false;
						canUseAll = false;
					}else if(countBlocksPerMessage_Key >= 15){
						//The values in the key stream are to large
						text += "\r\nThe key can not be applied. Do you want to ignore the key and use every message?";
						canUseKey = false;
					}else{
						text += "\r\n\nDo you want to hide \r\n"
							+countBlocksPerMessage_Key+" half bytes per \"Program Change\" message using the key, "
							+ "or "
							+ countBlocksPerMessage_NoKey + " half bytes per \"Program Change\" message using every message?";
					}

					QuestionBox dlg = new QuestionBox(text, canUseKey, canUseAll);
					DialogResult result = dlg.ShowDialog();
					
					canStart = (result != DialogResult.Cancel);
					if(result == DialogResult.No){
						key = new MemoryStream(new byte[1]{0});
						util.HalfBytesPerMidiMessage = (byte)countBlocksPerMessage_Key;
					}else{
						util.HalfBytesPerMidiMessage = (byte)countBlocksPerMessage_NoKey;
					}
				}else{
					//hide one half-byte per Program Change message
					util.HalfBytesPerMidiMessage = 1;
				}

				if(canStart){
					util.HideMessage(txtSrcFile.Text, txtDstFile.Text, message, key);
					message.Close();
					key.Close();
				}
			}
		}

		private void chkClean_CheckedChanged(object sender, System.EventArgs e) {
			lblClean.Enabled = txtClean.Enabled = btnClean.Enabled = chkClean.Checked;
		}

		private void btnExtract_Click(object sender, System.EventArgs e) {
			Stream messageStream = new MemoryStream();
			Stream keyStream = GetKeyStream();
			try{
				//extract the message
				MidiUtility util = new MidiUtility();
				util.ExtractMessage(txtSrcFile.Text,
					(chkClean.Checked)?txtClean.Text:null,
					messageStream, keyStream);
				
				//display the message
				messageStream.Seek(0, SeekOrigin.Begin);
				StreamReader reader = new StreamReader(messageStream, UnicodeEncoding.Unicode);
				String readerContent = reader.ReadToEnd();
				if(readerContent.Length > txtExtractedMessage.MaxLength){
					readerContent = readerContent.Substring(0, txtExtractedMessage.MaxLength);
				}
				txtExtractedMessage.Text = readerContent;
			}catch(Exception ex){
				MessageBox.Show(ex.ToString());
			}finally{
				messageStream.Close();
				keyStream.Close();
			}
		}

		private String SelectFileName(){
			SaveFileDialog dlg = new SaveFileDialog();
			dlg.Filter = "Standard MIDI Files (*.mid)|*.mid";
			if( dlg.ShowDialog(this) != DialogResult.Cancel){
				return dlg.FileName;
			}else{
				return null;
			}
		}

		private void btnKey_Click(object sender, System.EventArgs e) {
			OpenFileDialog dlg = new OpenFileDialog();
			dlg.Multiselect = false;
			if( dlg.ShowDialog(this) != DialogResult.Cancel){
				txtKeyFile.Text = dlg.FileName;
			}
		}

		private void textField_TextChanged(object sender, System.EventArgs e) {
			btnHide.Enabled =
				(txtSrcFile.Text.Length>0)
				&& (txtDstFile.Text.Length>0)
				&& (txtMessage.Text.Length>0);

			btnExtract.Enabled = (txtSrcFile.Text.Length>0)
				&&( (txtClean.Text.Length>0) == chkClean.Checked );
		}
	}
}
