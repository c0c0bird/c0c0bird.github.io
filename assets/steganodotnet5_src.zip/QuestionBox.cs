using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace SteganoMidi
{
	/// <summary>
	/// Zusammendfassende Beschreibung f�r QuestionBox.
	/// </summary>
	public class QuestionBox : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label lblQuestion;
		private System.Windows.Forms.Button btnKey;
		private System.Windows.Forms.Button btnAll;
		private System.Windows.Forms.Button btnCancel;
		/// <summary>
		/// Erforderliche Designervariable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public QuestionBox(String question, bool enableKeyBtn, bool enableAllBtn){
			//
			// Erforderlich f�r die Windows Form-Designerunterst�tzung
			//
			InitializeComponent();

			lblQuestion.Text = question;
			btnKey.Enabled = enableKeyBtn;
			btnAll.Enabled = enableAllBtn;
		}

		/// <summary>
		/// Die verwendeten Ressourcen bereinigen.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Erforderliche Methode f�r die Designerunterst�tzung. 
		/// Der Inhalt der Methode darf nicht mit dem Code-Editor ge�ndert werden.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblQuestion = new System.Windows.Forms.Label();
			this.btnKey = new System.Windows.Forms.Button();
			this.btnAll = new System.Windows.Forms.Button();
			this.btnCancel = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// lblQuestion
			// 
			this.lblQuestion.Location = new System.Drawing.Point(8, 8);
			this.lblQuestion.Name = "lblQuestion";
			this.lblQuestion.Size = new System.Drawing.Size(592, 144);
			this.lblQuestion.TabIndex = 0;
			// 
			// btnKey
			// 
			this.btnKey.Location = new System.Drawing.Point(56, 160);
			this.btnKey.Name = "btnKey";
			this.btnKey.Size = new System.Drawing.Size(160, 23);
			this.btnKey.TabIndex = 1;
			this.btnKey.Text = "Apply Key";
			this.btnKey.Click += new System.EventHandler(this.btnKey_Click);
			// 
			// btnAll
			// 
			this.btnAll.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnAll.Location = new System.Drawing.Point(224, 160);
			this.btnAll.Name = "btnAll";
			this.btnAll.Size = new System.Drawing.Size(160, 23);
			this.btnAll.TabIndex = 1;
			this.btnAll.Text = "Ignore Key";
			this.btnAll.Click += new System.EventHandler(this.btnAll_Click);
			// 
			// btnCancel
			// 
			this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnCancel.Location = new System.Drawing.Point(392, 160);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(160, 23);
			this.btnCancel.TabIndex = 2;
			this.btnCancel.Text = "Cancel";
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// QuestionBox
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(6, 15);
			this.CancelButton = this.btnCancel;
			this.ClientSize = new System.Drawing.Size(608, 191);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.btnCancel,
																		  this.btnKey,
																		  this.lblQuestion,
																		  this.btnAll});
			this.Name = "QuestionBox";
			this.Text = "Carrier too small";
			this.ResumeLayout(false);

		}
		#endregion

		private void btnKey_Click(object sender, System.EventArgs e) {
			this.DialogResult = DialogResult.Yes;
			this.Close();
		}

		private void btnAll_Click(object sender, System.EventArgs e) {
			this.DialogResult = DialogResult.No;
			this.Close();
		}

		private void btnCancel_Click(object sender, System.EventArgs e) {
			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}
	}
}
