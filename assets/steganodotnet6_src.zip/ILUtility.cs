using System;
using System.IO;
using System.Text;
using System.Collections;

namespace SteganoDotNet {
	/// <summary>Reads and writes IL Assembler Language code</summary>
	public class ILUtility {
		
		//writes the resulting IL code
		private StreamWriter writer = null;
		//length in bytes of the message being extracted
		private int messageLength = 0;
		//has the length of the message already been written to the carrier file?
		private bool isMessageLengthWritten = false;
		//has the maximum count of bytes hidden in a method already been written to the carrier file?
		private bool isBytesPerMethodWritten = false;

		//number of lines inserted in each method
		private int linesPerMethod = 0;

		//maximum count of bytes hidden in a method
		private int bytesPerMethod = 1;
		public int BytesPerMethod{
			get{ return bytesPerMethod; }
			set{ bytesPerMethod = value; }
		}


		public ILUtility(){ }

		/// <summary>Lists namespaces, classes and methods with return type "void"</summary>
		/// <param name="fileName">Name of the IL file to analyse</param>
		/// <param name="namespaces">Returns the names of all namespaces found in the file</param>
		/// <param name="classes">Returns the names of all classes</param>
		/// <param name="voidMethods">Returns the first lines of all method signatures</param>
		public void Analyse(String fileName, out ArrayList namespaces, out ArrayList classes, out ArrayList voidMethods){
			
			//initialize return lists
			namespaces = new ArrayList();
			classes = new ArrayList();
			voidMethods = new ArrayList();
			
			//current method's header, or null if the method doesn't return "void"
			String currentMethod = String.Empty;

			//read the IL file
			String[] lines = ReadFile(fileName);
			
			//loop over the lines of the IL file, fill lists
			for(int indexLines=0; indexLines<lines.Length; indexLines++){
				if(lines[indexLines].IndexOf(".namespace ") > 0){
					namespaces.Add( ProcessNamespace(lines[indexLines]) );
				}
				else if(lines[indexLines].IndexOf(".class ") > 0){
					classes.Add( ProcessClass(lines, ref indexLines) );
				}
				else if(lines[indexLines].IndexOf(".method ") > 0){
					currentMethod = ProcessMethod(lines, ref indexLines);
					if(currentMethod != null){
						voidMethods.Add(currentMethod);
					}
				}
			}
		}
	
		/// <summary>Hides a message in an IL file</summary>
		/// <param name="fileNameIn">Name of the source IL file</param>
		/// <param name="fileNameOut">Name for the resulting IL file</param>
		/// <param name="message">Message to hide</param>
		public void Hide(String fileNameIn, String fileNameOut, Stream message){
			HideOrExtract(fileNameIn, fileNameOut, message, true);
		}

		/// <summary>Extracts a message from an IL file</summary>
		/// <param name="fileNameIn">Name of the IL file</param>
		/// <param name="message">Empty stream to store the message</param>
		public void Extract(String fileNameIn, Stream message){
			HideOrExtract(fileNameIn, String.Empty, message, false);
		}

		/// <summary>Hides or extracts a message in/from an IL file</summary>
		/// <param name="fileNameIn">Name of the IL file</param>
		/// <param name="fileNameOut">Name for the resulting IL file - ignored if [hide] is false</param>
		/// <param name="message">Stream containing the message to hide, or empty stream to store the extracted message</param>
		/// <param name="hide">true: hide [message]; false: extract a message</param>
		private void HideOrExtract(String fileNameIn, String fileNameOut, Stream message, bool hide){
			
			if(hide){
				//open the destination file
				FileStream streamOut = new FileStream(fileNameOut, FileMode.Create);
				writer = new StreamWriter(streamOut);
			}else{
				//count of bytes hidden in each method is unknown,
				//it will be the first value to extract from the file
				bytesPerMethod = 0;
			}

			String[] lines = ReadFile(fileNameIn);
			bool isMessageComplete = false;

			for(int indexLines=0; indexLines<lines.Length; indexLines++){
				
				if(lines[indexLines].IndexOf(".method ") > 0){
					//found a method!
					if(hide){
						//hide as many bytes as needed
						isMessageComplete = ProcessMethodHide(lines, ref indexLines, message);
					}else{
						//extract all bytes hidden in this method
						isMessageComplete = ProcessMethodExtract(lines, ref indexLines, message);
					}
				}else if(hide){
					//the line does not belong to a useable method - just copy it
					writer.WriteLine(lines[indexLines]);
				}
				
				if(isMessageComplete){
					break; //nothing else to do
				}
			}
			
			//close writer
			if(writer != null){ writer.Close(); }
		}

		/// <summary>Reads a file line-by-line</summary>
		/// <param name="fileName">Name of the file</param>
		/// <returns>All lines</returns>
		private String[] ReadFile(String fileName){
			FileStream streamIn = new FileStream(fileName, FileMode.Open);
			StreamReader reader = new StreamReader(streamIn);

			ArrayList listLines = new ArrayList();
			String line;
			while( (line=reader.ReadLine()) != null ){
				listLines.Add(line);
			}
			reader.Close();
			return (String[])listLines.ToArray(typeof(String));
		}

		/// <summary>Extracts the name from a ".namespace name" line</summary>
		/// <param name="line">The .namespace-line</param>
		private String ProcessNamespace(String line){
			if(writer != null){ writer.WriteLine(line); }
			return line.Substring(11);
		}

		/// <summary>Reads the name from a class declaration</summary>
		/// <param name="lines">Lines of the IL file</param>
		/// <param name="indexLines">Current index in [lines]</param>
		/// <returns>Name of the class</returns>
		private String ProcessClass(String[] lines, ref int indexLines){
			int indexEndOfName = lines[indexLines].IndexOf("extends")-1;
			if(indexEndOfName < 0){
				indexEndOfName = lines[indexLines].IndexOf("{")-1;
				if(indexEndOfName < 0){
					indexEndOfName = lines[indexLines].Length-1;
				}				
			}
			int indexStartOfName = lines[indexLines].LastIndexOf(' ', indexEndOfName, indexEndOfName)+1;
					
			if(writer != null){ writer.WriteLine(lines[indexLines]); }
			return lines[indexLines].Substring(indexStartOfName, indexEndOfName-indexStartOfName+1);
		}

		/// <summary>Reads a method's header</summary>
		/// <param name="lines">Lines of the IL file</param>
		/// <param name="indexLines">Current index in [lines]</param>
		/// <returns>The method's header with line breaks removed</returns>
		private String ProcessMethod(String[] lines, ref int indexLines){
			if(lines[indexLines].IndexOf(" void ") > 0){
				StringBuilder methodSigBuilder = new StringBuilder();
				methodSigBuilder.Append(lines[indexLines]);
				
				indexLines++; //next line
				while(lines[indexLines].IndexOf("{") < 0){
					methodSigBuilder.Append(lines[indexLines]);
					indexLines++;
				}
				return methodSigBuilder.ToString();
			}
			return null;
		}

		/// <summary>Hides one or more bytes from the message stream in the IL file</summary>
		/// <param name="lines">Lines of the IL file</param>
		/// <param name="indexLines">Current index in [lines]</param>
		/// <param name="message">Stream containing the message</param>
		/// <returns>true: the last byte has been hidden; false: more message-bytes are waiting</returns>
		private bool ProcessMethodHide(String[] lines, ref int indexLines, Stream message){
			bool isMessageComplete = false;
			int currentMessageValue,	//next message-byte to hide
				positionInitLocals,		//index of the last ".locals init" line
				positionRet,			//index of the "ret" line
				positionStartOfMethodLine; //index of the method's first line
			
			writer.WriteLine(lines[indexLines]); //copy first line
			
			if(lines[indexLines].IndexOf(" void ") > 0){
				//found a method with return type "void"
				//the stack will be empty at it's end,
				//so we can insert whatever we like

				indexLines++; //next line
						
				//search start of method block, copy all skipped lines
				int oldIndex = indexLines;
				SeekStartOfBlock(lines, ref indexLines);
				CopyBlock(lines, oldIndex, indexLines);
				
				//now we are at the method's opening bracket
				positionStartOfMethodLine = indexLines;
				//go to first line of the method
				indexLines++;
				//get position of last ".locals init" and first "ret"
				positionInitLocals = 0;
				positionRet = 0;
				SeekLastLocalsInit(lines, ref indexLines, ref positionInitLocals, ref positionRet);
				
				if(positionInitLocals == 0){
					//no .locals - insert line at beginning of method
					positionInitLocals = positionStartOfMethodLine;
				}

				//copy from start of method until last .locals, or nothing (if no .locals found)
				CopyBlock(lines, positionStartOfMethodLine, positionInitLocals+1);
				indexLines = positionInitLocals+1;
				//insert local variable
				writer.Write(writer.NewLine);
				writer.WriteLine(".locals init (int32 myvalue)");
				//copy rest of the method until the line before "ret"
				CopyBlock(lines, indexLines, positionRet);
				
				//next line is "ret" - nothing left to damage on the stack
				indexLines = positionRet;
				
				//insert ldc/stloc pairs for [bytesPerMethod] bytes from the message stream
				//combine 4 bytes in one Int32
				for(int n=0; n<bytesPerMethod; n+=4){
					isMessageComplete = GetNextMessageValue(message, out currentMessageValue);
					writer.WriteLine("ldc.i4 "+currentMessageValue.ToString());
					writer.WriteLine("stloc myvalue");
				}

				//bytesPerMethod must be last one in the first method
				if(! isBytesPerMethodWritten){
					writer.WriteLine("ldc.i4 "+bytesPerMethod.ToString());
					writer.WriteLine("stloc myvalue");
					isBytesPerMethodWritten = true;
				}

				//copy current line
				writer.WriteLine(lines[indexLines]);

				if(isMessageComplete){
					//nothing read from the message stream, the message is complete
					//copy rest of the source file
					indexLines++;
					CopyBlock(lines, indexLines, lines.Length-1);
				}
			}
			return isMessageComplete;
		}

		/// <summary>
		/// Returns the next Int32 value to hide.
		/// First call returns message.Length,
		/// next calls return an Int32 containing 4 bytes from the message stream
		/// </summary>
		/// <param name="message">Stream containing the message</param>
		/// <param name="messageValue">Receives the next Int32 value to hide</param>
		/// <returns>true: the last byte has been hidden; false: more message-bytes are waiting</returns>
		private bool GetNextMessageValue(Stream message, out int messageValue){
			bool returnValue = false;
			messageValue = 0;
			
			if(! isMessageLengthWritten){
				//insert length of the message
				messageValue = (Int32)message.Length;
				isMessageLengthWritten = true;
			}else{
				//insert message byte
				for(int n=0; n<4; n++){
					int currentMessageValue = message.ReadByte();
				
					if(currentMessageValue < 0){
						returnValue = true;
						break;
					}else{
						messageValue += currentMessageValue << (8*n);
					}	
				}
			}

			return returnValue;
		}

		/// <summary>Extracts one or more bytes from the IL file</summary>
		/// <param name="lines">Lines of the IL file</param>
		/// <param name="indexLines">Current index in [lines]</param>
		/// <param name="message">Stream to store the extracted bytes in</param>
		/// <returns>true: the last byte has been extracted; false: more message-bytes are waiting</returns>
		private bool ProcessMethodExtract(String[] lines, ref int indexLines, Stream message){
			bool isMessageComplete = false;
			int positionRet,				//index of the "ret" line
				positionStartOfMethodLine;	//index of the method's first line
			
			if(lines[indexLines].IndexOf(" void ") > 0){
				//found a method with return type "void"
				//a part of the message is hidden here

				indexLines++; //next line
						
				//search first line of method block
				SeekStartOfBlock(lines, ref indexLines);
				positionStartOfMethodLine = indexLines;
						
				//go to first line of the method
				indexLines++;
				//get position of "ret"
				positionRet = SeekRet(lines, ref indexLines);
				if(bytesPerMethod == 0){
					//go 2 lines back - there we inserted "ldc.i4 "+bytesPerMethod
					indexLines = positionRet - 2;

				}else{
					//go 2 lines per expected message-byte back - there we inserted "ldc.i4 "+currentByte
					
					int countBytesLeftToRead = messageLength - (Int32)message.Length;
					if((countBytesLeftToRead > bytesPerMethod)||(messageLength == 0)){
						indexLines = positionRet - linesPerMethod;
					}else{
						linesPerMethod = (int)Math.Ceiling((float)countBytesLeftToRead/(float)4) *2;
						indexLines = positionRet - linesPerMethod;
					}
				}
				
				int indexValue; //index of the hidden value in a line
				String sValue;	//found value
				int iValue;		//found value, converted

				//read [bytesPerMethod] bytes from the message stream
				//if [bytesPerMethod]==0 it has not been read yet
				for(int n=0; (n<bytesPerMethod)||(bytesPerMethod==0); n+=4){	
					//ILDAsm creates line numbers - find the beginning of the instruction
					indexValue = lines[indexLines].IndexOf("ldc.i4");
					if(indexValue >= 0){
						//jump over "ldc.i4 " and get the constant
						indexValue += 7;
						sValue = lines[indexLines].Substring(indexValue);
						//parse the found value
						if(sValue.IndexOf('x') > 0){
							sValue = sValue.Substring(sValue.IndexOf("x")+1);
							iValue = int.Parse(sValue, System.Globalization.NumberStyles.HexNumber);
						}else{
							iValue = int.Parse(sValue);
						}

						if(bytesPerMethod == 0){ //[bytesPerMethod] has not been read yet
							bytesPerMethod = iValue;
							//go 2 lines per expected message-byte back - there we inserted "ldc.i4 "+currentByte.ToString()
							linesPerMethod = (int)Math.Ceiling((float)bytesPerMethod/(float)4) *2;
							indexLines = positionRet - 2 - linesPerMethod;
							//reset counter
							n-=4;
						}else{
							if(messageLength == 0){ //messageLength has not been read yet
								messageLength = iValue;
							}else{
								//the header values have already been read,
								//so this is a message value
								for(int indexBytes=0; indexBytes<4; indexBytes++){
									byte bValue = (byte)(iValue >> (indexBytes*8));
									message.WriteByte(bValue);
									isMessageComplete = (message.Length == messageLength);
									if(isMessageComplete){ break; }
								}
								if(isMessageComplete){ break; }
							}
							indexLines += 2; //next message-byte is in the next 2 lines
						}
					}else{
						//the line we tried to split is not a "ldc.i4" instruction - something has gone wrong!
						throw new ArgumentException("There is no message hidden in this file!");
					}
				}
			}
			return isMessageComplete;
		}

		/// <summary>Skips all lines until the next "{"</summary>
		/// <param name="lines">Lines of the IL file</param>
		/// <param name="indexLines">Current index in [lines]</param>
		private void SeekStartOfBlock(String[] lines, ref int indexLines){
			while(lines[indexLines].IndexOf("{") < 0){
				indexLines++;
			}
		}

		/// <summary>Finds the last ".locals init" and first "ret" line of a method</summary>
		/// <param name="lines">Lines of the IL file</param>
		/// <param name="indexLines">Current index in [lines]</param>
		/// <param name="positionInitLocals">Receives the index of the last ".local init" line</param>
		/// <param name="positionRet">Receives the index of the first "ret" line</param>
		private void SeekLastLocalsInit(String[] lines, ref int indexLines, ref int positionInitLocals, ref int positionRet){
			while(lines[indexLines].IndexOf("ret") < 0){ //until end of method
				if(lines[indexLines].IndexOf(".locals init ")>0){
					//.locals ends with ")"
					while(lines[indexLines].IndexOf(")") < 0){
						indexLines++;
					}
					positionInitLocals = indexLines;
				}
				indexLines++;
			}
			positionRet = indexLines;
		}

		/// <summary>Finds the first "ret" line in a method</summary>
		/// <param name="lines">Lines of the IL file</param>
		/// <param name="indexLines">Current index in [lines]</param>
		/// <returns>Index of the first "ret" line</returns>
		private int SeekRet(String[] lines, ref int indexLines){
			while(lines[indexLines].IndexOf("ret") < 0){ //until end of method
				indexLines++;
			}
			return indexLines;
		}

		/// <summary>Copies a block of lines from [lines] into the destination file</summary>
		/// <param name="lines">Lines of the IL file</param>
		/// <param name="start">Index of the first line to copy</param>
		/// <param name="end">Index of the last line to copy</param>
		private void CopyBlock(String[] lines, int start, int end){
			String[] buffer = new String[end-start];
			Array.Copy(lines, start, buffer, 0, buffer.Length);
			writer.Write(String.Join(writer.NewLine, buffer));
			writer.Write(writer.NewLine);
		}
	}
}
